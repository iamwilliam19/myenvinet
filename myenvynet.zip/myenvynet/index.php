<?php
	include('./db/config.php');
	//action carries name of pages to be included
	$myaction = $_GET['action'];
	$dir = $_GET['dir'];
	//assignment of feedbacks to variables
	$signal = $_GET['signal'];
	$error = $_GET['error'];
	$cp = $_GET['cp'];
	$view_title = $_GET['title'];


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" Type="text/css" href="style.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
<script type="text/javascript" src="./library/jquery.min.js"></script>
<script src="design.js"></script>
<title>myenvynet</title>
</head>

<body>
	<div class="container">
		<!-- hearder box-->
			<div class="header_box">
				<img src="./images/ip.jpg" width="100%" height="100%" style="-webkit-filter: brightness(0.4);
filter: brightness(0.4);" />
				<div class="cover">
					<!-- logo-->
					<a href="?action=home"><div class="logo">
						<img src="./images/logo.jpg" width="100%" height="100%" />
					</div></a>
					<!-- logo ends -->

					<!-- menu icon-->
					<div class="menu_icon">
						<i class="fa fa-bars"></i>
					</div>
					<!--menu icon-->

					<!-- serach_icon-->
					<div class="search_icon">
						<i class="fa fa-search"></i>
					</div>
					<!--search icon ends-->

					

					<div style="clear: both"></div>
				</div>		

				
			</div>
		<!--header box ends-->



		<!-- body container starts-->
		<div class="body_container">


			<!-- menu link-->
			<div class="menu_link">
				<ul >
					<!--the links here were given a name for addition of there pages into index-->
					<a href="?action=home"><li>Home</li></a>
					<a href="?action=news_feed"><li>News feed</li></a>
					<a href="?action=deals"><li>Deals</li></a>
					<a href="?action=how_to"><li>How Tos</li></a>
					<a href="?action=articles"><li>Articles</li></a>
					<a href="?action=publish"><li>Publish</li></a>
					<a href="?action=reviews"><li>Reviews</li></a>
					<a href="?action=gallery"><li>Gallery</li></a>
					<a href="?action=gadgets&gad=smartphones"><li>Smartphones & TVs</li></a>
					<a href="?action=compare"><li>Compare gadgets</li></a>
					<a href="?action=profile"><li>My profile</li></a>
					<?php 
						if($_SESSION['email'] == ''){
					?>
						<a href="?action=sign_in"><li>Sign in</li></a>

						<a href="?action=sign_up"><li>Sign up</li></a>

					<?php }else{?>
						<a href="db/sign_out.php"><li>Sign out</li></a>
					<?php } ?>
				</ul>
			</div>
		<!-- menu link ends-->

	<?php 
		//pages inclusiong
		//all pages with the matching names, were included here
		if($myaction == 'gallery'){
			include('./pages/gallery.php');
	}else if($myaction == 'profile'){
		include('./pages/profile.php');
	}else if($myaction == 'compare'){
		include('./pages/compare.php');
	}else if($myaction == 'deals'){
		include('./pages/deals.php');
	}else if($myaction == 'gadgets'){
		include('./pages/gadgets.php');
	}else if($myaction == 'news_feed'){
		include('./pages/news.php');
	}else if($myaction == 'how_to'){
		include('./pages/how_to.php');
	}else if($myaction == 'reviews'){
		include('./pages/reviews.php');
	}else if($myaction == 'articles'){
		include('./pages/articles.php');
	}else if($myaction == 'publish'){
		include('./pages/publish.php');
	}else if($myaction == 'gallery_others'){
		include('./pages/galleryOthers.php');
	}else if($myaction == 'smartphone_spec'){
		include('./pages/smartphone_spec.php');
	}else if($myaction == 'view'){
		include('./pages/view.php');
	}else if($myaction == 'sign_in'){
		include('./pages/sign_in.php');
	}else if($myaction == 'sign_up'){
		include('./pages/sign_up.php');
	}else if($myaction == 'disclaimer'){
		include('./pages/disclaimer.php');
	}else if($myaction == 'comment'){
		include('./pages/comment.php');
	}else if($myaction == 'reply'){
		include('./pages/reply.php');
	}else if($myaction == 'result'){
		include('./pages/result.php');
	}else if($myaction == 'smartdeals'){
		include('./pages/smartdeals.php');
	}else if($myaction == 'tvdeals'){
		include('./pages/tvdeals.php');
	}else if($myaction == 'laptopdeals'){
		include('./pages/laptopdeals.php');
	}else if($myaction == 'speakerdeals'){
		include('./pages/speakerdeals.php');
	}else if($myaction == 'sounddeals'){
		include('./pages/sound_deals.php');
	}else if($myaction == 'admin_profile'){
		include('./pages/admin_profile.php');
	}else if($myaction == 'member_profile'){
		include('./pages/member_profile.php');
	}else if($myaction == 'tv_spec'){
		include('./pages/tv_spec.php');
	}else if($myaction == 'television_list'){
		include('./pages/television_list.php');
	}else if($myaction == 'phone_list'){
		include('./pages/phone_list.php');
	}else if($myaction == 'smartphone_pics'){
		include('./pages/smartphone_pics.php');
	}else if($myaction == 'tv_pics'){
		include('./pages/tv_pics.php');
	}else if($myaction == 'sel_smartPhone'){
		include('./pages/sel_smartPhone.php');
	}else if($myaction == 'sel_other'){
		include('./pages/sel_other.php');
	}else if($myaction == 'pubnea'){
		include('./pages/pubnea.php');
	}else{
		
	?>	

			<!-- news feed container -->
				<div class="news_feed_box">
					<!-- news feed title -->
						<div class="news_title">
							News feed
						</div>
					<!--news feed title-->

					<?php
			//select content for news feed
			$select_news_feed = $conn -> query("SELECT * FROM news WHERE section = 'news_feed' order by id DESC LIMIT 5");
			$counter = 0;
			while($fetch_feed = $select_news_feed -> fetch_assoc()){
				$news_feed_img = $fetch_feed['image'];
				$news_feed_title = $fetch_feed['title'];
				$news_feed_content = $fetch_feed['content'];
				$news_feed_date = $fetch_feed['date'];
				$news_feed_poster = $fetch_feed['poster'];
				$news_feed_id = $fetch_feed['id'];
				$rank = $fetch_feed['poster_rank'];
				$poster_email = $fetch_feed['poster_email'];
				$news_feed_year = $fetch_feed['year'];
				$news_feed_month = $fetch_feed['month'];
				$news_feed_day = $fetch_feed['day'];
				$news_feed_hour = $fetch_feed['hour'];
				$news_feed_min = $fetch_feed['minute'];
				$news_feed_sec = $fetch_feed['second'];

				//get  date from data base and compare with current date
				$d = date("d");
				$main_day = $d - $news_feed_day;

				$y = date("y");
				$main_year = $y - $news_feed_year; 


				$m = date("m");
				$main_month = $m - $news_feed_month;

				$hr = date("H");
				$main_hour = $hr - $news_feed_hour;

				$mn = date("i");
				$main_min = $mn - $news_feed_min;

				$sc = date("s");
				$main_sec = $sc - $news_feed_sec;

				if($main_year != 0){
					 $time = 10;
				}else if($main_year == 0){
					if($main_month != 0){
						 $time = 9;
					}else if($main_month == 0){
						if($main_day != 0){
						$time = 8;
						}else if($main_day == 0){
							if($main_hour != 0){
								$time = 7;
							}else if($main_hour == 0){
								if($main_min != 0){
									$time = 6;
								}else if($main_min == 0){
									if($main_sec != 0){
										$time = 5;
									}else if($main_sec == 0){
										$time = 4;
									}
								}
							}
						}
					}
				}
				$strlen = strlen($news_feed_title);
				//check value of counter and decide if to post with pic
				if($counter == 0){
					$counter++;
		?>

					<!--newsfeed pic display-->
						<a href="?action=view&gv=<?php  echo $news_feed_id ;?>&dir=news_feed"><div class="pic_display_box">
							<!-- img box-->
								<div class="img_box">
									<img src="<?php echo $news_feed_img; ?>" width="100%" height="100%">
								</div>
							<!--img box ends-->
							<!--img_title-->
							<div class="img_title">
								<?php echo substr($news_feed_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
								
							</div>
							<!--img_title ends-->

							<!--img others -->
							<div class="img_others">
								<!-- check the rank of who owns the post so to know if member or admin -->
								<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="img_poster">By <?php echo $news_feed_poster ;?></div></a>

								<div class="img_date">
									<i class="fa fa-calendar" aria-hidden="true"></i>
								<?php
								//post value of time
									if($time == 10){
										if($main_year != 1){echo $main_year .' '. 'years ago';}
										else if($main_year == 1){echo $main_year .' '. 'year ago';}
									}else if($time == 9){
										if($main_month != 1){echo $main_month .' '. 'months ago';}
										else if($main_month == 1){echo $main_month .' '. 'month ago';}
									}else if($time == 8){
										if($main_day != 1){echo $main_day .' '. 'days ago';}
										if($main_day == 1){echo 'Yesterday';}
									}else if($time == 7){
										if($main_hour != 1){echo $main_hour .' '. 'hours ago';}
										else if($main_hour == 1){echo $main_hour .' '. 'hour ago';}
									}else if($time == 6){
										if($main_min != 1){echo $main_min .' '. 'mins ago';}
										else if($main_min == 1){echo $main_min .' '. 'min ago';}
									}else if($time == 5){
										if($main_sec != 1){echo $main_sec .' '. 'secs ago';}
									}else if($time == 4){
										echo ' Now';
									}
									
								
								?>
								</div>
								<div style="clear: both;"></div>
							</div>
							<!-- img others -->

						</div></a>
					<!-- news feed pic display box ends-->
					<div class="line"></div>
					<?php
			}else if ($counter > 0){
		?>
					<!--text-display-->
					<a href="?action=view&gv=<?php  echo $news_feed_id ;?>&dir=news_feed"><div class="text_display_box">
						<!-- text title-->
						<div class="text_title">
							<?php echo substr($news_feed_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
						</div>
						<!-- text _title ends-->

						<!-- text text-->
						<div class="text_text">
							<?php echo substr($news_feed_content,0,150); ?>
						</div>
						<!-- text text ends-->
						<div style="width: 100%; height: auto;">
						<!--text_others-->
						<div class="text_others">
							<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="text_poster">
								By <?php echo $news_feed_poster ;?>
							</div></a>

							<div class="text_date">
								<i class="fa fa-calendar" aria-hidden="true"></i>
								<?php
									if($time == 10){
										if($main_year != 1){echo $main_year .' '. 'years ago';}
										else if($main_year == 1){echo $main_year .' '. 'year ago';}
									}else if($time == 9){
										if($main_month != 1){echo $main_month .' '. 'months ago';}
										else if($main_month == 1){echo $main_month .' '. 'month ago';}
									}else if($time == 8){
										if($main_day != 1){echo $main_day .' '. 'days ago';}
										if($main_day == 1){echo 'Yesterday';}
									}else if($time == 7){
										if($main_hour != 1){echo $main_hour .' '. 'hours ago';}
										else if($main_hour == 1){echo $main_hour .' '. 'hour ago';}
									}else if($time == 6){
										if($main_min != 1){echo $main_min .' '. 'mins ago';}
										else if($main_min == 1){echo $main_min .' '. 'min ago';}
									}else if($time == 5){
										if($main_sec != 1){echo $main_sec .' '. 'secs ago';}
									}else if($time == 4){
										echo ' Now';
									}
									
								
								?>
							</div>
							<div style="clear: both;"></div>
						</div>
						<!--text others end-->
						
					</div></a>
					<!--text display ends -->
					</div>
					<div class="line"></div>
					<?php
			}
				}
		?>

			<!-- see more begins-->
			<div class="see_more">
				<div class="see">see more  <span> > </span></div>
				<div style="clear: both;"></div>
			</div>

			<!-- see more ends-->
				</div>
			<!-- news feed container ends -->

			<!-- latest articles start-->
			<div class="latest_box">
					<!-- news feed title -->
						<div class="latest_title">
							Latest articles
						</div>
					<!--news feed title-->

			<?php
			
				$select_latest_article = $conn -> query("SELECT * FROM news WHERE section = 'articles' order by id DESC LIMIT 5");
				$counter = 0;
				while($fetch_article = $select_latest_article -> fetch_assoc()){
					$latest_article_img = $fetch_article['image'];
					$latest_article_title = $fetch_article['title'];
					$latest_article_content = $fetch_article['content'];
					$latest_article_date = $fetch_article['date'];
					$latest_article_poster = $fetch_article['poster'];
					$latest_article_id = $fetch_article['id'];
					$rank = $fetch_article['poster_rank'];
				    $poster_email = $fetch_article['poster_email'];
				    $latest_article_year = $fetch_article['year'];
					$latest_article_month = $fetch_article['month'];
					$latest_article_day = $fetch_article['day'];
					$latest_article_hour = $fetch_article['hour'];
					$latest_article_min = $fetch_article['minute'];
					$latest_article_sec = $fetch_article['second'];

					$d = date("d");
					$main_day = $d - $latest_article_day;

					$y = date("y");
					$main_year = $y - $latest_article_year; 


					$m = date("m");
					$main_month = $m - $latest_article_month;

					$hr = date("H");
					$main_hour = $hr - $latest_article_hour;

					$mn = date("i");
					$main_min = $mn - $latest_article_min;

					$sc = date("s");
					$main_sec = $sc - $latest_article_sec;

					if($main_year != 0){
						 $time = 10;
					}else if($main_year == 0){
						if($main_month != 0){
							 $time = 9;
						}else if($main_month == 0){
							if($main_day != 0){
							$time = 8;
							}else if($main_day == 0){
								if($main_hour != 0){
									$time = 7;
								}else if($main_hour == 0){
									if($main_min != 0){
										$time = 6;
									}else if($main_min == 0){
										if($main_sec != 0){
											$time = 5;
										}else if($main_sec == 0){
											$time = 4;
										}
									}
								}
							}
						}
					}
					$strlen = strlen($latest_aritcle_title);

				//check value of counter and decide if to post with pic
				if($counter == 0){
					$counter++;
		?>

					<!--newsfeed pic display-->
					<a href="?action=view&gv=<?php  echo $latest_article_id ;?>&dir=articles">	<div class="pic_display_box">
							<!-- img box-->
								<div class="img_box">
									<img src="<?php echo $latest_article_img; ?>" width="100%" height="100%">
								</div>
							<!--img box ends-->
							<!--img_title-->
							<div class="img_title">
								<?php echo substr($latest_article_title, 0,100);  if($strlen > 100){echo "..." ;} ?> 
								
							</div>
							<!--img_title ends-->

							<!--img others -->
							<div class="img_others">
								<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="img_poster">By  <?php echo $latest_article_poster ;?></div></a>

								<div class="img_date">
									<i class="fa fa-calendar" aria-hidden="true"></i>
								<?php
									if($time == 10){
										if($main_year != 1){echo $main_year .' '. 'years ago';}
										else if($main_year == 1){echo $main_year .' '. 'year ago';}
									}else if($time == 9){
										if($main_month != 1){echo $main_month .' '. 'months ago';}
										else if($main_month == 1){echo $main_month .' '. 'month ago';}
									}else if($time == 8){
										if($main_day != 1){echo $main_day .' '. 'days ago';}
										if($main_day == 1){echo 'Yesterday';}
									}else if($time == 7){
										if($main_hour != 1){echo $main_hour .' '. 'hours ago';}
										else if($main_hour == 1){echo $main_hour .' '. 'hour ago';}
									}else if($time == 6){
										if($main_min != 1){echo $main_min .' '. 'mins ago';}
										else if($main_min == 1){echo $main_min .' '. 'min ago';}
									}else if($time == 5){
										if($main_sec != 1){echo $main_sec .' '. 'secs ago';}
									}else if($time == 4){
										echo ' Now';
									}
									
								
								?>
								</div>
							</div>
							<!-- img others -->

						</div></a>
					<!-- news feed pic display box ends-->
					<div class="line"></div>
					<?php
			}else if ($counter > 0){
		?>
					<!--text-display-->
				<a href="?action=view&gv=<?php  echo $latest_article_id ;?>&dir=articles">	<div class="text_display_box">
						<!-- text title-->
						<div class="text_title">
							<?php echo substr($latest_article_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
						</div>
						<!-- text _title ends-->

						<!-- text text-->
						<div class="text_text">
							<?php echo substr($latest_article_content,0,150); ?>
						</div>
						<!-- text text ends-->
						<div style="width: 100%; height: auto;">
						<!--text_others-->
						<div class="text_others">
							<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class=" text_poster">
								By <?php echo $latest_article_poster; ?>
							</div></a>

							<div class="text_date">
									<i class="fa fa-calendar" aria-hidden="true"></i>
								<?php
									if($time == 10){
										if($main_year != 1){echo $main_year .' '. 'years ago';}
										else if($main_year == 1){echo $main_year .' '. 'year ago';}
									}else if($time == 9){
										if($main_month != 1){echo $main_month .' '. 'months ago';}
										else if($main_month == 1){echo $main_month .' '. 'month ago';}
									}else if($time == 8){
										if($main_day != 1){echo $main_day .' '. 'days ago';}
										if($main_day == 1){echo 'Yesterday';}
									}else if($time == 7){
										if($main_hour != 1){echo $main_hour .' '. 'hours ago';}
										else if($main_hour == 1){echo $main_hour .' '. 'hour ago';}
									}else if($time == 6){
										if($main_min != 1){echo $main_min .' '. 'mins ago';}
										else if($main_min == 1){echo $main_min .' '. 'min ago';}
									}else if($time == 5){
										if($main_sec != 1){echo $main_sec .' '. 'secs ago';}
									}else if($time == 4){
										echo ' Now';
									}
									
								
								?>
							</div>
							<div style="clear: both;"></div>
						</div>
						<!--text others end-->

					</div></a>
					<!--text display ends -->
				</div>
					<div class="line"></div>
					<?php
			}
				}
		?>

			<!-- see more begins-->
			<div class="see_more">
				<div class="see">see more articles  <span> > </span></div>
				<div style="clear: both;"></div>
			</div>

			<!-- see more ends-->
				</div>
			<!-- latest articles ends-->

			<!--  reviews start-->
			<div class="review_box">
					<!-- news feed title -->
						<div class="review_title">
							Review articles
						</div>
					<!--news feed title-->

					<?php
			
			$select_review_article = $conn -> query("SELECT * FROM news WHERE section = 'reviews' order by id DESC LIMIT 5");
	$counter = 0;
	while($fetch_review = $select_review_article -> fetch_assoc()){
		$review_img = $fetch_review['image'];
		$review_title = $fetch_review['title'];
		$review_content = $fetch_review['content'];
		$review_date = $fetch_review['date'];
		$review_poster = $fetch_review['poster'];
		$review_id = $fetch_review['id'];
		$rank = $fetch_review['poster_rank'];
		$poster_email = $fetch_review['poster_email'];
		$review_year = $fetch_review['year'];
		$review_month = $fetch_review['month'];
		$review_day = $fetch_review['day'];
		$review_hour = $fetch_review['hour'];
		$review_min = $fetch_review['minute'];
		$review_sec = $fetch_review['second'];

					$d = date("d");
					$main_day = $d - $review_day;

					$y = date("y");
					$main_year = $y - $review_year; 


					$m = date("m");
					$main_month = $m - $review_month;

					$hr = date("H");
					$main_hour = $hr - $review_hour;

					$mn = date("i");
					$main_min = $mn - $review_min;

					$sc = date("s");
					$main_sec = $sc - $review_sec;

					if($main_year != 0){
						 $time = 10;
					}else if($main_year == 0){
						if($main_month != 0){
							 $time = 9;
						}else if($main_month == 0){
							if($main_day != 0){
							$time = 8;
							}else if($main_day == 0){
								if($main_hour != 0){
									$time = 7;
								}else if($main_hour == 0){
									if($main_min != 0){
										$time = 6;
									}else if($main_min == 0){
										if($main_sec != 0){
											$time = 5;
										}else if($main_sec == 0){
											$time = 4;
										}
									}
								}
							}
						}
					}

		$strlen = strlen($review_title);
				//check value of counter and decide if to post with pic
				if($counter == 0){
					$counter++;
		?>

					<!--newsfeed pic display-->
					<a href="?action=view&gv=<?php  echo $review_id ;?>&dir=reviews">	<div class="pic_display_box">
							<!-- img box-->
								<div class="img_box">
									<img src="<?php echo $review_img; ?>" width="100%" height="100%">
								</div>
							<!--img box ends-->
							<!--img_title-->
							<div class="img_title">
								<?php echo substr($review_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
								
							</div>
							<!--img_title ends-->

							<!--img others -->
							<div class="img_others">
								<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="img_poster">By <?php echo $review_poster ;?></div></a>

								<div class="img_date">
									<i class="fa fa-calendar" aria-hidden="true"></i>
								<?php
									if($time == 10){
										if($main_year != 1){echo $main_year .' '. 'years ago';}
										else if($main_year == 1){echo $main_year .' '. 'year ago';}
									}else if($time == 9){
										if($main_month != 1){echo $main_month .' '. 'months ago';}
										else if($main_month == 1){echo $main_month .' '. 'month ago';}
									}else if($time == 8){
										if($main_day != 1){echo $main_day .' '. 'days ago';}
										if($main_day == 1){echo 'Yesterday';}
									}else if($time == 7){
										if($main_hour != 1){echo $main_hour .' '. 'hours ago';}
										else if($main_hour == 1){echo $main_hour .' '. 'hour ago';}
									}else if($time == 6){
										if($main_min != 1){echo $main_min .' '. 'mins ago';}
										else if($main_min == 1){echo $main_min .' '. 'min ago';}
									}else if($time == 5){
										if($main_sec != 1){echo $main_sec .' '. 'secs ago';}
									}else if($time == 4){
										echo ' Now';
									}
									
								
								?>
								</div>
							</div>
							<!-- img others -->

						</div></a>
					<!-- news feed pic display box ends-->
					<div class="line"></div>
					<?php
			}else if ($counter > 0){
		?>
					<!--text-display-->
					<a href="?action=view&gv=<?php  echo $review_id ;?>&dir=reviews"><div class="text_display_box">
						<!-- text title-->
						<div class="text_title">
							<?php echo substr($review_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
						</div>
						<!-- text _title ends-->

						<!-- text text-->
						<div class="text_text">
							<?php echo substr($review_content,0,150); ?>
						</div>
						<!-- text text ends-->

						<!--text_others-->
						<div class="text_others">
							<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="text_poster">
								By <?php echo $review_poster ;?>
							</div></a>

							<div class="text_date">
								<i class="fa fa-calendar" aria-hidden="true"></i>
								<?php
									if($time == 10){
										if($main_year != 1){echo $main_year .' '. 'years ago';}
										else if($main_year == 1){echo $main_year .' '. 'year ago';}
									}else if($time == 9){
										if($main_month != 1){echo $main_month .' '. 'months ago';}
										else if($main_month == 1){echo $main_month .' '. 'month ago';}
									}else if($time == 8){
										if($main_day != 1){echo $main_day .' '. 'days ago';}
										if($main_day == 1){echo 'Yesterday';}
									}else if($time == 7){
										if($main_hour != 1){echo $main_hour .' '. 'hours ago';}
										else if($main_hour == 1){echo $main_hour .' '. 'hour ago';}
									}else if($time == 6){
										if($main_min != 1){echo $main_min .' '. 'mins ago';}
										else if($main_min == 1){echo $main_min .' '. 'min ago';}
									}else if($time == 5){
										if($main_sec != 1){echo $main_sec .' '. 'secs ago';}
									}else if($time == 4){
										echo ' Now';
									}
									
								
								?>
							</div>
							
						</div>
						<!--text others end-->

					</div></a>
					<!--text display ends -->

					<div class="line"></div>
					<?php
			}
				}
		?>

			<!-- see more begins-->
			<div class="see_more">
				<div class="see">see more reviews <span> > </span></div>
				<div style="clear: both;"></div>
			</div>

			<!-- see more ends-->
				</div>

			<!-- reviews end-->

			<!-- hot to begins-->
			<div class="how_to_box">
					<!-- news feed title -->
						<div class="how_to_title">
							Latest on How Tos'
						</div>
					<!--news feed title-->

					<?php
			
			$select_how_to = $conn -> query("SELECT * FROM news WHERE section = 'how_to'  order by id DESC LIMIT 5");
	$counter = 0;
	while($fetch_how_to = $select_how_to -> fetch_assoc()){
		$how_to_img = $fetch_how_to['image'];
		$how_to_title = $fetch_how_to['title'];
		$how_to_content = $fetch_how_to['content'];
		$how_to_date = $fetch_how_to['date'];
		$how_to_poster = $fetch_how_to['poster'];
		$how_to_id = $fetch_how_to['id'];
		$rank = $fetch_how_to['poster_rank'];
		$how_to_email = $fetch_how_to['poster_email'];
		$how_to_year = $fetch_how_to['year'];
		$how_to_month = $fetch_how_to['month'];
		$how_to_day = $fetch_how_to['day'];
		$how_to_hour = $fetch_how_to['hour'];
		$how_to_min = $fetch_how_to['minute'];
		$how_to_sec = $fetch_how_to['second'];

					$d = date("d");
					$main_day = $d - $how_to_day;

					$y = date("y");
					$main_year = $y - $how_to_year; 


					$m = date("m");
					$main_month = $m - $how_to_month;

					$hr = date("H");
					$main_hour = $hr - $how_to_hour;

					$mn = date("i");
					$main_min = $mn - $review_min;

					$sc = date("s");
					$main_sec = $sc - $review_sec;

					if($main_year != 0){
						 $time = 10;
					}else if($main_year == 0){
						if($main_month != 0){
							 $time = 9;
						}else if($main_month == 0){
							if($main_day != 0){
							$time = 8;
							}else if($main_day == 0){
								if($main_hour != 0){
									$time = 7;
								}else if($main_hour == 0){
									if($main_min != 0){
										$time = 6;
									}else if($main_min == 0){
										if($main_sec != 0){
											$time = 5;
										}else if($main_sec == 0){
											$time = 4;
										}
									}
								}
							}
						}
					}

		$strlen = strlen($how_to_title);
				//check value of counter and decide if to post with pic
				if($counter == 0){
					$counter++;
		?>

					<!--newsfeed pic display-->
					<a href="?action=view&gv=<?php  echo $how_to_id ;?>&dir=how_to">	<div class="pic_display_box">
							<!-- img box-->
								<div class="img_box">
									<img src="<?php echo $how_to_img; ?>" width="100%" height="100%">
								</div>
							<!--img box ends-->
							<!--img_title-->
							<div class="img_title">
								<?php echo substr($how_to_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
								
							</div>
							<!--img_title ends-->

							<!--img others -->
							<div class="img_others">
								<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="img_poster">By <?php echo $how_to_poster ;?></div></a>

								<div class="img_date">
									<i class="fa fa-calendar" aria-hidden="true"></i>
								<?php
									if($time == 10){
										if($main_year != 1){echo $main_year .' '. 'years ago';}
										else if($main_year == 1){echo $main_year .' '. 'year ago';}
									}else if($time == 9){
										if($main_month != 1){echo $main_month .' '. 'months ago';}
										else if($main_month == 1){echo $main_month .' '. 'month ago';}
									}else if($time == 8){
										if($main_day != 1){echo $main_day .' '. 'days ago';}
										if($main_day == 1){echo 'Yesterday';}
									}else if($time == 7){
										if($main_hour != 1){echo $main_hour .' '. 'hours ago';}
										else if($main_hour == 1){echo $main_hour .' '. 'hour ago';}
									}else if($time == 6){
										if($main_min != 1){echo $main_min .' '. 'mins ago';}
										else if($main_min == 1){echo $main_min .' '. 'min ago';}
									}else if($time == 5){
										if($main_sec != 1){echo $main_sec .' '. 'secs ago';}
									}else if($time == 4){
										echo ' Now';
									}
									
								
								?>
								</div>
							</div>
							<!-- img others -->

						</div></a>
					<!-- news feed pic display box ends-->
					<div class="line"></div>
					<?php
			}else if ($counter > 0){
		?>
					<!--text-display-->
					<a href="?action=view&gv=<?php  echo $how_to_id ;?>&dir=how_to"><div class="text_display_box">
						<!-- text title-->
						<div class="text_title">
							<?php echo substr($how_to_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
						</div>
						<!-- text _title ends-->

						<!-- text text-->
						<div class="text_text">
							<?php echo substr($how_to_content,0,150); ?>
						</div>
						<!-- text text ends-->

						<!--text_others-->
						<div class="text_others">
							<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="text_poster">
								By <?php echo $how_to_poster ;?>
							</div></a>

							<div class="text_date">
								<i class="fa fa-calendar" aria-hidden="true"></i>
								<?php
									if($time == 10){
										if($main_year != 1){echo $main_year .' '. 'years ago';}
										else if($main_year == 1){echo $main_year .' '. 'year ago';}
									}else if($time == 9){
										if($main_month != 1){echo $main_month .' '. 'months ago';}
										else if($main_month == 1){echo $main_month .' '. 'month ago';}
									}else if($time == 8){
										if($main_day != 1){echo $main_day .' '. 'days ago';}
										if($main_day == 1){echo 'Yesterday';}
									}else if($time == 7){
										if($main_hour != 1){echo $main_hour .' '. 'hours ago';}
										else if($main_hour == 1){echo $main_hour .' '. 'hour ago';}
									}else if($time == 6){
										if($main_min != 1){echo $main_min .' '. 'mins ago';}
										else if($main_min == 1){echo $main_min .' '. 'min ago';}
									}else if($time == 5){
										if($main_sec != 1){echo $main_sec .' '. 'secs ago';}
									}else if($time == 4){
										echo ' Now';
									}
									
								
								?>
							</div>
							
						</div>
						<!--text others end-->

					</div></a>
					<!--text display ends -->

					<div class="line"></div>
					<?php
			}
				}
		?>

			<!-- see more begins-->
			<div class="see_more">
				<div class="see">see more reviews <span> > </span>
					<div style="clear: both;"></div>
				</div>
			</div>

			<!-- see more ends-->
				</div>
			<!-- how to ends-->

			<!-- gallery begins-->
			<div class="gallery_box">
					<!-- news feed title -->
						<div class="gallery_title">
							Gallery
						</div>
					<!--news feed title-->

					<?php
			$select_gallery = $conn -> query("SELECT * FROM news WHERE section = 'gallery'  order by id DESC LIMIT 5");
	
	while($fetch_gallery = $select_gallery -> fetch_assoc()){
		$gallery_img = $fetch_gallery['image'];
		$gallery_title = $fetch_gallery['title'];
		$gallery_content = $fetch_gallery['content'];
		$gallery_date = $fetch_gallery['date'];
		$gallery_poster = $fetch_gallery['poster'];
		$gallery_extra = $fetch_gallery['extra'];
		$gallery_id = $fetch_gallery['id'];
		$rank = $fetch_gallery['poster_rank'];
		$poster_email = $fetch_gallery['poster_email'];
		$gallery_to_year = $fetch_gallery['year'];
		$gallery_to_month = $fetch_gallery['month'];
		$gallery_to_day = $fetch_gallery['day'];
		$gallery_to_hour = $fetch_gallery['hour'];
		$gallery_to_min = $fetch_gallery['minute'];
		$gallery_to_sec = $fetch_gallery['second'];

					$d = date("d");
					$main_day = $d - $gallery_day;

					$y = date("y");
					$main_year = $y - $gallery_year; 


					$m = date("m");
					$main_month = $m - $gallery_month;

					$hr = date("H");
					$main_hour = $hr - $gallery_hour;

					$mn = date("i");
					$main_min = $mn - $gallery_min;

					$sc = date("s");
					$main_sec = $sc - $gallery_sec;

					if($main_year != 0){
						 $time = 10;
					}else if($main_year == 0){
						if($main_month != 0){
							 $time = 9;
						}else if($main_month == 0){
							if($main_day != 0){
							$time = 8;
							}else if($main_day == 0){
								if($main_hour != 0){
									$time = 7;
								}else if($main_hour == 0){
									if($main_min != 0){
										$time = 6;
									}else if($main_min == 0){
										if($main_sec != 0){
											$time = 5;
										}else if($main_sec == 0){
											$time = 4;
										}
									}
								}
							}
						}
					}
		$strlen = strlen($gallery_title);
		//counting images
		// create a new dom object
		$doc = new DOMDocument();
		//use the object to load our string
		$doc -> loadHTML($gallery_content);
		//create an xpath to tranverse the dom
		$selector = new DOMXpath($doc);
		//select img as choice object
		$result = $selector -> query('//img');
		$img_count = 0;
		//count all matches

		$my_img_array = array();
		foreach($result  as $target){
			$img_count++;

			$img_att = $target->getAttribute('src');

			array_push($my_img_array, $img_att);
			
		}	
?>	

					<!--newsfeed pic display-->
					<a href="?action=view&gv=<?php  echo $gallery_id ;?>&dir=gallery">	<div class="pic_display_box">
							<!-- img box-->
								<div class="gallery_img_box">
									<img src="<?php echo $my_img_array[0]; ?>" width="100%" height="100%">

									<div class="gallery_extra_container">
										<div class="extra_div">
											<?php
												//check if extra is empty
												if($gallery_extra != ''){?>

											<div class="extra"><?php echo substr($gallery_extra, 0, 10 ) ;?></div>
											<?php }else{ ?>
											<div class="extra_empty">
												<?php echo $gallery_extra ;?>
											</div>

										<?php }?>
										</div>
										<div class="gallery_icon">
											<div class="gicon"><i class="fa fa-camera-retro"></i></div>
										</div>
										<div class="pic_counter">
											<div class="extra_counter">
												1 of <?php echo $img_count ?>
											</div>
										</div>
									</div>
								</div>
							<!--img box ends-->
							<!--img_title-->
							<div class="img_title">
								<?php echo substr($gallery_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
								
							</div>
							<!--img_title ends-->

							<!--img others -->
							<div class="img_others">
								<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="img_poster">By  <?php echo $gallery_poster ;?></div></a>

								<div class="img_date">
									<i class="fa fa-calendar" aria-hidden="true"></i>
								<?php
									if($time == 10){
										if($main_year != 1){echo $main_year .' '. 'years ago';}
										else if($main_year == 1){echo $main_year .' '. 'year ago';}
									}else if($time == 9){
										if($main_month != 1){echo $main_month .' '. 'months ago';}
										else if($main_month == 1){echo $main_month .' '. 'month ago';}
									}else if($time == 8){
										if($main_day != 1){echo $main_day .' '. 'days ago';}
										if($main_day == 1){echo 'Yesterday';}
									}else if($time == 7){
										if($main_hour != 1){echo $main_hour .' '. 'hours ago';}
										else if($main_hour == 1){echo $main_hour .' '. 'hour ago';}
									}else if($time == 6){
										if($main_min != 1){echo $main_min .' '. 'mins ago';}
										else if($main_min == 1){echo $main_min .' '. 'min ago';}
									}else if($time == 5){
										if($main_sec != 1){echo $main_sec .' '. 'secs ago';}
									}else if($time == 4){
										echo ' Now';
									}
									
								
								?>
								</div>
								<div style="clear: both;"></div>

								
							</div>
							<!-- img others -->

						</div></a>
					<!-- news feed pic display box ends-->
					
					<div class="line"></div>

					
					<?php
			
				}
		?>

			<!-- see more begins-->
			<div class="see_more">
				<div class="see">Go to gallery <span> > </span></div>
				
			</div>

			<!-- see more ends-->
				</div>
			<!-- gallery ends-->

			<!-- hot deals begin-->
			<div class="hot_deal_box">
				<!-- hot title-->
				<div class="hot_title">
					Hot deals
				</div>
				<!-- hot title ends-->

				<!-- hot main display-->
				<?php
	
	$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals'  order by id DESC LIMIT 5");
	
	while($fetch_deal = $select_deal -> fetch_assoc()){
		$deal_img = $fetch_deal['image'];
		$deal_title = $fetch_deal['title'];
		$deal_content = $fetch_deal['content'];
		$deal_date = $fetch_deal['date'];
		$deal_poster = $fetch_deal['poster'];
		$deal_disccount = $fetch_deal['disccount'];
		$deal_store = $fetch_deal['store'];
		$deal_price = $fetch_deal['price'];
		$deal_id = $fetch_deal['id'];
		$rank = $fetch_deal['poster_rank'];
		$poster_email = $fetch_deal['poster_email'];
		$strlen = strlen($deal_title);
		$txt_strlen = strlen($deal_content);

		?>

				<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="hot_main_display">
					<!--main title-->
					<div class="hot_main_title">
						<?php echo substr($deal_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
					</div>
					<!-- main title ends-->
					<!-- hot img box-->
					<div class="hot_image_box">
						<img src="<?php echo $deal_img; ?>" width="100%" height="100%"/>
						<?php if($deal_disccount != ''){ ?>
						<div class="hot_extra"><?php echo $deal_disccount; ?>% 0FF</div>
							<?php } ?>
					</div>
					<!-- hot image box ends-->
					<?php if($deal_price != '' && $deal_store != ''){ ?>
					<div class="hot_price">
						<span>$<?php echo $deal_price; ?></span> (at <?php echo $deal_store; ?>)
					</div>
					<?php } ?>

					<div class="hot_txt"><?php echo substr( $deal_content,0,210); if($txt_strlen > 210){echo '...';} ?> </div>

					<div class="details_link">Check details... </div>
					<div class="line"></div>
				</div></a>
				<?php } ?>
				<!-- hot main display ends-->

				
			</div>
			<!-- hot deals end-->

			<!--smart phones starts-->
			<div class="smart_phones_container">
				<!-- smart phone title-->
				<div class="smart_phone_title">Latest smart phones</div>
				<!-- smart phone title ends-->

				<!--smart_box-->
				<div class="smart_box">
					<?php
	
	$select_phone = $conn -> query("SELECT * FROM news WHERE section = 'phones'  order by id DESC LIMIT 3");
	
	while($fetch_phone = $select_phone -> fetch_assoc()){
		$phone_img = $fetch_phone['image'];
		$phone_title = $fetch_phone['title'];
		$phone_id = $fetch_phone['id'];
		
		$strlen = strlen($phone_title);

		?>

					<!--smart display-->
				<div class="smart_display">
					<a href="?action=smartphone_spec&sc=<?php echo $phone_id; ?>">	<img src="<?php echo $phone_img ; ?>" width="100%" height="100%" /></a>
						<!-- phone_name-->
						<a href="?action=smartphone_spec&sc=<?php echo $phone_id; ?>"><div class="phone_name_container">
						<div class="phone_name"><?php echo substr($phone_title, 0 , 20); ?></div>
					</div></a>
						<!--phone name ends-->
					</div>
					<!--smart display ends-->
					<?php } ?>
					<div style="clear: both;"></div>
				</div>
				<!--smart box ends-->
				<div class="line"></div>
				<!-- see more begins-->
			<div class="see_more">
				<div class="see">see more smart phones <span> > </span></div>
				<div style="clear: both;"></div>
			</div>

			<!-- see more ends-->
				
			</div>
			<!--smart phone ends-->

			<!-- television starts -->
			<div class="tele_box">
				<!--tele title-->
					<div class="tele_title">
						Latest on Televisions
					</div>
				<!--tele title ends-->
				<?php
	$select_tele = $conn -> query("SELECT * FROM news WHERE section = 'televisions' order by id DESC LIMIT 2");
	
	while($fetch_tele = $select_tele -> fetch_assoc()){
		$tele_img = $fetch_tele['image'];
		$tele_title = $fetch_tele['title'];
		$tele_id = $fetch_tele['id'];
		$strlen = strlen($tele_title_title);

		?>

				<!-- tele display-->
				<div class="tele_display">
					<a href="?action=tv_spec&sc=<?php echo $tele_id; ?>"><img src="<?php echo $tele_img ; ?>" width="100%" height="100%" /></a>
					<a href="?action=tv_spec&sc=<?php echo $tele_id; ?>"><div class="tele_name_container">
						<div class="tele_name">
							 <?php echo $tele_title; ?>
						</div>
					</div></a>
				</div>
				<?php } ?>
				<!-- tele display-->
				<div style="clear: both;"></div>

			</div>

			<div class="line"></div>
			<!--television ends-->
			<!-- see more begins-->
			<div class="see_more">
				<div class="see">see all Televisions <span> > </span></div>
				<div style="clear: both;"></div>
			</div>

			<!-- see more ends-->


			
		

		<?php } ?>
		</div>
		<!-- body container ends-->

		
			<!--footer begins-->
			<div class="footer">
				<form action="" method="post">
					<div class="form_container">
					<div class="foot_label"> <label for="foot_search">Search </label> </div>
					<div class="foot_input">
						<input type="text" id="foot_search" name="search_value" class="search_value">

						<button type="submit">Search</button>
						<div style="clear: both;"></div>
					</div>

				</div>
				<!-- sug box starts-->
				<div class="sug_box"></div>
				<!--sug box ends-->
				</form>
				<!-- connect begins-->
				<div class="connect_head">
					connect with us
				</div>
				<!--connect ends-->

				<!--connect icons-->
				<div class="connect_icon">
					<div class="connect_fb"><i class="fab fa-facebook-f"></i>
					</div>

					<div class="connect_tw">
						<i class="fab fa-twitter"></i>
					</div>

					<div class="connect_gplus"><i class="fab fa-google-plus-g"></i></div>
					<div style="clear: both;"></div>
				</div>
				<!--connect icons end-->

				<!--foot links -->
				<div class="foot_links">
					<ul>
						<li>SITE MAP</li>
						<li>PRIVACY POLICY</li>
						<li>DISCLAIMER</li>
						<li>CONTACT US</li>
						<div style="clear: both;"></div>
					</ul>
				</div>
				<!--foot links end-->

				<!--refrence-->
				<div class="reference">
				Copyright  &#169; 2018 MyEnvyNet. All Rights Reserved.
				</div>
				<!--refrence ends-->

			</div>
			<!--footer ends-->

	</div>



<script>
	$(document).ready(function(evt){
		$('.text_text img').css("display","none");	
	});
</script>
</body>
</html>
