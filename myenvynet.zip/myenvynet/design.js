$(document).ready(function(){
    

    $(window).click(function(evt){
       if(evt.target.className == 'menu_icon' || evt.target.className=='fa fa-bars'){
        $('.menu_link').show();
       }else{
        $('.menu_link').hide();
       }
    });


    $(window).click(function(evt){
       if(evt.target.className == 'gallery_more_icon' || evt.target.className=='fas fa-ellipsis-h'){
        $('.more_list').show();
       }else{
        $('.more_list').hide();
       }
    });


    $(window).click(function(evt){
       if(evt.target.className == 'spec_share' || evt.target.className=='fas fa-share-alt'){
        $('.spec_icon_others').show();
       }else{
        $('.spec_icon_others').hide();
       }
    });

  $('.search_icon').click((e) => {
    $('.search_value').focus();
  });

    $('.form').submit(function(evt){
        let name = $('.full_name').val();
        if(name == ''){
          $('.name_error').html('Please add a name');
          evt.preventDefault();
          $('.full_name').val("");
          $('.full_name').focus();
        }else{
          let regex = /^[a-zA-Z\s]+$/;
          let nameMatch = name.match(regex);
          if(!nameMatch){
            $('.name_error').html('Please add alphabets and space only. eg. William Steven');
            evt.preventDefault();
            $('.full_name').val("");
            $('.full_name').focus();
          }else if(nameMatch){
            let email = $('.email').val();
            if(email == ''){
                $('.email_error').html('Please add a valid email');
                evt.preventDefault();
                $('.email').val("");
                $('.email').focus();
            }else{
              let email_regex = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
              if (!email_regex.test(email)) {
                  $('.email_error').html('Please add a valid email');
                  evt.preventDefault();
                  $('.email').val("");
                  $('.email').focus();
               }else if (email_regex.test(email)){
                 let password = $('.password').val();
                  if(password == ''){
                    $('.password_error').html('Please enter a valid password');
                    evt.preventDefault();
                    $('.password').val("");
                    $('.password').focus();
                  }else{
                    if ( /[a-z]/.test(password)){
                      if(/[A-Z]/.test(password)){
                        if(/[0-9]/.test(password)){
                          if(password.length >= 6){
                            return true;
                          }else{
                             evt.preventDefault();
                             $('.password_error').html('Please enter a valid password');
                               $('.password').val("");
                               $('.password').focus();
                          }
                        }else{
                           evt.preventDefault();
                           $('.password_error').html('Please enter a valid password');
                             $('.password').val("");
                              $('.password').focus();
                        }
                      }else{
                         evt.preventDefault();
                         $('.password_error').html('Please enter a valid password');
                               $('.password').val("");
                                $('.password').focus();
                      }
                    }else{
                       evt.preventDefault();
                       $('.password_error').html('Please enter a valid password');
                             $('.password').val("");
                           $('.password').focus();
                    }
                  }
               }
                                     
            }
            
          }
        }


               
    });


    //sign in form code

    $('.sign_in_form').submit(function(evt){
      let email = $('.email').val();
      let email_regex = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;    
      //check if email is empty
      if(email == ''){
        $('.sign_in_email_error').html('Please enter a valid email');
        evt.preventDefault();
        $('.email').val('');
        $('.email').focus();
      }else if(!email_regex.test(email)){
         $('.sign_in_email_error').html('Please enter a valid email');
         evt.preventDefault();
         $('.email').val('');
         $('.email').focus();
      }else{
        let password = $('.password').val();
        if(password == ''){
          $('.sign_in_password_error').html('Please enter a valid password');
          evt.preventDefault();
          $('.password').val('');
          $('.password').focus();
        }
      }

    });
//sign in form ends

//comment  starts
  $('.comment_form').submit(function(evt){
      let comment = $('.comment').val();
      if(comment == ''){
        $('.comment_error').html('Please write something');
        $('.comment').focus();
        evt.preventDefault();
      }
  });
//comment ends


//reply pafe starts

  $('.reply_form').submit(function(evt){
    let reply = $('.reply').val();
    if(reply == ''){
      $('.reply_error').html("Please write something");
      evt.preventDefault();
      $('.reply').focus();a
    }else{
      return true;
    }
  });
//reply page ends

//compare page 

$('.compare_form').submit(function(e){
  let val_one = $('#dev_one').val();
  let val_two = $('#dev_two').val();
  let cat = $('.type_category').val();
  if(cat == ''){
    alert('Please select a category');
    e.preventDefault();
  }else if(val_one == val_two){
    alert("Please select Two different phones");
    e.preventDefault();
  }else if(val_one == '' || val_two == ''){
    alert('You must enter two values');
    e.preventDefault();
  }
});
//compare ends

// deal sort start
$('.deal_form').submit(function(e){
  let brand = $('.brands').val();
  if(brand == ''){
    alert('Please select a brand');
    e.preventDefault();
    //get prices
  }else{
      let store = $('.stores').val();
      if(store == ''){
        alert('please select a store');
        e.preventDefault();
      }
    }
  
});

$('.smart_deal_form').submit(function(e){
  let brand = $('.brands').val();
  if(brand == ''){
    alert('Please select a brand');
    e.preventDefault();
    //get prices
  }else{
      let store = $('.stores').val();
      if(store == ''){
        alert('please select a store');
        e.preventDefault();
      }else{
        let feature = $('.smart_feature').val();
      }
    }
  
});


$('.tv_deal_form').submit(function(e){
  let brand = $('.brands').val();
  if(brand == ''){
    alert('Please select a brand');
    e.preventDefault();
    //get prices
  }else{
      let store = $('.stores').val();
      if(store == ''){
        alert('please select a store');
        e.preventDefault();
      }else{
        let types = $('.tv_types').val();

      }
    }
  
});


$('.laptop_deal_form').submit(function(e){
  let brand = $('.brands').val();
  if(brand == ''){
    alert('Please select a brand');
    e.preventDefault();
    //get prices
  }else{
      let store = $('.stores').val();
      if(store == ''){
        alert('please select a store');
        e.preventDefault();
      }else{
        let types = $('.tv_types').val();
        
      }
    }
  
});


$('.speaker_deal_form').submit(function(e){
  let brand = $('.brands').val();
  if(brand == ''){
    alert('Please select a brand');
    e.preventDefault();
    //get prices
  }else{
      let store = $('.stores').val();
      if(store == ''){
        alert('please select a store');
        e.preventDefault();
      }else{
        let types = $('.tv_types').val();
        
      }
    }
  
});

$('.sound_deal_form').submit(function(e){
  let brand = $('.brands').val();
  if(brand == ''){
    alert('Please select a brand');
    e.preventDefault();
    //get prices
  }else{
      let store = $('.stores').val();
      if(store == ''){
        alert('please select a store');
        e.preventDefault();
      }else{
        let types = $('.tv_types').val();
        
      }
    }
  
});

//deal sort ends

$(".hider").click(function(evt){
            $(".rules_box").hide();
            $(".hider").hide();
            $(".revealer").show();
          });

          $(".revealer").click(function(evt){
            $(".rules_box").show();
            $(".revealer").hide();
            $(".hider").show();
          });

$(".publish_form").submit(function(evt){

            let post_title = $(".pub_post_title").val();
            let post_text = $("#summernote").val();

            if(post_title == '' || post_text == ''){
              alert("Please fiil all fields");
              evt.preventDefault();
            }else if(post_title.length > 60){
              alert("Please title should not be more than 60 alphabets");
              evt.preventDefault();
            }
          });

});