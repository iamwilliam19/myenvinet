<?php

	include('config.php');
	
	//fetch the comment details
	$comment = $_POST['comment_text'];
	$_SESSION['comment'] = $comment;
	$email = $_SESSION['email'];
	$table = $_GET['dir'];
	$id = $_GET['cp'];
	$title = $_GET['title'];
	$day = date("d");
	$month = date("m"); 
	$year = date("y");
	$hour = date("h");
	$min = date("i");
	$sec = date("s");
	$new_comment = trim($comment);
	
	
	//fetch commenter name
	$srch_name = $conn -> query("SELECT * FROM accounts WHERE email = '$email'");
	$fetch_det = $srch_name -> fetch_assoc();
	$name = $fetch_det['name'];
	
	//now we insert all this deyails into our comment table
	$insert_comment = $conn -> query("INSERT INTO comments (commenter,comment,dir_table,content_title,content_id,year,month,day,hour,minute,second)VALUES('$name','$new_comment','$table','$title','$id','$year','$month','$day','$hour','$min','$sec')");

	if($insert_comment){
		//unset the session comment
		unset($_SESSION["comment"]);
		header("location: ../index.php?action=view&remark=001&dir=$table&gv=$id");
	}
	
	
	
?>