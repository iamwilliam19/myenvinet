<?php
	include('config.php');

	$name = $_POST['name'];
	$email = $_POST['email'];
	$password = $_POST['password'];

	$_SESSION['name'] = $name;
	$_SESSION['email'] = $email;
	$_SESSION['password'] = $password;

	$find_email = $conn -> query("SELECT * FROM accounts WHERE email = '$email'");
		$row_count = mysqli_num_rows($find_email);

	//check if name is empty
	if($name == ''){
		
		header("location: ../index.php?action=sign_up&error=001");
		//check if name has a digit
	}else if (preg_match('~[0-9]+~', $name)) {
    	header("location: ../index.php?action=sign_up&error=001");
    	//check if email add is empty
	}else if($email == ''){
		header("location: ../index.php?action=sign_up&error=002");
		//check if email add is correctly written
	}elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		header("location: ../index.php?action=sign_up&error=002");
		//check if password is empty
	}else if($row_count > 0){
		header("location: ../index.php?action=sign_up&error=007");
	}else if($password == ''){
		header("location: ../index.php?action=sign_up&error=003");
		//check if password has upper case, lower case, a number and up to 6
	}else if(preg_match('~[0-9]~', $password) && preg_match('~[a-z]~', $password) && preg_match('~[A-Z]~', $password) && strlen($password) >= 6){
		
		//encrypt password
		$new_password = md5($password);
		//trim spaces from both end
		$new_name = trim($name);
		//change first character to upper case
		$mod_name = ucfirst($new_name);
		//insert details into data base
		$insert_detail = $conn -> query("INSERT INTO accounts (name,email,password)VALUES('$mod_name','$email','$new_password')");

		//redirect to sign in page
		if($insert_detail){
			header("location: ../index.php?action=sign_in&signal=01");
		}
		//else there is something wrong with password
	}else{
		header("location: ../index.php?action=sign_up&error=003");
	}





?>
