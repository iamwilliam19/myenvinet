<?php
	include('config.php');
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	//move all into session
	$_SESSION['email'] = $email;
	$_SESSION['password'] = $password;
	
	
	// find email
	$select_email = $conn -> query("SELECT * FROM accounts WHERE email = '$email'");
	$row_count = mysqli_num_rows($select_email);
	//fetch password
	$fetcher = $select_email -> fetch_assoc();
	$fetched_password = $fetcher['password'];

	//encrpyt what was given as password
	$encrpyted_password = md5($password);
	
	if($row_count < 1){
		header("location: ../index.php?action=sign_in&error=004");
	}else{

		 if($email == ''){
			header("location: ../index.php?action=sign_in&error=004");
		}else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			header("location: ../index.php?action=sign_in&error=004");
		}else{
			if($password == ''){
				header("location: ../index.php?action=sign_in&error=005");
			}else if($fetched_password != $encrpyted_password){
				header("location: ../index.php?action=sign_in&error=005");
			}else{
				header("location: ../index.php?action=home");
			}
		}
	}


	
?>