<?php
	include('config.php');
	$com_id = $_GET['cd'];
	$reply = $_POST['reply_text'];
	$_SESSION['reply'] = $reply;
	$email = $_SESSION['email'];

	//ferch the comment details
	$select_com = $conn -> query("SELECT * FROM comments WHERE id = '$com_id'");
	 $fet_datails = $select_com -> fetch_assoc();
	 $dir = $fet_datails['dir_table'];
	 $content_title = $fet_datails['content_title'];
	 $content_id = $fet_datails['content_id'];
	 $day = date("d");
	 $month = date("m"); 
	 $year = date("y");
	 $hour = date("h");
	 $min = date("i");
	 $sec = date("s");
	 $new_reply = trim($reply);

	 //fetch replyer details
	 $srch_name = $conn -> query("SELECT * FROM accounts WHERE email = '$email'");
	$fetch_det = $srch_name -> fetch_assoc();
	$name = $fetch_det['name'];


	//insert the reply
	$insert_reply = $conn -> query("INSERT INTO replys (comment_id,replyer,reply,content_id,content_title,dir_table,year,month,day,hour,minute,second)VALUES('$com_id','$name','$reply','$content_id','$content_title','$dir','$year','$month','$day','$hour','$min','$sec')");

	if($insert_reply){
		header("location: ../index.php?action=reply&com_id=$com_id&remark=002");
		unset($_SESSION['reply']);
	}
?>