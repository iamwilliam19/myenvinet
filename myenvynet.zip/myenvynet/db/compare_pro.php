<?php
	include("config.php");

    $valone = $_POST['dev_one'];
	$valtwo = $_POST['dev_two'];
	$cat = $_POST['category'];
	$_SESSION['valone'] = $valone;
	$_SESSION['valtwo'] = $valtwo;

	if($valone == '' || $valtwo == ''){
		header("location: ../index.php?action=compare&ed=008");
	}else{
		//find all list of phones
		$find = $conn -> query("SELECT * FROM  news WHERE section = '$cat' && title = '$valone'");
		//look for phone one
		$count_row = mysqli_num_rows($find);
		if($count_row == 0){
			header("location: ../index.php?action=compare&ed=002");
			//find phone two
		}else{
			
			$find_two = $conn -> query("SELECT * FROM news WHERE section = '$cat' && title = '$valtwo'");
			//look for phone two
			$count_row_two = mysqli_num_rows($find_two);
			if($count_row_two == 0){
					header("location: ../index.php?action=compare&ed=003");
			}else{
				// check if two phones are of same type
				if($valone == $valtwo){
					header("location: ../index.php?action=compare&ed=004");
				}else{
					//fetch image of phone one
					$fet_one = $conn -> query("SELECT * FROM news WHERE section = '$cat' && title = '$valone'");
					$fet_det_one = $fet_one -> fetch_assoc();
					$main_name_one = $fet_det_one['title'];
					$valone_img = $fet_det_one['image'];

					//fetch image of phone two
					$fet_two = $conn -> query("SELECT * FROM news WHERE section = '$cat' && title = '$valtwo'");
					$fet_det_two = $fet_two -> fetch_assoc();
					$valtwo_img = $fet_det_two['image'];
					$main_name_two = $fet_det_two['title'];
					
					//insert details into compared
					$insert_compared = $conn -> query("INSERT INTO compared (gadget_one,gadget_two,phone_one_image,phone_two_image)VALUES('$valone','$valtwo','$valone_img','$valtwo_img')");

					//go to result page
					header("location: ../index.php?action=result&gadget_one=$main_name_one&gadget_two=$main_name_two&category=$cat");
					
					//unset session
					unset($_SESSION['valone']);
					unset($_SESSION['valtwo']);	
				}
			}

		}
	}

?>