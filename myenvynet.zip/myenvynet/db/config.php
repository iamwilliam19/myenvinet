<?php
    session_start();

    //database connection
    $server = 'localhost';
    $username = 'root';
    $password = '';
    $db = 'myenvynet';

    $conn = new mysqli($server,$username,$password,$db)or die('error');
?>