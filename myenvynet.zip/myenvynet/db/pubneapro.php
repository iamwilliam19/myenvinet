<?php
	
	include("config.php");

	$section = $_GET['section'];
	$email = $_SESSION['email'];
	$title = $_POST['pub_title'];
	$data = $_POST['editordata'];
	$trim_title = trim($title);
	$main_title = mysqli_real_escape_string($conn,$trim_title);
	$_SESSION['text_title'] = $title;
	$_SESSION['data'] = $data;

	
	
	//extract src of first image
	// create a new dom object
		$doc = new DOMDocument();
		//use the object to load our string
		$doc -> loadHTML($data);
		//create an xpath to tranverse the dom
		$selector = new DOMXpath($doc);
		//select img as choice object
		$result = $selector -> query('//img');

		$img_count = 0;
		//count all matches

		$my_img_array = array();
		foreach($result  as $target){
			$img_count++;

			$img_att = $target->getAttribute('src');


			if($img_count == 1){
				$first_img = $img_att;
			}
		}

		//confirm presence of atleast one image
		if(!$img_count > 0 ){
			header("location: ../index.php?action=pubnea&report=001&section=$section");
		}else{

			//get time of post
			$day = date("d");
			$month = date("m"); 
			$year = date("y");
			$hour = date("H");
			$min = date("i");
			$sec = date("s");



			//get poster details
			$find = $conn -> query("SELECT * FROM accounts WHERE email = '$email'");
			
			$count_match = mysqli_num_rows($find);
			if($count_match < 1){
				?>

					<script type="text/javascript">
						alert('PLease you need to signin before posting');
						
						setTimeout(function() {
                         window.location.replace("../index.php?action=sign_in");
                    }, 2000);
					</script>

				<?php
			}else{
				$fet = $find -> fetch_assoc();
				$name = $fet['name'];
			
			$ins = $conn -> query("INSERT INTO news (title,image,content,section,poster,poster_rank,poster_email,year,month,day,hour,minute,second)VALUES('$title','$first_img','$data','$section','$name','member','$email','$year','$month','$day','$hour','$min','$sec')");



				if($ins){
					unset($_SESSION['data']);
					unset($_SESSION['text_title']);
					header("location: ../index.php?action=$section");
				}
			}
		}
	
?>