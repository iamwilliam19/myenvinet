<?php
	include("config.php");

	$brand = $_POST['brand'];
	$store = $_POST['store'];
	$price_one = $_POST['money_one'];
	$price_two = $_POST['money_two'];
    $feature = $_POST['feature'];	
    $type = $_POST['type'];
	$sender = $_GET['sender'];

	//find matches for selected stuff
if($sender == 'all'){
	if($brand == 'others' && $store == 'others'){
		$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two ");
	}else if($brand == 'others'){
		$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store' && price >= $price_one && price <= $price_two ");
	}else if($store == 'others'){
		$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two ");
	}else{
		$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two ");
	}
	$count_row = mysqli_num_rows($sel);
	if($count_row > 0){
		header("location: ../index.php?action=deals&branded=$brand&stored=$store&price_one=$price_one&price_two=$price_two&apply=001");
	}else{
		header("location: ../index.php?action=deals&fail=001");
	}	
}else if($sender == 'smart_deal'){
	if($brand == 'others' && $store == 'others'){
		if($feature != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && feature = '$feature' && category = 'phones' ");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && category = 'phones'");
		}
	}else if($brand == 'others'){
		if($feature != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' &&  store = '$store'  && price >= $price_one && price <= $price_two && feature = '$feature' && category = 'phones'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' &&  store = '$store' && price >= $price_one && price <= $price_two && category = 'phones'");
		}
	}else if($store == 'others'){
		if($feature != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' &&  brand = '$brand' && price >= $price_one && price <= $price_two && feature = '$feature' && category = 'phones'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && category = 'phones'");
		}
	}else{
		if($feature != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && feature = '$feature' && category = 'phones'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && category = 'phones'");
		}
	}

	$count_row = mysqli_num_rows($sel);
	 if($count_row > 0){
		header("location: ../index.php?action=smartdeals&branded=$brand&stored=$store&price_one=$price_one&price_two=$price_two&apply=001&feature=$feature");
	}else{
		header("location: ../index.php?action=smartdeals&fail=001");
	}
	
	 	
	
}else if($sender == 'tv_deal'){
	if($brand == 'others' && $store == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && types = '$type' && category = 'televisions' ");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && category = 'televisions'");
		}

	}else if($brand == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store'  && price >= $price_one && price <= $price_two && types = '$type' && category = 'televisions'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store' && price >= $price_one && price <= $price_two && category = 'televisions'");
		}

	}else if($store == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && types = '$type' && category = 'televisions'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && category = 'televisions'");
		}

	}else{
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && types = '$type' && category = 'televisions'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && category = 'televisions'");
		}

	}

	$count_row = mysqli_num_rows($sel);
	 if($count_row > 0){
		header("location: ../index.php?action=tvdeals&branded=$brand&stored=$store&price_one=$price_one&price_two=$price_two&apply=001&type=$type");
	}else{
		header("location: ../index.php?action=tvdeals&fail=001");
	}
	
	 
}else if($sender == 'laptop_deal'){
	if($brand == 'others' && $store == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && types = '$type' && category = 'laptops' ");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && category = 'laptops'");
		}

	}else if($brand == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store'  && price >= $price_one && price <= $price_two && types = '$type' && category = 'laptops'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store' && price >= $price_one && price <= $price_two && category = 'laptops'");
		}

	}else if($store == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && types = '$type' && category = 'laptops'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && category = 'laptops'");
		}

	}else{
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && types = '$type' && category = 'laptops'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && category = 'laptops'");
		}

	}

	$count_row = mysqli_num_rows($sel);
	 if($count_row > 0){
		header("location: ../index.php?action=laptopdeals&branded=$brand&stored=$store&price_one=$price_one&price_two=$price_two&apply=001&type=$type");
	}else{
		header("location: ../index.php?action=laptopdeals&fail=001");
	}

}else if($sender == 'speaker_deal'){
	if($brand == 'others' && $store == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && types = '$type' && category = 'speakers' ");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && category = 'speakers'");
		}

	}else if($brand == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store'  && price >= $price_one && price <= $price_two && types = '$type' && category = 'speakers'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store' && price >= $price_one && price <= $price_two && category = 'speakers'");
		}

	}else if($store == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && types = '$type' && category = 'speakers'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && category = 'speakers'");
		}

	}else{
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && types = '$type' && category = 'speakers'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && category = 'speakers'");
		}

	}

	$count_row = mysqli_num_rows($sel);
	 if($count_row > 0){
		header("location: ../index.php?action=speakerdeals&branded=$brand&stored=$store&price_one=$price_one&price_two=$price_two&apply=001&type=$type");
	}else{
		header("location: ../index.php?action=speakerdeals&fail=001");
	}

}else if($sender == 'sound_deal'){
	if($brand == 'others' && $store == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && types = '$type' && category = 'sounds' ");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && category = 'sounds'");
		}

	}else if($brand == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store'  && price >= $price_one && price <= $price_two && types = '$type' && category = 'sounds'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store' && price >= $price_one && price <= $price_two && category = 'sounds'");
		}

	}else if($store == 'others'){
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && types = '$type' && category = 'sounds'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && category = 'sounds'");
		}

	}else{
		if($type != ''){
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && types = '$type' && category = 'sounds'");
		}else{
			$sel = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && category = 'sounds'");
		}

	}

	$count_row = mysqli_num_rows($sel);
	 if($count_row > 0){
		header("location: ../index.php?action=sounddeals&branded=$brand&stored=$store&price_one=$price_one&price_two=$price_two&apply=001&type=$type");
	}else{
		header("location: ../index.php?action=sounddeals&fail=001");
	}
}
?>