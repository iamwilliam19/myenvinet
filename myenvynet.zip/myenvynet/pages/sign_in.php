<body>


	<!-- body container starts-->
		<div class="body_container">
			<!--sign links start-->
			<div class="sign_links">
				<a href="?action=sign_up"><div class="sign_up <?php if($myaction == 'sign_up'){echo 'sign_selected';} ?>">
					Sign up
				</div></a>

				<a href="?action=sign_in"><div class="sign_in <?php if($myaction == 'sign_in'){echo 'sign_selected';} ?> ">
					Sign in
				</div></a>
				<div style="clear: both;"></div>
			</div>
			<!--sign links end-->
			<?php 
				if($signal == 01){
			?>
			<div class="signal">
				<span>Congratulations!!</span> acoount created, you can now login
			</div>
		<?php } ?>

			<!--sign form box begin-->
			<div class="sign_form_box">
				<form action="db/sign_in_pro.php" method="post" class="sign_in_form">

					

					<label for="email">Email:</label>
					<?php 
						if($error == 004){
					?>
					<div class="sign_in_email_error">Email invalid or not existing</div>
				   <?php } ?>

				  

					<div class="sign_in_email_error"></div>
					<input type="text" name="email" placeholder="Enter email  eg. smith@gmail.com *" class="email"  id="email" value="<?php echo $_SESSION['email']; ?>" required />

					<label for="password">password:</label>
					<?php 
						if($error == 005){
					?>
					<div class="sign_in_password_error">Please enter a valid password</div>
				<?php } ?>
					<div class="sign_in_password_error"></div>
					<input type="password" name="password" placeholder="Enter a new password * eg.Smith122" class="password" id="password" value="<?php echo $_SESSION['password']; ?>" required style="width: 100%; height: 30px; border-radius: 5px; background-color: #FFFFD4;" />
					<div class="sign_form_dir">
						 Your password should contain at least one uppercase, one lower case , one number and a minimum of 6 characters.
					</div>

					<button type="submit" name="Create">Sign in</button>
				</form>

				<div class="sign_other">
					 Don't have an account already?  <a href="?action=sign_up">Create account</a>
				</div>
			</div>
			<!--sign form box ends-->



		</div>
		<!-- body container ends-->


</body>
</html>
