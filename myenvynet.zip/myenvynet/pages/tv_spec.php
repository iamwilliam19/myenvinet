<?php
	$tele_id = $_GET['sc'];
	

	//do selections
	$select_tele = $conn -> query("SELECT * FROM news  WHERE section = 'televisions' && id ='$tele_id'");
	
		$fetch_tele = $select_tele -> fetch_assoc();
		$tele_img = $fetch_tele['image'];
		$tele_title = $fetch_tele['title'];
		$tele_id = $fetch_tele['id'];
		$tele_brand = $fetch_tele['brand'];
		$tele_release_date = $fetch_tele['release_date'];
		$tele_version = $fetch_tele['version'];
		$tele_series = $fetch_tele['series'];
		$tele_name2 = $fetch_tele['name_2'];
		$tele_type = $fetch_tele['tv_type'];
		$tele_channel_tuner = $fetch_tele['tv_channel_tuner'];
		$tele_ram_type = $fetch_tele['ram_type'];
		$tele_link = $fetch_tele['link'];
		$tele_operating_power = $fetch_tele['operating_power'];
		$tele_face_rec = $fetch_tele['face_rec'];
		$tele_light_sensor = $fetch_tele['light_sensor'];
		$tele_ram_freq = $fetch_tele['freq'];
		$tele_cam_resolution = $fetch_tele['cam_resolution'];
		$tele_usb_port = $fetch_tele['usb_port'];
		$tele_pro_tech = $fetch_tele['pro_tech'];
		$tele_video_port = $fetch_tele['video_port'];
		$tele_head_phone_jack = $fetch_tele['head_phone_jack'];
		$tele_cache= $fetch_tele['cache'];
		$tele_blue_light = $fetch_tele['blue_light'];
		$tele_store = $fetch_tele['store'];
		$tele_price = $fetch_tele['price'];
		$tele_disccount = $fetch_tele['disccount'];
		$tele_best_deal = $fetch_tele['best_deal'];
		$tele_screen_refresh = $fetch_tele['screen_refresh'];
		$tele_dimming_tech = $fetch_tele['dimming_tech'];
		$tele_backlight = $fetch_tele['backlight'];
		$tele_viewing_angle = $fetch_tele['viewing_angle'];
		$tele_motion_inter = $fetch_tele['motion_inter'];
		$tele_smart_tv = $fetch_tele['smart_tv'];
		$tele_smart_tv_feat = $fetch_tele['smart_tv_feat'];
		$tele_manufacturer = $fetch_tele['manufacturer'];
		$tele_screen_size = $fetch_tele['screen_size'];
		$tele_flat_screen = $fetch_tele['flat_screen'];
		$tele_ops = $fetch_tele['ops'];
		$tele_three_d_tv = $fetch_tele['three_d_tv'];
		$tele_three_d_tv_glasses = $fetch_tele['three_d_tv_glasses'];
		$tele_mi_value = $fetch_tele['mi_value'];
		$tele_frame_Rate = $fetch_tele['frame_rate'];
		$tele_processor = $fetch_tele['pro'];
		$tele_video_signal = $fetch_tele['video_signal'];
		$tele_ram = $fetch_tele['ram'];
		$tele_vp_mode = $fetch_tele['vp_mode'];
		$tele_speaker_output = $fetch_tele['speaker_output'];
		$tele_int_mem = $fetch_tele['int_mem'];
		$tele_soud_effect = $fetch_tele['sound_effect'];
		$tele_cam = $fetch_tele['camera'];
		$tele_cable_port = $fetch_tele['cable_port'];
		$tele_battery = $fetch_tele['battery'];
		$tele_ethernet_port = $fetch_tele['ethernet_port'];
		$tele_other_high = $fetch_tele['other_high'];
		$tele_Dap = $fetch_tele['Dap'];
		$tele_add_port = $fetch_tele['add_port'];
		$tele_design = $fetch_tele['design'];
		$tele_LAN = $fetch_tele['LAN'];
		$tele_stand_by = $fetch_tele['stand_by'];
		$tele_power_saving = $fetch_tele['power_saving'];
		$tele_dimension = $fetch_tele['dimension'];
		$tele_req_voltage = $fetch_tele['req_voltage'];
		$tele_req_freq = $fetch_tele['req_freq'];
		$tele_power_add_feat = $fetch_tele['power_add_feat'];
		$tele_wall_mount = $fetch_tele['wall_mount'];
		$tele_tv_stand = $fetch_tele['tv_stand'];
		$tele_config_others = $fetch_tele['config_others'];
		$tele_in_box = $fetch_tele['in_box'];
		$tele_other_comp_acc = $fetch_tele['other_comp_acc'];
		$tele_weight = $fetch_tele['weight'];
		$tele_lang_sup = $fetch_tele['lang_sup'];
		$tele_liscence = $fetch_tele['liscence'];
		$tele_other_spec = $fetch_tele['other_spec'];
		$tele_other_image_feat = $fetch_tele['other_image_feat'];

		$tele_other_audio_feat = $fetch_tele['other_audio_feat'];
		$tele_other_cam_feat = $fetch_tele['other_cam_feat'];
		$tele_aspect_ratio = $fetch_tele['aspect_rat'];
		$tele_disp_type = $fetch_tele['disp_type'];
		$tele_resolution = $fetch_tele['resolution'];
		$tele_pixel_den = $fetch_tele['pixel_den'];
		$tele_cont_ratio = $fetch_tele['cont_ratio'];
		$tele_edge_disp = $fetch_tele['edge_disp'];
		$tele_triluminos = $fetch_tele['triluminos'];
		$tele_color_sat = $fetch_tele['color_sat'];
		$tele_brightness = $fetch_tele['brightness'];
		$tele_hd_comp = $fetch_tele['hd_comp'];
		$tele_three_d_touch = $fetch_tele['three_d_touch'];
		
		$tele_wide_color = $fetch_tele['wide_color'];
		
		$tele_pixel_resp = $fetch_tele['pixel_resp'];
		
		$tele_curved_screen = $fetch_tele['curved_screen'];
	
		
		
		$tele_ui = $fetch_tele['ui'];
		
		$tele_graphic_pro = $fetch_tele['graphic_pro'];
		$tele_gpu = $fetch_tele['gpu'];
		$tele_soc = $fetch_tele['soc'];
		$tele_isa = $fetch_tele['isa'];
	
		$tele_cpu = $fetch_tele['cpu'];
		$tele_co_pro = $fetch_tele['co_pro'];
		$tele_ram_type = $fetch_tele['ram_type'];
		$tele_ram_channel = $fetch_tele['ram_channel'];
		$tele_freq = $fetch_tele['freq'];
		$tele_mem_type = $fetch_tele['mem_type'];
		$tele_mem_card = $fetch_tele['mem_card'];
		$tele_front_cam = $fetch_tele['front_cam'];
		$tele_sensor_mod = $fetch_tele['sensor_mod'];
		$tele_vid_rec = $fetch_tele['vid_rec'];
	
		$tele_sensor_type = $fetch_tele['sensor_type'];
		$tele_cam_feat = $fetch_tele['cam_feat'];
		$tele_vid_format = $fetch_tele['vid_format'];
		$tele_vid_format = $fetch_tele['aud_format'];
		$tele_img_format = $fetch_tele['img_format'];
		$tele_aud_format = $fetch_tele['aud_format'];
		$tele_speaker = $fetch_tele['speaker'];
		$tele_microphone = $fetch_tele['microphone'];
		
		
		
		$tele_wifi = $fetch_tele['wifi'];
		$tele_wifi_feature = $fetch_tele['wifi_feature'];
		$tele_bluetooth = $fetch_tele['bluetooth'];
		
		$tele_other_con = $fetch_tele['other_con'];
		$tele_usb_port = $fetch_tele['usb_port'];
		$tele_Ddi = $fetch_tele['Ddi'];
		
		
		$tele_other_sensors = $fetch_tele['other_sensors'];
		
		

		
		$tele_others = $fetch_tele['others'];
		
		$tele_service_temp = $fetch_tele['service_temp'];
		
		$tele_support = $fetch_tele['support'];
		$tele_war_type = $fetch_tele['war_type'];
		$tele_colors = $fetch_tele['color'];
		$tele_price = $fetch_tele['price'];
		
		$tele_screen_to_body = $fetch_tele['screen_to_body'];
		
		$strlen = strlen($tele_title);


?>


<!-- body container starts-->
<div class="body_container">
	<!--spec links box begins -->
	<div class="spec_links">
		<div class="spec_links_box">
		 <ul class="spec_ul">
		 	<a href="?action=tv_spec&sc=<?php echo $tele_id; ?>"><li class="spec_selected">Specs</li></a>
		 	<a href="?action=tv_pics&sc=<?php echo $tele_id; ?>"><li>Pictures</li></a>
		 	<li>Reviews</li>
		 	<li>Comments</li>
		 </ul>
		 <div style="clear: both;"></div>
		</div>
	</div>
	<!--spec link box ends-->

	<!--spec title-->
	<div class="spec_title">
		<h3><?php echo $tele_title ?></h3>
	</div>
	<!--spec title ends-->

	<!--spec image-->
	<div class="spec_img">
		<img src="<?php echo $tele_img ?>" width="100%" height="100%" />
	</div>
	<!--spec image ends -->

	<!--specicons-->
	<div class="spec_icons">
		<div class="spec_i">
			<i class="fab fa-facebook-f"></i>
		</div>

		<div class="spec_i">
			<i class="fab fa-twitter"></i> 
		</div>

		<div class="spec_i spec_share">
			<i class="fas fa-share-alt"></i> 
		</div>

		<div style="clear: both;"></div>

		<!-- spec icon others begin-->
		<div class="spec_icon_others">
			<div class="spec_stumble">
				<i class="fab fa-stumbleupon"></i>
			</div>

			<div class="spec_redit">
				<i class="fab fa-reddit-alien"></i>
			</div>

			<div class="spec_messenger">
				<i class="fab fa-facebook-messenger"></i>
			</div>

			<div class="spec_gplus">
				<i class="fab fa-google-plus-g"></i>
			</div>
		</div>
		<!--spec icon others ends-->

	</div>
	<!--spec icons ends-->

	<!--spec extra begins-->
	<div class="spec_extra">
		<!-- pec extra left-->
		<div class="spec_extra_left">
			<div class="left_fav">
				<div class="left_left">
				Add to favourites

				</div>

				<div class="left_right">
					<i class="fab fa-gratipay"></i>
				</div>

				<div style="clear: both;"></div>
			</div>

			<div class="right_fav">
				20 fans
			</div>

			<div style="clear: both;"></div>
		</div>
		<!--spec extra left ends-->

				<!-- pec extra right-->
		<div class="spec_extra_right">
			<div class="hit_box">
				100 hits
		    </div>
		</div>
		<!--spec extra right ends-->
		<div style="clear: both;"></div>
	</div>
	<!--spec extra ends-->

	
	
	<!--main spec box-->
	<div class="main_spec_box">
		<?php
			if($tele_release_date != '' || $tele_version != '' || $tele_series != '' || $tele_name2 != '' || $tele_manufacturer != ''){
		?>
		<div class="sub_spec_info">
			<h3>Key information</h3>
		</div>
	<?php } ?>
		<!--realse date-->
		<?php

			if($tele_release_date != ''){
		 ?>
		
		<div class="sub_spec_box">
		<div class="sub_spec_title">
			Release date:
		</div>

		<div class="sub_spec_ans">
			<?php echo $tele_release_date; ?>
		</div>
	</div>
	<?php } ?>
		<!--release date ends-->

		<!--realse date-->
		<?php

			if($tele_version != ''){
		 ?>
		
		<div class="sub_spec_box">
		<div class="sub_spec_title">
			Model:
		</div>

		<div class="sub_spec_ans">
			<?php echo $tele_version; ?>
		</div>
	</div>
	<?php } ?>
		<!--release date ends-->

	<!--name2-->

	<?php

			if($tele_name2 != ''){
		 ?>
		
		<div class="sub_spec_box">
		<div class="sub_spec_title">
			Also known as:
		</div>

		<div class="sub_spec_ans">
			<?php echo $tele_name2; ?>
		</div>
	</div>
		

	<?php } ?>
	<!--name2 ends-->
		

	<!--manufacturer-->

	<?php

			if($tele_manufacturer != ''){
		 ?>
		
		<div class="sub_spec_box">
		<div class="sub_spec_title">
			Manufacturer:
		</div>

		<div class="sub_spec_ans">
			<?php echo $tele_manufacturer; ?>
		</div>
	</div>
		

	<?php } ?>
	<!--manufacturer ends-->

<!--highlight table-->
<?php
			if($tele_screen_size != '' || $tele_hd_comp != '' || $tele_motion_inter != '' || $tele_screen_refresh != '' || $tele_type != '' || $tele_Ddi != '' || $tele_channel_tuner != '' || $tele_other_high != ''){
		?>
	<div class="sub_spec_info">
			<h3>Highlights</h3>
		</div>
<?php } ?>
		<!-- screen-->
		<?php

			if($tele_screen_size != ''){
		 ?>
		<div class="table" >
			<div class="row">
				<div class="col_1">
					<strong>Screen size, display type &amp; resolution: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_screen_size; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--screen ends-->

		<!-- pro-->
		<?php

			if($tele_hd_comp != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>HDR Compliant: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_hd_comp; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--pro ends-->

		<!-- pro-->
		<?php

			if($tele_motion_inter != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Motion interpolation technology: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_motion_inter; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--pro ends-->


		<!-- pro-->
		<?php

			if($tele_screen_refresh!= ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Screen refresh rate: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_screen_refresh; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--pro ends-->

		<!-- ops-->
		<?php

			if($tele_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>TV type: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--ops ends-->

		<!-- ops-->
		<?php

			if($tele_Ddi != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Digital display interface: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_Ddi; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--ops ends-->

		<!-- ops-->
		<?php

			if($tele_channel_tuner != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>TV channel tuner: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_channel_tuner; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--ops ends-->

		<!-- ops-->
		<?php

			if($tele_other_high != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other highlights: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_other_high; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--ops ends-->

		<!-- ram-->
		<?php

			if($tele_store!= '' && $tele_price != '' && $tele_disccount != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Best deal: </strong>
				</div>
				<div class="col_2">
					Buy at <?php echo ' '.$tele_store. '  $' .$tele_price. ', ' .$tele_disccount. '% OFF'; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--ram ends-->

		<div class="best_deal">
			Buy
		</div>

		<div class="full_spec"><h3>Full specification</h3></div>

<?php
			if($tele_screen_size != '' || $tele_hd_comp != '' || $tele_design != '' || $tele_dimension != '' || $tele_weight != '' || $tele_Ddi != '' || $tele_aspect_ratio != '' || $tele_screen_to_body != '' || $tele_disp_type != '' || $tele_resolution != '' || $tele_pixel_den != '' || $tele_cont_ratio != '' || $tele_dimming_tech != '' || $tele_triluminos != '' || $tele_color_sat != '' || $tele_brightness != '' || $tele_backlight != '' || $tele_hd_comp != '' || $tele_wide_color != '' || $tele_blue_light != '' || $tele_viewing_angle != '' || $tele_other_spec != ''){
		?>

		<div class="sub_spec_info">
			<h3>Size &amp; Display features</h3>
		</div>
<?php }?>
		<!-- begin-->
		<?php

			if($tele_design != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Design: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_design; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_screen_size != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Screen size: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_screen_size; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_dimension != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Dimension: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_dimension; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_weight != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Weight: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_weight; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_screen_to_body != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Screen to body ratio: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_screen_to_body; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_aspect_ratio != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Aspect ratio: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_aspect_ratio; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_disp_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Display type: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_disp_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_resolution != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Resolution: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_resolution; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_pixel_den != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Pixel density: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_pixel_den; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_cont_ratio != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Contrast ratio: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_cont_ratio; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- ram-->
		<?php

			if($tele_dimming_tech != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Dimming technology: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_dimming_tech; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		

		<!-- begin-->
		<?php

			if($tele_triluminos != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Triluminos display: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_triluminos; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_color_sat != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Color saturation (NTSC): </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_color_sat; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_brightness != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Brightness level: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_brightness; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- ram-->
		<?php

			if($tele_backlight != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Backlight: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_backlight; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- begin-->
		<?php

			if($tele_hd_comp != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>HDR compliant: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_hd_comp; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
		

		<!-- begin-->
		<?php

			if($tele_wide_color != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Wide color gamut display: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_wide_color; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- ram-->
		<?php

			if($tele_blue_light != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Blue light filter (for eye care): </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_blue_light; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- begin-->
		<?php

			if($tele_viewing_angle != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Viewing angle: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_viewing_angle; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		

		<!-- begin-->
		<?php

			if($tele_other_spec != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other features: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_other_spec; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		

		
<?php 
	if($tele_smart_tv != '' || $tele_ops != '' || $tele_smart_tv_feat != '' || $tele_flat_screen != '' || $tele_curved_screen != '' || $tele_three_d_tv != '' || $tele_three_d_tv_glasses != ''){
?>

		<div class="sub_spec_info">
			<h3>TV type</h3>
		</div>
<?php } ?>

		<!-- begin-->
		<?php

			if($tele_smart_tv != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Smart tv: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_smart_tv; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_ops != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Operating system: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_ops; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_smart_tv_feat != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Smart Tv features: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_smart_tv_feat; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_flat_screen != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Flat screen: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_flat_screen; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_curved_screen != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Curved screen: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_curved_screen; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_three_d_tv != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>3D Tv: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_three_d_tv; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_three_d_tv_glasses != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>3D Tv glasses: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_three_d_tv_glasses; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php 
	if($tele_motion_inter != '' || $tele_mi_value != '' || $tele_screen_refresh != '' || $tele_pixel_resp != '' || $tele_frame_Rate != '' || $tele_video_signal != '' || $tele_channel_tuner != '' || $tele_vp_mode != '' || $tele_other_image_feat != '' ){
?>
		<div class="img_pro"><h3>Image processing &amp; features</h3></div>
<?php 
}
?>
		<!-- begin-->
		<?php

			if($tele_motion_inter != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Motion interpolation tehnology: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_motion_inter; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_mi_value != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>MI value: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_mi_value; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_screen_refresh != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Screen refresh rate: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_screen_refresh; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_pixel_resp != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Pixel response time: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_pixel_resp; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_frame_Rate != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Frame rate control: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_frame_Rate; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_video_signal != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Video signal: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_video_signal; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_channel_tuner != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Tv channel tunner: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_channel_tuner; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_vp_mode != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Video &amp; picture modes: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_vp_mode; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_other_image_feat != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other features: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_other_image_feat; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php 
	if($tele_vid_format != '' || $tele_aud_format != '' || $tele_img_format != ''){
?>
		<div class="video"><h3>Video, Audio & Image formats</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_vid_format != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Video format and codecs: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_vid_format; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_aud_format != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Audio format and codecs: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_aud_format; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_img_format != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Image format and codecs: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_img_format; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
		<?php 

			if($tele_speaker != '' || $tele_speaker_output != '' || $tele_soud_effect != '' || $tele_microphone != '' || $tele_other_audio_feat != ''){

		?>

		<div class="audio"><h3>Audio, speaker & mic</h3></div>

<?php } ?>

		<!-- begin-->
		<?php

			if($tele_speaker != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Speaker: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_speaker; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_speaker_output != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Speaker output: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_speaker_output; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_soud_effect != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Sound effects: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_soud_effect; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_microphone != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Microphone: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_microphone; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_other_audio_feat != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other audio features: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_other_audio_feat; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->
<?php 
	if($tele_usb_port != ''|| $tele_head_phone_jack != '' || $tele_Ddi != '' || $tele_video_port != '' || $tele_cable_port != '' || $tele_ethernet_port != '' || $tele_Dap != '' || $tele_add_port != ''){
?>
		<div class="port"><h3>Ports</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_usb_port != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>USB port: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_usb_port; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_head_phone_jack != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Head phone jack: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_head_phone_jack; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		
		<!-- begin-->
		<?php

			if($tele_Ddi != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Digital display interface: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_Ddi; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_video_port != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Video port: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_video_port; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_cable_port != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Cable port: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_cable_port; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_ethernet_port != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Ethernet port: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_ethernet_port; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_Dap != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Digital audio port: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_Dap ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_add_port != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Additional port: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_add_port; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php
	if($tele_wifi != '' || $tele_wifi_feature != '' || $tele_bluetooth != '' || $tele_LAN != '' || $tele_other_con != ''){
?>
		<div class="connect"><h3>Network Connectivity</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_wifi != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>WI-FI: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_wifi; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_wifi_feature != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>WI-FI features: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_wifi_feature; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		
		

		<!-- begin-->
		<?php

			if($tele_bluetooth != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Bluetooth: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_bluetooth; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		

		<!-- begin-->
		<?php

			if($tele_LAN != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Local Area Network: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_LAN; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		

		<!-- begin-->
		<?php

			if($tele_other_con != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other connectivity features: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_other_con; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<?php 
			if($tele_graphic_pro != '' || $tele_gpu != '' || $tele_soc != '' || $tele_isa != '' || $tele_pro_tech != '' || $tele_cache!= '' || $tele_cpu != '' || $tele_co_pro != ''){
		?>

		<div class="processor"><h3>Processor</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_graphic_pro != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Graphics processor: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_graphic_pro; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_gpu != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>GPU frequency: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_gpu; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_soc != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>System-on-Chip {SoC}: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_soc; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_isa != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Instruction Set Architecture {ISA}: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_isa; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_pro_tech != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Process technology: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_pro_tech; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_cache != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Cache memory: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_cache; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		

		<!-- begin-->
		<?php

			if($tele_cpu != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>C.P.U: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_cpu; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_co_pro != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Core processor: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_co_pro; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php
	if($tele_ram != '' || $tele_ram_type != '' || $tele_ram_channel != '' || $tele_ram_freq != '' || $tele_int_mem != '' || $tele_mem_type != '' || $tele_mem_card != ''){
 ?>
		<div class="ram_and_mem"><h3>RAM and Memory</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_ram != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Random access memory size : </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_ram; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_ram_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>RAM type : </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_ram_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_ram_freq != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Frequency : </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_ram_freq; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_ram_channel != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>RAM channel : </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_ram_channel; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		

		<!-- begin-->
		<?php

			if($tele_int_mem != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Internal memory: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_int_mem; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_mem_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Memory type: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_mem_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_mem_card != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Memory card support: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_mem_card; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php

	if($tele_operating_power != '' || $tele_stand_by != '' || $tele_power_saving != '' || $tele_req_voltage != '' || $tele_req_freq != '' || $tele_power_add_feat != ''){

?>
		<div class="camera"><h3>Power consumption</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_operating_power != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Operating power: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_operating_power; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_stand_by != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Stand-by: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_stand_by; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_power_saving != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Power saving: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_power_saving; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_req_voltage != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Required voltage: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_req_voltage; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_req_freq != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Required frequency: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_req_freq; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_power_add_feat != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Additional features: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_power_add_feat; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php

	if($tele_cam_resolution != '' || $tele_sensor_type != '' || $tele_sensor_mod != '' || $tele_other_cam_feat != '' || $tele_vid_rec != ''){

?>
		<div class="camera"><h3>Camera</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_cam_resolution != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Camera resolution: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_cam_resolution; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		
		<!-- begin-->
		<?php

			if($tele_sensor_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Sensor type: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_sensor_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_sensor_mod != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Sensor model: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_sensor_mod; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_cam_feat != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Features: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_cam_feat; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_vid_rec != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Video recording: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_vid_rec; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
<?php

	if($tele_wall_mount != '' || $tele_tv_stand != '' || $tele_config_others != ''){

?>
		
		<div class="sensor"><h3>User-friendly configuration</h3></div>		
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_wall_mount != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Wall mounting(VESA): </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_wall_mount; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_tv_stand != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Tv stand: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_tv_stand; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_config_others != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other features: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_config_others; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
		<?php

			if($tele_light_sensor != '' || $tele_face_rec != '' || $tele_other_sensors != ''){

		?>

		<div class="sensor"><h3>Sensors</h3></div>
<?php } ?>
		<?php

			if($tele_light_sensor != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Light sensors: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_light_sensor; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<?php

			if($tele_face_rec != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Face recognition: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_face_rec; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->




		

		<!-- begin-->
		<?php

			if($tele_other_sensors != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other sensors: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_other_sensors; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
<?php 
	
	if($tele_in_box != '' || $tele_other_comp_acc != ''){
 ?>
		<div class="other_feat"><h3>Accessories</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_in_box != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>In the box: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_in_box; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
		
		<!-- begin-->
		<?php

			if($tele_other_comp_acc != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other compatible accessories: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_other_sensors; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
<?php 

	if($tele_lang_sup != '' || $tele_service_temp != '' || $tele_liscence != '' || $tele_others != ''){
?>
		<div class="other_feat"><h3>Other features</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_lang_sup != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Language support: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_lang_sup; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
		
		
		
		<!-- begin-->
		<?php

			if($tele_service_temp != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>In service temperature: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_service_temp; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_liscence != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Liscence &amp; certificates: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_liscence; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_others != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other features: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_others; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		

		
<?php 

	if($tele_support != '' || $tele_war_type != ''){
?>
		<div class="sup"><H3>Support and Warranty</H3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_support != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Support: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_support; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_war_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Warranty type: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_war_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
<?php
	if($tele_colors != '' || $tele_price != ''){
?>
		<div class="color_price"><h3>Color and Price</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($tele_colors != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Colors: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_colors; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($tele_price != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Price: </strong>
				</div>
				<div class="col_2">
					<?php echo $tele_price; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<!-- table box ends-->
	</div>
	<!--main spec box ends-->

	<!--spec disclaimer box-->
	<div  class="spec_disclaimer_box">
		<span>Disclaimer:</span> We like to admit that the specs of the product above may not be 100% correct. To suggest an edit, contact us <a href="#"  style="color: #2A6BA6;">here</a>. <a href="?action=disclaimer" style="text-decoration: underline;">Read full Disclaimer</a>.
	</div>
	<!--spec disclimer box ends-->
	
<div class="dealer_match">
	<?php
		$match = $conn -> query("SELECT * FROM news WHERE section = 'deals' && title = '$tele_title' ");
		if($match){
			$ct = mysqli_num_rows($match);
			if($ct == 1){
				$fetch_deal = $match -> fetch_assoc();
				$deal_img = $fetch_deal['image'];
				$deal_title = $fetch_deal['title'];
				$deal_content = $fetch_deal['content'];
				$deal_date = $fetch_deal['date'];
				$deal_poster = $fetch_deal['poster'];
				$deal_disccount = $fetch_deal['disccount'];
				$deal_store = $fetch_deal['store'];
				$deal_price = $fetch_deal['price'];
				$deal_id = $fetch_deal['id'];
				$deal_link = $fetch_deal['link'];
				$deal_category = $fetch_deal['category'];
				$strlen = strlen($deal_title);
				$txt_strlen = strlen($deal_content);
?>
			<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="hot_main_display">
					<!--main title-->
					<div class="hot_main_title">
						<?php echo substr($deal_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
					</div>
					<!-- main title ends-->
					<!-- hot img box-->
					<div class="hot_image_box">
						<img src="<?php echo $deal_img; ?>" width="100%" height="100%"/>
						<?php if($deal_disccount != ''){ ?>
						<div class="hot_extra"><?php echo $deal_disccount; ?>% 0FF</div>
							<?php } ?>
					</div>
					<!-- hot image box ends-->
					<?php if($deal_price != '' && $deal_store != ''){ ?>
					<div class="hot_price">
						<span>$<?php echo $deal_price; ?></span> (at <?php echo $deal_store; ?>)
					</div>
					<?php } ?>

					<div class="hot_txt"><?php echo substr( $deal_content,0,210); if($txt_strlen > 210){echo '...';} ?> </div>
					<?php 
						$find_cat = $conn -> query("SELECT * FROM $deal_category WHERE title = '$deal_title' ");
						if($find_cat){
						$count_cat = mysqli_num_rows($find_cat);
						if($count_cat == 1){
					?>

					<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="details_link">Check details... </div></a>
				<?php } } ?>
				
					
				</div></a>

<?php
			}
		}
	?>
</div>

<!-- see more begins-->
			<a href="?action=deals"><div class="see_more">
				<div class="see">see all deals<span> > </span></div>
				<div style="clear: both;"></div>
			</div></a>

			<!-- see more ends-->


	<!--related tele box-->
	<div class="related_tele_box">
		<div   class="related_title">
			<h3>Related televisions</h3>
		</div>

		<!--related display box starts-->
		<div class="related_display_box">
			<?php 
				// select related tele
				$related_tele = $conn -> query("SELECT * FROM news WHERE section = 'televisions' && brand = '$tele_brand' && id != '$tele_id' ");

				$count_display = 0;
				while($fetch_related = $related_tele -> fetch_assoc()){

					$related_img = $fetch_related['image'];
					$related_name = $fetch_related['title'];

					$count_display++;
			?>
			<!--related display beigns-->
			<div class="related_display">
				
				<img src="<?php echo $related_img; ?>" width="100%" height="100%" />

				<!--tele name-->
				<div class="related_name">
					<?php echo $related_name; ?>
				</div>
				<!--tele name ends-->
			</div>
			<!--related display ends-->



			<?php 
					//echo line
				   	if($count_display == 2){
				   		echo "<div class='display_line'></div>";
				   		$count_display = 0;
				   	}
		    	}
		   ?>



			<div style="clear: both;"></div>
		</div>
		<!-- related display box ends-->

	</div>
	<!--related tele box ends-->

	<!-- see all  starts -->
	<div class="related_seeAll_box">
		see all <?php echo $tele_brand; ?> televisions <span> > </span>
	</div>
	<!-- see all ends-->

		
</div>
<!-- body container ends-->

