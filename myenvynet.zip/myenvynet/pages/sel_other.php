
	<!-- body container starts-->
		<div class="body_container">
			
			<!--publish conatainer starts-->
			<div>
				<!--selpage title starts-->
				<div class="sel_page_title"><h4>Select a section to publish on</h4></div>
				<!--sel page title ends-->
				<!--sections box start-->
				<div class="section_box">
					<!--section sub box starts-->
					<a href="?action=pubnea&section=news_feed">
					<div class="section_sub_box">
						<div class="section_sect1">
							News: publish news on smartphones & TVs 
						</div>

						<div class="section_sect2">
							>
						</div>
						<div style="clear: both;"></div>
					</div>
				</a>
					<!--section sub box ends-->

					<!--section sub box starts-->
					<div class="section_sub_box">
						<div class="section_sect1">
							Reviews: Publish reviews on any smartphone/TV 
						</div>

						<div class="section_sect2">
							>
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--section sub box ends-->
					<!--section sub box starts-->
					<a href="?action=pubnea&section=articles">
					<div class="section_sub_box">
						<div class="section_sect1">
							Articles: publish articles on smartphones & TVs 
						</div>

						<div class="section_sect2">
							>
						</div>
						<div style="clear: both;"></div>
					</div>
				</a>
					<!--section sub box ends-->
					<!--section sub box starts-->
					<a href="?action=pubnea&section=how_to">
					<div class="section_sub_box">
						<div class="section_sect1">
							How-Tos: publish how to make use of smartphone or TV features and apps, how to jail break/root smartphones, how to perform smartphone/TV repairs, etc.	


						</div>

						<div class="section_sect2" >
							>
						</div>
						<div style="clear: both;"></div>
					</div>
				</a>
					<!--section sub box ends-->
					<!--section sub box starts-->
					<div class="section_sub_box">
						<div class="section_sect1">
							Gallery: upload smartphone/TV related pictures- camera samples of different smartphones & Televisions, smartphone & TV exhibitions, etc.

						</div>

						<div class="section_sect2" >
							>
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--section sub box ends-->
				</div>
				<!--sections box end-->

				<div class="pub_write_up" style="margin-top: 30px">
					
					<p>
						<span style="font-weight: 600">Please note:</span> topics which look like this- 'How to make $400,000 online' are not allowed on a strict basis. You need to identify the exact strategy for making the said money/amount online. E.g. 'how to be a billionaire buying and selling bitcoins' Alright, you also have to make sure its tech related too. 
					</p>
				</div>
				<!--pub others end-->
			</div>

			<!--publish container ends-->
			
		</div>
		<!-- body container ends-->
