<?php

$error = $_GET['ed'];

?>
<body>
	<!-- body container starts-->
		<div class="body_container">

			<div class="compare_title">
				Compare devices
			</div>

			<div class="line"></div>

			<form action="db/compare_pro.php" method="post" class="compare_form">

				<div class="brand_type_box">
					<div class="brand_type">
					<select class="type_category" name="category">
						<option value="">Category</option>
						<option value="phones">Phones</option>
						<option value="televisions">Televisions</option>
					</select>
				</div>
				</div>

			<!--compare box-->
			<div class="compare_box">
				<?php if($error == 001){?>
				<div class="dev_error">Please fill out all boxes</div>
			<?php }else if($error == 002){ ?>
				<div class="dev_error">No match for Gadget one</div>
			<?php }else if($error == 003){ ?>
			<div class="dev_error">No match for Gadget two</div>
		<?php }else if ($error == 004){ ?>
			<div class="dev_error">Please select two different Gadgets</div>
		<?php } ?>
				
					<div class="dev_1">
						<label for="dev_one" class="dev_num">1.</label>

						<input type="text" name="dev_one" placeholder="Enter device name" class="dev_one_value" id="dev_one" value="<?php echo $_SESSION['valone']; ?>" />
					</div>
					<div class="dev_2">
						<label for="dev_two" class="dev_num">2.</label>

						<input type="text" name="dev_two" placeholder="Enter device name" class="dev_two_value" id="dev_two" value="<?php echo $_SESSION['valtwo']; ?>" />
					</div>
					<div style="clear: both;"></div>	
					<div class="compare">
					<button type="submit" class="compare">
				      Compare
					</button>
				</div>
				
			</div>
			<!--compare_box ends -->
		</form>
			
		</div>
		<!-- body container ends-->


</body>
</html>
