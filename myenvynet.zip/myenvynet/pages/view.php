<?php  
	include('./db/config.php');
	$selected_id = $_GET['gv'];

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

</head>



<body>

	<?php 
	
		$g_view_select = $conn -> query("SELECT * FROM news WHERE section = '$dir' && id = '$selected_id' ") or die(error);
		$fetch_gview = $g_view_select -> fetch_assoc() or die('error in fetching details');
		$title = $fetch_gview['title'];
		$poster= $fetch_gview['poster'];
		$id = $fetch_gview['id'];
		
	?>


	<!-- body container starts-->
		<div class="body_container">
		
		<!--g_view starts -->
		<div class="g_view">
			<?php echo $title; ?>
		</div>
		<!-- g_view ends-->

		<!--view directory starts-->
		<div class="view_dir">
			<div class="dir_date">
				13Nov,2016 /  
			</div> 
			<div class="dir_home">
				HOME>> GALLERY /
			</div> 
			<div class="dir_comment">
				20 comments
			</div> 

			<div style="clear: both;"></div>
		</div>
		<!--view directory ends-->

		<!--gallery poster profile-->
		<div class="gallery_profile_container">
			<div class="gallery_poster_img">
				<img src="./images/profile.jpg" height="100%" width="100%" style="border-radius: 50px;" />
			</div>

			<div class="gallery_poster_name">
				<span>by</span> <?php echo $poster; ?> 
			</div>

			<div style="clear: both;"></div>
		</div>
		<!-- gallery profile ends-->

		<!-- share box-->
		<div class="share_box">
			<div class="share_count">
				<h3>30<br> shares</h3>
			</div>

			<!--gallery facebook share-->
			<div class="gallery_fb_share">
				<i class="fab fa-facebook-f"></i> <span> Share </span>
				<div style="clear: both;"></div>
			</div>

				<!--gallery facebook share ends-->

				<!--gallery twitter share-->
			<div class="gallery_tw_share">
				<i class="fab fa-twitter"></i> <span> Tweet </span>
				<div style="clear: both;"></div>
			</div>
				<!--gallery twitter share ends-->

					<!--gallery reddit share-->
			<div class="gallery_red_share">
				<i class="fab fa-reddit-alien"></i> <span> Post </span>
				<div style="clear: both;"></div>
			</div>
				<!--gallery reedit share ends-->

				<!--more icon-->
				<div class="gallery_more_icon">
					<i class="fas fa-ellipsis-h"></i>
				</div>
				<!--more icon ends-->
				<!--more list-->
				<div class="more_list">
					<!--gallery stummble-->
					<div class="gallery_stumble">
						<i class="fab fa-stumbleupon"></i> Share
					</div>
					<!--gallery stumble ends-->

					<!--gallery google-->
					<div class="gallery_google">
						<i class="fab fa-google-plus-g"></i> Share
					</div>
					<!--gallery google ends-->

					<!--gallery messenger-->
					<div class="gallery_messenger">
						<i class="fab fa-facebook-messenger"></i> Share
					</div>
					<!--gallery messenger ends-->
					<div style="clear: both;"></div>
				</div>
				<!--more list ends-->

				<div style="clear: both"></div>

				
		</div>
		<!--share box ends-->

		<!--gallery view flow begins-->
		<div class="gallery_view_flow">
			<?php
				$g_content= $fetch_gview['content'];
				echo $g_content;
				
				
		     

			?>
		</div>
		<!--gallery view flow ends-->

		<script type="text/javascript">
			$(document).ready(function(){
				var images = $('.gallery_view_flow img');
				$.each(images,function(index,value){
					var indexDigit = index + 1;
					var formattedNumber = ("0" + indexDigit).slice(-2);

					$('<div class="flow_counter">'+formattedNumber+'</div>').insertBefore(value);

					$('<br />').insertAfter(value);
					$(value).removeAttr('style');
				})
			});
		</script>

		<!--gallery view likes and n like-->
		<div class="gallery_like_box">
			<div class="gallery_likes">
				<i class="far fa-thumbs-up"></i> <span> 123</span>
			</div>

			<div class="gallery_unlikes">
				<i class="far fa-thumbs-down"></i> <span> 123</span>
			</div>

			<div style="clear: both;"></div>
		</div>
		<!--gallery view like ends-->

		<!--gallery_publish starts-->
			<div class="gallery_publish">
				Publish Here
			</div>
			<!-- gallery publish ends-->


		<!--about publisher starts-->
		<div class="about_publisher_box">
			<!--publiush title box-->
			<div class="publish_title_topic">
				<div class="publish_title_box">
					<div class="publish_title">
					About Publisher
				   </div>
			    </div>
			</div>
			<!--publish title box ends-->

			<!--publisher pic box-->
			<div class="pub_pic_box">
				<div class="pub_pic">
					<img src="./images/profile.jpg" width="90%" height="90%"  />
				</div>
			</div>
			<!--publisher pic box ends-->

			<!--pub_name begins-->
			<div class="pub_name">
			<?php echo $g_poster ;?> (member)
			</div>
			<!--pub name ends-->

			<!--pub bio begins-->
			<div class="pub_bio_box">
				<div class="g_bio_title">
					Bio:
				</div>

				<div class="g_bio_detail">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim venia

					<a href="#">view profile</a>
				</div>

				<div style="clear: both;"></div>
			</div>
			<!--pub bio ends-->
		</div>
		<!--about publisher ends-->

		<!--comments space-->
		<script type="text/javascript">
			let arrow = 0;
		</script>
		<?php 

			//select all required comments
			$select_com = $conn -> query("SELECT * FROM comments WHERE dir_table = '$dir' AND content_title = '$title' AND content_id = '$id' order by id DESC LIMIT 3 ");

			while ($fetched_com = $select_com -> fetch_assoc()) {
				$commenter = $fetched_com['commenter'];
				$commenter_img = $fetched_com['commenter_image'];
				$comment = $fetched_com['comment'];
				$commenter = $fetched_com['commenter'];
				$commenter_dir_table = $fetched_com['dir_table'];
				$comment_id = $fetched_com['id'];
				$year = $fetched_com['year'];
				$month = $fetched_com['month'];
				$day = $fetched_com['day'];
				$hour = $fetched_com['hour'];
				$min = $fetched_com['minute'];
				$sec = $fetched_com['second'];
				$strlen = strlen($comment);


		?>

		<div class="comment_space">
			<!--comment space head-->
			<div class="comment_space_head">
				<div class="commenter_space_img">
					<?php if($commenter_img != ''){?>
						<img src="<?php echo $commenter_img ;?>" width="100%" height="100%" />
					<?php } else{
							$firstchar = substr($commenter,0, 1);
						?>
							
						<div class="commenter_space_letter" id="<?php echo $comment_id; ?>"><?php echo strtoupper($firstchar);  ?></div>
						<script type="text/javascript">
							$(document).ready(function(){

								let colorArray = ['violet','indigo','pink','orange','purple'];
								
								let selected = arrow % 4;

								$('#<?php echo $comment_id; ?>').css('background-color',colorArray[selected]);
								arrow++;
							});
						</script>
						
					<?php } ?>
				</div>
				<div class="commenter_space_name"><?php echo $commenter ;?></div>
				<div class="commenter_space_date">today</div>

				<div style="clear: both;"></div>
			</div>
			<!--comment space head ends-->

			<!--comment space text begins-->
			<div class="comment_space_text" id="w<?php echo $comment_id; ?>">
				<?php echo substr($comment,0,200);
					if($strlen > 200){
					?>
					<span class="span">...more</span>
					<?php } ?>
			</div>
			<!-- comment space text ends-->

			<script type="text/javascript">
						$(document).ready((evt)=>{
							$('#w<?php echo $comment_id; ?> span').click((e)=>{
								$('#w<?php echo $comment_id; ?> span').hide();
								$('#w<?php echo $comment_id ;?>').append("<?php echo substr($comment, 200); ?>");
							});
						});
					</script>

			<!--commenter space others-->
			<div class="commenter_space_others">
				<div class="comment_space_like">
					<i class="far fa-thumbs-up"></i> <span> 123</span>
				</div>

				<div class="comment_space_unlike">
					<i class="far fa-thumbs-down"></i> <span> 123</span>
				</div>

				<a href="?action=reply&com_id=<?php echo $comment_id ?>"><div class="comment_space_reply">
					<i class="far fa-comment"></i> <span> Reply</span>
				</div></a>

				<div class="comment_space_report">
					<i class="fas fa-exclamation-triangle"></i> <span> Report</span>
				</div>


				<div style="clear: both;"></div>
			</div>
			<!--commenter space others ends-->

			<div class="line"></div>

		</div>
	<?php } ?>
		<!--comment space ends-->

		<!--comments-->
		<div class="comments_dir_box">
			<a href="?action=comment&title=<?php echo $title; ?>&cp=<?php echo $id; ?>&dir=<?php echo $dir; ?>"><div class="write_comment">
				Write a comment
			</div></a>
			<div class="read_comment">
				Read all comment
			</div>
			<div style="clear: both;"></div>
		</div>
		<!--comments ends-->
		</div>
		<!-- body container ends-->


</body>
</html>
