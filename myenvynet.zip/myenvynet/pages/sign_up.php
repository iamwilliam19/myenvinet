<body>


	<!-- body container starts-->
		<div class="body_container">
			<!--sign links start-->
			<div class="sign_links">
				<a href="?action=sign_up"><div class="sign_up <?php if($myaction == 'sign_up'){echo 'sign_selected';} ?>">
					Sign up
				</div></a>

				<a href="?action=sign_in"><div class="sign_in <?php if($myaction == 'sign_in'){echo 'sign_selected';} ?> ">
					Sign in
				</div></a>
				<div style="clear: both;"></div>
			</div>
			<!--sign links end-->

			<!--sign form box begin-->
			<div class="sign_form_box">
				<form action="db/sign_up_pro.php" method="post" class="form">

					<label for="full_name">Fullname:</label>
					<?php
						if($error == 001){
					?>
						<div class="name_error">Please enter a valid name</div>
					<?php } ?>
					<div class="name_error"></div>
					<input type="text" name="name" placeholder="Enter your first name and surname *" class="full_name" id="full_name" value="<?php echo $_SESSION['name']; ?>" required />
					<div class="sign_form_dir">
						Please make sure your names are correct.
					</div>

					<label for="email">Email:</label>
					<?php 
						if($error == 002){
					?>
					<div class="email_error">Please enter a valid email</div>
				   <?php } ?>

				   <?php 
						if($error == 007){
					?>
					<div class="email_error"> Email already exists</div>
				   <?php } ?>

					<div class="email_error"></div>
					<input type="text" name="email" placeholder="Enter email  eg. smith@gmail.com *" class="email"  id="email" value="<?php echo $_SESSION['email']; ?>" required />
					<div class="sign_form_dir">
						 your mail is spam safe.
					</div>

					<label for="password">password:</label>
					<?php 
						if($error == 003){
					?>
					<div class="password_error">Please enter a valid password</div>
				<?php } ?>
					<div class="password_error"></div>
					<input type="password" name="password" placeholder="Enter a new password * eg.Smith122" class="password" id="password" value="<?php echo $_SESSION['password']; ?>" required style="width: 100%; height: 30px; border-radius: 5px; background-color: #FFFFD4;"  />
					<div class="sign_form_dir">
						 Your password should contain at least one uppercase, one lower case , one number and a minimum of 6 characters.
					</div>

					<button type="submit" name="Create">Create my account</button>
				</form>

				<div class="sign_other">
					 Have an account already?  <a href="?action=sign_in">Sign in</a>
				</div>
			</div>
			<!--sign form box ends-->



		</div>
		<!-- body container ends-->


</body>
</html>
