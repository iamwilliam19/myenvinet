
	<!-- body container starts-->
		<div class="body_container">
			
			<!--news title box-->
			<div class="news_title_box">
				Articles
			</div>
			<!--news title box ends-->

			<div class="news_cont">
				<?php
			//select content for news feed
			$select_news_feed = $conn -> query("SELECT * FROM news WHERE section = 'articles'  order by id DESC LIMIT 16");
			$counter = 0;
			while($fetch_feed = $select_news_feed -> fetch_assoc()){
				$news_feed_img = $fetch_feed['image'];
				$news_feed_title = $fetch_feed['title'];
				$news_feed_content = $fetch_feed['content'];
				$news_feed_date = $fetch_feed['date'];
				$news_feed_poster = $fetch_feed['poster'];
				$id = $fetch_feed['id'];
				$strlen = strlen($news_feed_title);
				//check value of counter and decide if to post with pic
				
		?>

					<!--newsfeed pic display-->
					<a href="?action=view&gv=<?php  echo $id ;?>&dir=articles">	<div class="pic_display_box">
							<!-- img box-->
								<div class="img_box">
									<img src="<?php echo $news_feed_img; ?>" width="100%" height="100%">
								</div>
							<!--img box ends-->
							<!--img_title-->
							<div class="img_title">
								<?php echo substr($news_feed_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
								
							</div>
							<!--img_title ends-->

							<!--img others -->
							<div class="img_others">
								<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="img_poster">By <?php echo $news_feed_poster ;?></div></a>

								<div class="img_date">
									<?php echo $news_feed_date; ?>
								</div>
							</div>
							<!-- img others -->

						</div></a>
					<!-- news feed pic display box ends-->
					<div class="line"></div>
			
					
					<?php
			
				}
		?>

		<!--related begins-->
					<div class="related_artcles_title">
						<h3>Related articles</h3>
					</div>

					<div class="line"></div>


					<?php
			//select content for news feed
			$select_news_feed = $conn -> query("SELECT * FROM news WHERE section = 'articles'  order by id DESC LIMIT 3");
			$counter = 0;
			while($fetch_feed = $select_news_feed -> fetch_assoc()){
				$news_feed_img = $fetch_feed['image'];
				$news_feed_title = $fetch_feed['title'];
				$news_feed_content = $fetch_feed['content'];
				$news_feed_date = $fetch_feed['date'];
				$news_feed_poster = $fetch_feed['poster'];
				$id = $fetch_feed['id'];
				$strlen = strlen($news_feed_title);
				//check value of counter and decide if to post with pic
				
		?>
					<!--text-display-->
					<div class="text_display_box">
						<!-- text title-->
						<div class="text_title" style="font-size: 13px;">
							<?php echo substr($news_feed_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
						</div>
						<!-- text _title ends-->

						<!-- text text-->
						<div class="text_text">
							<?php echo substr($news_feed_content,0,150); ?>
						</div>
						<!-- text text ends-->

						<!--text_others-->
						<div class="text_others">
						<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>">	<div class="text_poster">
								By <?php echo $news_feed_poster ;?>
							</div></a>

							<div class="text_date">
								<?php echo $news_feed_date; ?>
							</div>
							<div style="clear: both;"></div>
						</div>
						<!--text others end-->

					</div>
					<!--text display ends -->

					<div class="line"></div>				<!--related ends-->
				<?php } ?>
			
				</div>
			<!-- news feed container ends -->
		<div class="gallery_publish">
				Publish Here
			</div>
			
		</div>
		<!-- body container ends-->
