<?php
	$smartphone_id = $_GET['sc'];
	

	//do selections
	$select_phone = $conn -> query("SELECT * FROM news  WHERE section = 'phones' && id='$smartphone_id'");
	
		$fetch_phone = $select_phone -> fetch_assoc();
		$phone_img = $fetch_phone['image'];
		$phone_title = $fetch_phone['title'];
		$phone_id = $fetch_phone['id'];
		$phone_brand = $fetch_phone['brand'];
		$phone_release_date = $fetch_phone['release_date'];
		$phone_version = $fetch_phone['version'];
		$phone_name2 = $fetch_phone['name_2'];
		$phone_manufacturer = $fetch_phone['manufacturer'];
		$phone_screen_size = $fetch_phone['screen_size'];
		$phone_ops = $fetch_phone['ops'];
		$phone_processor = $fetch_phone['pro'];
		$phone_ram = $fetch_phone['ram'];
		$phone_int_mem = $fetch_phone['int_mem'];
		$phone_cam = $fetch_phone['camera'];
		$phone_battery = $fetch_phone['battery'];
		$phone_other_high = $fetch_phone['other_high'];
		$phone_design = $fetch_phone['design'];
		$phone_dimension = $fetch_phone['dimension'];
		$phone_weight = $fetch_phone['weight'];
		$phone_aspect_ratio = $fetch_phone['aspect_rat'];
		$phone_disp_type = $fetch_phone['disp_type'];
		$phone_resolution = $fetch_phone['resolution'];
		$phone_pixel_den = $fetch_phone['pixel_den'];
		$phone_cont_ratio = $fetch_phone['cont_ratio'];
		$phone_phy_key = $fetch_phone['phy_key'];
		$phone_edge_disp = $fetch_phone['edge_disp'];
		$phone_triluminos = $fetch_phone['triluminos'];
		$phone_color_sat = $fetch_phone['color_sat'];
		$phone_brightness = $fetch_phone['brightness'];
		$phone_hd_comp = $fetch_phone['hd_comp'];
		$phone_three_d_touch = $fetch_phone['three_d_touch'];
		$phone_true_tone = $fetch_phone['true_tone'];
		$phone_wide_color = $fetch_phone['wide_color'];
		$phone_always_on = $fetch_phone['always_on'];
		$phone_pixel_resp = $fetch_phone['pixel_resp'];
		$phone_screen_prot = $fetch_phone['screen_prot'];
		$phone_curved_screen = $fetch_phone['curved_screen'];
		$phone_scratch_res = $fetch_phone['scratch_res'];
		$phone_anti_finger = $fetch_phone['anti_finger'];
		$phone_blue_light = $fetch_phone['blue_light'];
		$phone_sun_light = $fetch_phone['sun_light'];
		$phone_multi_touch = $fetch_phone['multi_touch'];
		$phone_other_feat = $fetch_phone['other_feat'];
		$phone_ui = $fetch_phone['ui'];
		$phone_pre_installed = $fetch_phone['pre_installed'];
		$phone_graphic_pro = $fetch_phone['graphic_pro'];
		$phone_gpu = $fetch_phone['gpu'];
		$phone_soc = $fetch_phone['soc'];
		$phone_isa = $fetch_phone['isa'];
		$phone_pro_tech = $fetch_phone['pro_tech'];
		$phone_cpu = $fetch_phone['cpu'];
		$phone_co_pro = $fetch_phone['co_pro'];
		$phone_ram_type = $fetch_phone['ram_type'];
		$phone_ram_channel = $fetch_phone['ram_channel'];
		$phone_freq = $fetch_phone['freq'];
		$phone_mem_type = $fetch_phone['mem_type'];
		$phone_mem_card = $fetch_phone['mem_card'];
		$phone_front_cam = $fetch_phone['front_cam'];
		$phone_sensor_mod = $fetch_phone['sensor_mod'];
		$phone_vid_rec = $fetch_phone['vid_rec'];
		$phone_rear_cam = $fetch_phone['rear_cam'];
		$phone_sensor_type = $fetch_phone['sensor_type'];
		$phone_cam_feat = $fetch_phone['cam_feat'];
		$phone_vid_format = $fetch_phone['vid_format'];
		$phone_vid_format = $fetch_phone['aud_format'];
		$phone_img_format = $fetch_phone['img_format'];
		$phone_aud_format = $fetch_phone['aud_format'];
		$phone_speaker = $fetch_phone['speaker'];
		$phone_microphone = $fetch_phone['microphone'];
		$phone_sim_count = $fetch_phone['sim_count'];
		$phone_sim_type = $fetch_phone['sim_type'];
		$phone_twogcall = $fetch_phone['twog_call'];
		$phone_twog_data = $fetch_phone['twog_data'];
		$phone_threeg_call = $fetch_phone['threeg_Call'];
		$phone_threeg_data = $fetch_phone['threeg_data'];
		$phone_fourg_call = $fetch_phone['fourg_call'];
		$phone_fourg_data = $fetch_phone['fourg_data'];
		$phone_please_note = $fetch_phone['please_note'];
		$phone_sim_use = $fetch_phone['sim_use'];
		$phone_wifi = $fetch_phone['wifi'];
		$phone_wifi_feature = $fetch_phone['wifi_feature'];
		$phone_cell_net = $fetch_phone['cell_net'];
		$phone_data_con = $fetch_phone['data_con'];
		$phone_bluetooth = $fetch_phone['bluetooth'];
		$phone_nav_sys = $fetch_phone['nav_sys'];
		$phone_other_con = $fetch_phone['other_con'];
		$phone_usb_port = $fetch_phone['usb_port'];
		$phone_Ddi = $fetch_phone['Ddi'];
		$phone_finger_print = $fetch_phone['finger_print'];
		$phone_audio_jack = $fetch_phone['audio_jack'];
		$phone_face_rec = $fetch_phone['face_rec'];
		$phone_other_sensors = $fetch_phone['other_sensors'];
		$phone_bat_type = $fetch_phone['bat_type'];
		$phone_bat_mod = $fetch_phone['bat_mod'];
		$phone_charge_output = $fetch_phone['charge_output'];
		$phone_bat_sup = $fetch_phone['bat_sup'];
		$phone_browser_sup = $fetch_phone['browser_sup'];
		$phone_wearable = $fetch_phone['wearable'];
		$phone_fm = $fetch_phone['fm'];
		$phone_not_light = $fetch_phone['not_light'];
		$phone_voice_ass = $fetch_phone['voice_ass'];
		$phone_air_ges = $fetch_phone['air_ges'];
		$phone_extra_pro = $fetch_phone['extra_pro'];
		$phone_others = $fetch_phone['others'];
		$phone_cloud_sto = $fetch_phone['cloud_sto'];
		$phone_service_temp = $fetch_phone['service_temp'];
		$phone_sar = $fetch_phone['sar'];
		$phone_sty_pen = $fetch_phone['sty_pen'];
		$phone_mobile_pay = $fetch_phone['mobile_pay'];
		$phone_support = $fetch_phone['support'];
		$phone_war_type = $fetch_phone['war_type'];
		$phone_colors = $fetch_phone['color'];
		$phone_price = $fetch_phone['price'];
		$phone_audio_output = $fetch_phone['audio_output'];
		$phone_screen_to_body = $fetch_phone['screen_to_body'];
		$phone_cache = $fetch_phone['cache'];
		$strlen = strlen($phone_title);


?>


<!-- body container starts-->
<div class="body_container">
	<!--spec links box begins -->
	<div class="spec_links">
		<div class="spec_links_box">
		 <ul class="spec_ul">
		 	<a href="?action=smartphone_spec&sc=<?php echo $phone_id; ?>"><li class="spec_selected">Specs</li></a>
		 	<a href="?action=smartphone_pics&sc=<?php echo $phone_id; ?>"><li>Pictures</li></a>
		 	<li>Reviews</li>
		 	<li>Comments</li>
		 </ul>
		 <div style="clear: both;"></div>
		</div>
	</div>
	<!--spec link box ends-->

	<!--spec title-->
	<div class="spec_title">
		<h3><?php echo $phone_title ?></h3>
	</div>
	<!--spec title ends-->

	<!--spec image-->
	<div class="spec_img">
		<img src="<?php echo $phone_img ?>" width="100%" height="100%" />
	</div>
	<!--spec image ends -->

	<!--specicons-->
	<div class="spec_icons">
		<div class="spec_i">
			<i class="fab fa-facebook-f"></i>
		</div>

		<div class="spec_i">
			<i class="fab fa-twitter"></i> 
		</div>

		<div class="spec_i spec_share">
			<i class="fas fa-share-alt"></i> 
		</div>

		<div style="clear: both;"></div>

		<!-- spec icon others begin-->
		<div class="spec_icon_others">
			<div class="spec_stumble">
				<i class="fab fa-stumbleupon"></i>
			</div>

			<div class="spec_redit">
				<i class="fab fa-reddit-alien"></i>
			</div>

			<div class="spec_messenger">
				<i class="fab fa-facebook-messenger"></i>
			</div>

			<div class="spec_gplus">
				<i class="fab fa-google-plus-g"></i>
			</div>
		</div>
		<!--spec icon others ends-->

	</div>
	<!--spec icons ends-->

	<!--spec extra begins-->
	<div class="spec_extra">
		<!-- pec extra left-->
		<div class="spec_extra_left">
			<div class="left_fav">
				<div class="left_left">
				Add to favourites

				</div>

				<div class="left_right">
					<i class="fab fa-gratipay"></i>
				</div>

				<div style="clear: both;"></div>
			</div>

			<div class="right_fav">
				20 fans
			</div>

			<div style="clear: both;"></div>
		</div>
		<!--spec extra left ends-->

				<!-- pec extra right-->
		<div class="spec_extra_right">
			<div class="hit_box">
				100 hits
		    </div>
		</div>
		<!--spec extra right ends-->
		<div style="clear: both;"></div>
	</div>
	<!--spec extra ends-->

	
	
	<!--main spec box-->
	<div class="main_spec_box">
		<?php
			if($phone_release_date != '' || $phone_version != '' || $phone_series != '' || $phone_name2 != '' || $phone_manufacturer != ''){
		?>
		<div class="sub_spec_info">
			<h3>Key information</h3>
		</div>

	<?php } ?>

		<!--realse date-->
		<?php

			if($phone_release_date != ''){
		 ?>
		
		<div class="sub_spec_box">
		<div class="sub_spec_title">
			Release date:
		</div>

		<div class="sub_spec_ans">
			<?php echo $phone_release_date; ?>
		</div>
	</div>
	<?php } ?>
		<!--release date ends-->

	<!--name2-->

	<?php

			if($phone_name2 != ''){
		 ?>
		
		<div class="sub_spec_box">
		<div class="sub_spec_title">
			Also known as:
		</div>

		<div class="sub_spec_ans">
			<?php echo $phone_name2; ?>
		</div>
	</div>
		

	<?php } ?>
	<!--name2 ends-->
		

	<!--manufacturer-->

	<?php

			if($phone_manufacturer != ''){
		 ?>
		
		<div class="sub_spec_box">
		<div class="sub_spec_title">
			Manufacturer:
		</div>

		<div class="sub_spec_ans">
			<?php echo $phone_manufacturer; ?>
		</div>
	</div>
		

	<?php } ?>
	<!--manufacturer ends-->

<!--highlight table-->
<?php
			if($phone_screen_size != '' || $phone_hd_comp != ''  || $phone_Ddi != '' || $phone_other_high != '' || $phone_ops != '' || $phone_processor != '' || $phone_ram != '' || $phone_int_mem != '' || $phone_cam != '' || $phone_battery != '' ){
		?>
	<div class="sub_spec_info">
			<h3>Highlights</h3>
		</div>
<?php } ?>
		<!-- screen-->
		<?php

			if($phone_screen_size != ''){
		 ?>
		<div class="table" >
			<div class="row">
				<div class="col_1">
					<strong>Screen size: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_screen_size; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--screen ends-->

		<!-- pro-->
		<?php

			if($phone_ops != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Operating system: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_ops; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--pro ends-->

		<!-- ops-->
		<?php

			if($phone_processor != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Processor: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_processor; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--ops ends-->

		<!-- ram-->
		<?php

			if($phone_ram != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Ram: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_ram; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--ram ends-->

		<!-- int mem-->
		<?php

			if($phone_int_mem != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Internal memory: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_int_mem; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!--int mem ends-->

		<!-- battery-->
		<?php

			if($phone_battery != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Battery: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_battery; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--batteyr ends-->

		<!-- other-->
		<?php

			if($phone_other_high != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other highlights: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_other_high; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!--other ends-->

		<div class="full_spec"><h3>Full specification</h3></div>
<?php
			if($phone_screen_size != '' || $phone_hd_comp != '' || $phone_design != '' || $phone_dimension != '' || $phone_weight != '' || $phone_Ddi != '' || $phone_aspect_ratio != '' || $phone_screen_to_body != '' || $phone_disp_type != '' || $phone_resolution != '' || $phone_pixel_den != '' || $phone_cont_ratio != '' || $phone_dimming_tech != '' || $phone_triluminos != '' || $phone_color_sat != '' || $phone_brightness != '' || $phone_backlight != '' || $phone_hd_comp != '' || $phone_wide_color != '' || $phone_blue_light != '' || $phone_viewing_angle != '' || $phone_other_spec != '' || $phone_phy_key != '' || $phone_edge_disp != '' || $phone_three_d_touch != '' || $phone_true_tone != '' || $phone_always_on != '' || $phone_pixel_resp != '' || $phone_screen_prot != '' || $phone_curved_screen != '' || $phone_scratch_res != '' || $phone_anti_finger != '' || $phone_sun_light != '' || $phone_multi_touch != '' || $phone_other_feat != ''){
		?>

		<div class="sub_spec_info">
			<h3>Size, Display & Screen</h3>
		</div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_design != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Design: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_design; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_screen_size != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Screen size: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_screen_size; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_dimension != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Dimension: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_dimension; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_weight != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Weight: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_weight; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_screen_to_body != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Screen to body ratio: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_screen_to_body; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_aspect_ratio != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Aspect ratio: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_aspect_ratio; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_disp_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Display type: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_disp_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_resolution != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Resolution: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_resolution; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_pixel_den != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Pixel density: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_pixel_den; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_cont_ratio != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Contrast ratio: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_cont_ratio; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_phy_key != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Physical keyboard: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_phy_key; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_edge_disp != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Edge display: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_edge_disp; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		

		<!-- begin-->
		<?php

			if($phone_triluminos != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Triluminos display: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_triluminos; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_color_sat != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Color saturation: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_color_sat; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_brightness != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Brightness: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_brightness; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_hd_comp != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>HDR10 compliant: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_hd_comp; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_three_d_touch != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>3D touch: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_three_d_touch; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_true_tone != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>True tone display: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_true_tone; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_wide_color != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Wide color gamut display: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_wide_color; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_always_on != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Always on: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_always_on; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_pixel_resp != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Pixel response time: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_pixel_resp; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_screen_prot != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Screen protection: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_screen_prot; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_curved_screen != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Curved screen: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_curved_screen; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_scratch_res != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Scratch resistant: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_scratch_res; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_anti_finger != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Ant-finger print coating: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_anti_finger; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_blue_light != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Blue light filter (for eye care): </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_blue_light; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->


		<!-- begin-->
		<?php

			if($phone_sun_light != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Sunlight mode and reading mode: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_sun_light; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_multi_touch != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Multi touch gesture: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_multi_touch; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_other_feat != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other features: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_other_feat; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php 
	
	if($phone_ops != '' || $phone_ui != '' || $phone_pre_installed != ''){

?>
		<div class="sub_spec_info">
			<h3>Software</h3>
		</div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_ops != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Operating system: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_ops; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_pre_installed != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Pre-installed Apps: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_pre_installed; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<?php 
			if($phone_graphic_pro != '' || $phone_gpu != '' || $phone_soc != ''  || $phone_isa != '' || $phone_pro_tech != '' || $phone_cpu != '' || $phone_cache != '' || $phone_co_pro != ''){

		?>
<div class="sub_spec_info">
			<h3>Processor</h3>
		</div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_graphic_pro != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Graphics processor: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_graphic_pro; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_gpu != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>GPU frequency: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_gpu; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_soc != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>System-on-Chip {SoC}: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_soc; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_isa != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Instruction Set Architecture {ISA}: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_isa; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_pro_tech != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Process technology: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_pro_tech; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_cache != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>
					cache memory: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_cache; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_cpu != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>C.P.U: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_cpu; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_co_pro != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Core processor: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_co_pro; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
<?php
	if($phone_ram != '' || $phone_ram_type != '' || $phone_ram_channel != '' || $phone_freq != '' || $phone_int_mem != '' || $phone_mem_type != '' || $phone_mem_card != ''){
 ?>
		<div class="ram_and_mem"><h3>RAM and Memory</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_ram != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Random access memory size : </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_ram; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_ram_channel != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>RAM channel : </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_ram_channel; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_freq != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Frequency : </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_freq; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_int_mem != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Internal memory: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_int_mem; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_mem_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Memory type: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_mem_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_mem_card != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Memory card support: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_mem_card; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->


<?php

	if($phone_cam_resolution != '' || $phone_sensor_type != '' || $phone_sensor_mod != '' || $phone_cam_feat != '' || $phone_vid_rec != '' || $phone_front_cam != '' || $phone_rear_cam != ''){

?>
		<div class="camera"><h3>Camera</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_front_cam != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Front camera: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_front_cam; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_sensor_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Sensor type: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_sensor_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_sensor_mod != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Sensor model: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_sensor_mod; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_cam_feat != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Features: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_cam_feat; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_vid_rec != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Video recording: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_vid_rec; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_rear_cam != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Rear camera: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_rear_cam; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_vid_rec != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Video recording: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_vid_rec; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<?php 
			if($phone_vid_format != '' || $phone_aud_format != '' || $phone_img_format != ''){
		?>

		<div class="video"><h3>Video, Audio & Image formats</h3></div>

	<?php } ?>

		<!-- begin-->
		<?php

			if($phone_vid_format != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Video format and codecs: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_vid_format; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_aud_format != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Audio format and codecs: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_aud_format; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_img_format != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Image format and codecs: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_img_format; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
<?php
	if($phone_audio_output != '' || $phone_speaker != '' || $phone_microphone != ''){
?>
		<div class="audio"><h3>Audio, speaker & mic</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_audio_output != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Audio output: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_audio_output; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_speaker != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Speaker: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_speaker; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_microphone != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Microphone: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_microphone; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>

		<!-- ends-->

<?php

	if($phone_sim_count != '' || $phone_sim_type != '' || $phone_twogcall != '' || $phone_threeg_call != '' || $phone_fourg_call != '' || $phone_twog_data != '' || $phone_threeg_data != '' || $phone_fourg_data != '' || $phone_please_note != '' || $phone_sim_use != ''){

?>

		<div class="sim"><h3>Sim and Network support</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_sim_count != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Sim count: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_sim_count; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_sim_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Sim type: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_sim_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_twogcall != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>2g(for calls): </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_twogcall; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_threeg_call != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>3g(for calls): </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_threegcall; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_fourg_call != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>4g/LTE(for calls): </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_fourg_call; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->
		
		<!-- begin-->
		<?php

			if($phone_twog_data != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>2g(for data): </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_twog_data; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_threeg_data != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>3g(for data): </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_threeg_data; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_fourg_data != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>4g/LTE(for data): </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_fourg_data; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_please_note != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Please note: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_please_note; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_sim_use != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>sim use: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_sim_use; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php
	if($phone_wifi != '' || $phone_wifi_feature != '' || $phone_bluetooth != '' || $phone_LAN != '' || $phone_other_con != '' || $phone_cell_net != '' || $phone_data_con != '' || $phone_other_con != '' || $phone_nav_sys != '' ){
?>
		<div class="connect"><h3>Connectivity</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_wifi != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>WI-FI: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_wifi; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_wifi_feature != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>WI-FI features: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_wifi_feature; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_cell_net != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Cellular network: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_cell_net; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_data_con != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Data connection: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_data_con; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_bluetooth != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Bluetooth: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_bluetooth; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_nav_sys != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Navigation system: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_nav_sys; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_other_con != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other connectivity features: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_other_con; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php
	if($phone_usb_port != '' || $phone_audio_jack != ''|| $phone_Ddi != ''){
?>
		<div class="port"><h3>Ports</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_usb_port != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>USB Port: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_usb_port; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_audio_jack != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Audio jack: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_audio_jack; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_Ddi != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Digital display interface: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_Ddi; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

	<?php
		if($phone_finger_print != '' || $phone_face_rec != '' || $phone_other_sensors != ''){
	?>

		<div class="sensor"><h3>Sensors</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_finger_print != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Finger-print sensor: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_finger_print; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_face_rec != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Face recognition: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_face_rec; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->


		<!-- begin-->
		<?php

			if($phone_other_sensors != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other sensors: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_other_sensors; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php
	if($phone_battery != '' || $phone_bat_type != '' || $phone_bat_mod != '' || $phone_charge_output != '' || $phone_bat_sup != ''){
?>
		<div class="battery"><h3>Battery</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_battery != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Capacity: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_battery; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_bat_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Type: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_bat_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_bat_mod != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Model: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_bat_mod; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_charge_output != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Charger output: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_charge_output; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_bat_sup != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Supports: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_bat_sup; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php
	if($phone_browser_sup != '' || $phone_wearable != '' || $phone_fm != '' || $phone_not_light != '' || $phone_voice_ass != '' || $phone_air_ges != '' || $phone_extra_pro != '' || $phone_others != '' || $phone_cloud_sto != '' || $phone_service_temp != '' || $phone_sar != '' || $phone_sty_pen != '' || $phone_mobile_pay != ''){
?>
		<div class="other_feat"><h3>Other features</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_browser_sup != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Browser support: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_browser_sup; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_wearable != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Wearable devices supported: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_wearable; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_fm != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>FM radio: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_fm; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_not_light != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>notification light: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_not_light; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_voice_ass != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Voice assistant: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_voice_ass; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_air_ges != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Air gesture: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_air_ges; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_extra_pro != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Extra protection: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_extra_pro; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_others != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Other features: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_others; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_cloud_sto != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Cloud Storage: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_cloud_sto; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_service_temp != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>In service temperature: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_service_temp; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_sar != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>SAR: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_sar; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_sty_pen != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Stylus Pen: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_sty_pen; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_mobile_pay != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Mobile payment: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_mobile_pay; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<?php

	if( $phone_support != '' || $phone_war_type != '' ){
?>
		<div class="sup"><H3>Support and Warranty</H3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_support != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Support: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_support; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_war_type != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Warranty type: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_war_type; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->


<?php
	if($phone_colors != '' || $phone_price != ''){
?>
		<div class="color_price"><h3>Color and Price</h3></div>
<?php } ?>
		<!-- begin-->
		<?php

			if($phone_colors != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Colors: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_colors; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

		<!-- begin-->
		<?php

			if($phone_price != ''){
		 ?>
		<div class="table" >
			<div class="row" >
				<div class="col_1">
					<strong>Price: </strong>
				</div>
				<div class="col_2">
					<?php echo $phone_price; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
		</div>
		<?php } ?>
		<!-- ends-->

<!-- table box ends-->
	</div>
	<!--main spec box ends-->

	<!--spec disclaimer box-->
	<div  class="spec_disclaimer_box">
		<span>Disclaimer:</span> We like to admit that the specs of the product above may not be 100% correct. To suggest an edit, contact us <a href="#"  style="color: #2A6BA6;">here</a>. <a href="?action=disclaimer" style="text-decoration: underline;">Read full Disclaimer</a>.
	</div>
	<!--spec disclimer box ends-->


	<!--related phones box-->
	<div class="related_phones_box">
		<div   class="related_title">
			<h3>Related phones</h3>
		</div>

		<!--related display box starts-->
		<div class="related_display_box">
			<?php 
				// select related phones
				$related_phones = $conn -> query("SELECT * FROM news WHERE section = 'phones' && brand = '$phone_brand' && id != '$phone_id' ");

				$count_display = 0;
				while($fetch_related = $related_phones -> fetch_assoc()){

					$related_img = $fetch_related['image'];
					$related_name = $fetch_related['name'];

					$count_display++;
			?>
			<!--related display beigns-->
			<div class="related_display">
				
				<img src="<?php echo $related_img; ?>" width="100%" height="100%" />

				<!--phone name-->
				<div class="related_name">
					<?php echo $related_name; ?>
				</div>
				<!--phone name ends-->
			</div>
			<!--related display ends-->



			<?php 
					//echo line
				   	if($count_display == 2){
				   		echo "<div class='display_line'></div>";
				   		$count_display = 0;
				   	}
		    	}
		   ?>



			<div style="clear: both;"></div>
		</div>
		<!-- related display box ends-->

	</div>
	<!--related phones box ends-->

	<!-- see all  starts -->
	<div class="related_seeAll_box">
		see all <?php echo $phone_brand; ?> phones <span> > </span>
	</div>
	<!-- see all ends-->

		
</div>
<!-- body container ends-->

