<?php
	$gadgets_id = $_GET['sc'];
	

	//do selections
	$select_gadgets = $conn -> query("SELECT * FROM news  WHERE section = 'phones' && id='$gadgets_id'");
	
		$fetch_gadgets = $select_gadgets -> fetch_assoc();
		$gadgets_img = $fetch_gadgets['image'];
		$gadgets_title = $fetch_gadgets['title'];
		$gadgets_id = $fetch_gadgets['id'];

		$gadgets_content = $fetch_gadgets['content'];

		$gadgets_brand = $fetch_gadgets['brand'];
		$gadgets_release_date = $fetch_gadgets['release_date'];
		$gadgets_version = $fetch_gadgets['version'];
		$gadgets_name2 = $fetch_gadgets['name_2'];
		$gadgets_manufacturer = $fetch_gadgets['manufacturer'];
		$gadgets_screen_size = $fetch_gadgets['screen_size'];
		$gadgets_ops = $fetch_gadgets['ops'];
		$gadgets_processor = $fetch_gadgets['pro'];
		$gadgets_ram = $fetch_gadgets['ram'];
		$gadgets_int_mem = $fetch_gadgets['int_mem'];
		$gadgets_cam = $fetch_gadgets['camera'];
		$gadgets_battery = $fetch_gadgets['battery'];
		$gadgets_other_high = $fetch_gadgets['other_high'];
		$gadgets_design = $fetch_gadgets['design'];
		$gadgets_dimension = $fetch_gadgets['dimension'];
		$gadgets_weight = $fetch_gadgets['weight'];
		$gadgets_aspect_ratio = $fetch_gadgets['aspect_rat'];
		$gadgets_disp_type = $fetch_gadgets['disp_type'];
		$gadgets_resolution = $fetch_gadgets['resolution'];
		$gadgets_pixel_den = $fetch_gadgets['pixel_den'];
		$gadgets_cont_ratio = $fetch_gadgets['cont_ratio'];
		$gadgets_phy_key = $fetch_gadgets['phy_key'];
		$gadgets_edge_disp = $fetch_gadgets['edge_disp'];
		$gadgets_triluminos = $fetch_gadgets['triluminos'];
		$gadgets_color_sat = $fetch_gadgets['color_sat'];
		$gadgets_brightness = $fetch_gadgets['brightness'];
		$gadgets_hd_comp = $fetch_gadgets['hd_comp'];
		$gadgets_three_d_touch = $fetch_gadgets['three_d_touch'];
		$gadgets_true_tone = $fetch_gadgets['true_tone'];
		$gadgets_wide_color = $fetch_gadgets['wide_color'];
		$gadgets_always_on = $fetch_gadgets['always_on'];
		$gadgets_pixel_resp = $fetch_gadgets['pixel_resp'];
		$gadgets_screen_prot = $fetch_gadgets['screen_prot'];
		$gadgets_curved_screen = $fetch_gadgets['curved_screen'];
		$gadgets_scratch_res = $fetch_gadgets['scratch_res'];
		$gadgets_anti_finger = $fetch_gadgets['anti_finger'];
		$gadgets_blue_light = $fetch_gadgets['blue_light'];
		$gadgets_sun_light = $fetch_gadgets['sun_light'];
		$gadgets_multi_touch = $fetch_gadgets['multi_touch'];
		$gadgets_other_feat = $fetch_gadgets['other_feat'];
		$gadgets_ui = $fetch_gadgets['ui'];
		$gadgets_pre_installed = $fetch_gadgets['pre_installed'];
		$gadgets_graphic_pro = $fetch_gadgets['graphic_pro'];
		$gadgets_gpu = $fetch_gadgets['gpu'];
		$gadgets_soc = $fetch_gadgets['soc'];
		$gadgets_isa = $fetch_gadgets['isa'];
		$gadgets_pro_tech = $fetch_gadgets['pro_tech'];
		$gadgets_cpu = $fetch_gadgets['cpu'];
		$gadgets_co_pro = $fetch_gadgets['co_pro'];
		$gadgets_ram_type = $fetch_gadgets['ram_type'];
		$gadgets_ram_channel = $fetch_gadgets['ram_channel'];
		$gadgets_freq = $fetch_gadgets['freq'];
		$gadgets_mem_type = $fetch_gadgets['mem_type'];
		$gadgets_mem_card = $fetch_gadgets['mem_card'];
		$gadgets_front_cam = $fetch_gadgets['front_cam'];
		$gadgets_sensor_mod = $fetch_gadgets['sensor_mod'];
		$gadgets_vid_rec = $fetch_gadgets['vid_rec'];
		$gadgets_rear_cam = $fetch_gadgets['rear_cam'];
		$gadgets_sensor_type = $fetch_gadgets['sensor_type'];
		$gadgets_cam_feat = $fetch_gadgets['cam_feat'];
		$gadgets_vid_format = $fetch_gadgets['vid_format'];
		$gadgets_vid_format = $fetch_gadgets['aud_format'];
		$gadgets_img_format = $fetch_gadgets['img_format'];
		$gadgets_aud_format = $fetch_gadgets['aud_format'];
		$gadgets_speaker = $fetch_gadgets['speaker'];
		$gadgets_microgadgets = $fetch_gadgets['microgadgets'];
		$gadgets_sim_count = $fetch_gadgets['sim_count'];
		$gadgets_sim_type = $fetch_gadgets['sim_type'];
		$gadgets_twogcall = $fetch_gadgets['twog_call'];
		$gadgets_twog_data = $fetch_gadgets['twog_data'];
		$gadgets_threeg_call = $fetch_gadgets['threeg_Call'];
		$gadgets_threeg_data = $fetch_gadgets['threeg_data'];
		$gadgets_fourg_call = $fetch_gadgets['fourg_call'];
		$gadgets_fourg_data = $fetch_gadgets['fourg_data'];
		$gadgets_please_note = $fetch_gadgets['please_note'];
		$gadgets_sim_use = $fetch_gadgets['sim_use'];
		$gadgets_wifi = $fetch_gadgets['wifi'];
		$gadgets_wifi_feature = $fetch_gadgets['wifi_feature'];
		$gadgets_cell_net = $fetch_gadgets['cell_net'];
		$gadgets_data_con = $fetch_gadgets['data_con'];
		$gadgets_bluetooth = $fetch_gadgets['bluetooth'];
		$gadgets_nav_sys = $fetch_gadgets['nav_sys'];
		$gadgets_other_con = $fetch_gadgets['other_con'];
		$gadgets_usb_port = $fetch_gadgets['usb_port'];
		$gadgets_Ddi = $fetch_gadgets['Ddi'];
		$gadgets_finger_print = $fetch_gadgets['finger_print'];
		$gadgets_audio_jack = $fetch_gadgets['audio_jack'];
		$gadgets_face_rec = $fetch_gadgets['face_rec'];
		$gadgets_other_sensors = $fetch_gadgets['other_sensors'];
		$gadgets_bat_type = $fetch_gadgets['bat_type'];
		$gadgets_bat_mod = $fetch_gadgets['bat_mod'];
		$gadgets_charge_output = $fetch_gadgets['charge_output'];
		$gadgets_bat_sup = $fetch_gadgets['bat_sup'];
		$gadgets_browser_sup = $fetch_gadgets['browser_sup'];
		$gadgets_wearable = $fetch_gadgets['wearable'];
		$gadgets_fm = $fetch_gadgets['fm'];
		$gadgets_not_light = $fetch_gadgets['not_light'];
		$gadgets_voice_ass = $fetch_gadgets['voice_ass'];
		$gadgets_air_ges = $fetch_gadgets['air_ges'];
		$gadgets_extra_pro = $fetch_gadgets['extra_pro'];
		$gadgets_others = $fetch_gadgets['others'];
		$gadgets_cloud_sto = $fetch_gadgets['cloud_sto'];
		$gadgets_service_temp = $fetch_gadgets['service_temp'];
		$gadgets_sar = $fetch_gadgets['sar'];
		$gadgets_sty_pen = $fetch_gadgets['sty_pen'];
		$gadgets_mobile_pay = $fetch_gadgets['mobile_pay'];
		$gadgets_support = $fetch_gadgets['support'];
		$gadgets_war_type = $fetch_gadgets['war_type'];
		$gadgets_colors = $fetch_gadgets['color'];
		$gadgets_price = $fetch_gadgets['price'];
		$gadgets_audio_output = $fetch_gadgets['audio_output'];
		$gadgets_screen_to_body = $fetch_gadgets['screen_to_body'];
		$gadgets_cache = $fetch_gadgets['cache'];
		$strlen = strlen($gadgets_title);


?>


<!-- body container starts-->
<div class="body_container">
	<!--spec links box begins -->
	<div class="spec_links">
		<div class="spec_links_box">
		 <ul class="spec_ul">
		 	<a href="?action=smartphones_spec&sc=<?php echo $gadgets_id; ?>"><li >Specs</li></a>
		 	<a href="?action=smartgadgets_pics&sc=<?php echo $gadgets_id; ?>"><li class="spec_selected">Pictures</li></a>
		 	<li>Reviews</li>
		 	<li>Comments</li>
		 </ul>
		 <div style="clear: both;"></div>
		</div>
	</div>
	<!--spec link box ends-->

	<!--spec pic box starts-->
	<div class="spec_pic_box">
			
			<?php

				echo $gadgets_content;

			?>
	</div>
	<!--spec pic box ends-->

			<script type="text/javascript">
			$(document).ready(function(){
				var images = $('.spec_pic_box img');
				$.each(images,function(index,value){
					var indexDigit = index + 1;
					var formattedNumber = ("0" + indexDigit).slice(-2);

					$('<div class="flow_counter">'+formattedNumber+'</div>').insertBefore(value);
				})
			});
		</script>

		
</div>
<!-- body container ends-->

