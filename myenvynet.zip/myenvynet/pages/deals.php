-<?php
	
	//get back what was selected and also report
	$brand = $_GET['branded'];
	$store = $_GET['stored'];
	$price_one = $_GET['price_one'];
	$price_two = $_GET['price_two'];
	$apply = $_GET['apply'];
	$fail = $_GET['fail'];

?>

<!-- body container starts-->
<div class="body_container">
			<!--deals box start-->
			<div class="deals_box">
				<!--deal links start-->
				<div class="deal_links">
					<table width="auto">
						<tr>
						
							<td class="deal_selected"><a href="?action=deals">Deals</a> </td>

						<td><a href="?action=smartdeals">Smartphones</a></td>
						<td><a href="?action=tvdeals">TVs</a></td>
						<td><a href="?action=laptopdeals">Laptops</a></td>
						<td><a href="?action=speakerdeals">Speakers</a></td>
						<td><a href="?action=sounddeals">Sounds</a></td>				
					</tr>
					</table>			
				</div>
				<!--deal links ends-->

				<div class="deal_intro">
				Get the best deals on electronics. All you need to do is click on any picture and voila you are off to shop!
				 </div>

				 <!--deal sort-->
				 <div class="deal_sort">
				 	Sort by:
				 </div>
				 <!--deal sort ends-->

				 <!--deal drop box-->
				 <form action="db/alldeal.php?sender=all" method="post" class="deal_form">
				 <div class="deal_drop_box">
				 	<div class="drop_item">
				 		<select class="brands" name="brand">
				 			<option value="">Brands</option>
				 			<option value="10.or">10.or</option>
				 			<option value="1more">1more</option>
				 			<option value="acer">Acer</option>
				 			<option value="acoustic_audio">Acoustic audio</option>
				 			<option value="ailihen">Ailihen</option>
				 			<option value="akg">AKG</option>
				 			<option value="altec">Altec lansing</option>
				 		
				 			<option value="amazon">Amazon</option>
				 			<option value="anker">Anker</option>
				 			<option value="aoc">AOC</option>
				 			<option value="apple">Apple</option>
				 			<option value="asus">ASUS</option>
				 			<option value="audio_engine">Audio engine</option>
				 			<option value="audio_technica">Audio-technica</option>
				 			<option value="ausdom">Ausdom</option>
				 			<option value="avantree">Avantree</option>
				 			<option value="bang&olufen">Bang &amp; Olufsen</option>
				 			<option value="beats">Beats by Dre</option>
				 			<option value="behringer">Behringer</option>
				 			<option value="blackberry">Blackberry</option>
				 			<option value="blu">BLU</option>
				 			<option value="bluedio">Bluedio</option>
				 			<option value="bluephonic">Bluephonic</option>
				 			<option value="bohm">BOHM</option>
				 			<option value="bose">Bose</option>
				 			<option value="bowers">Bowers &amp; Wilkins </option>
				 			<option value="bpl">BPL</option>
				 			<option value="brainwavz">Brainwavz</option>
				 			<option value="Cambridge">Cambridge Soundworks</option>
				 			<option value="cerwin">Cerwin-
				 			Vega</option>
				 			<option value="cowin">Cowin</option>
				 			<option value="creative">Creative</option>
				 			<option value="cyber">Cyber acoustics</option>
				 			<option value="definitive">Definitive</option>
				 			<option value="dell">Dell</option>
				 			<option value="element">Element</option>
				 			<option value="edifier">Edifier</option>
				 			<option value="fenda">F &amp; D Fenda</option>
				 			<option value="finlux">Finlux</option>
				 			<option value="gigabyte">Gigabyte</option>
				 			<option value="google">Google</option>
				 			<option value="grado">Grado</option>
				 			<option value="akg">Harman Kardon</option>
				 			<option value="hisense">Hisense</option>
				 			<option value="hp">HP</option>
				 			<option value="htc">HTC</option>
				 			<option value="huawei">
				 				Huawei
				 			</option>
				 			<option value="hussar">Hussar</option>
				 			<option value="infinity">Infinity</option>
				 			<option value="infocus">Infocus</option>
				 			<option value="ion">ION</option>
				 			<option value="insignia">Insignia</option>
				 			<option value="jabra">Jabra</option>
				 			<option value="jbl">JBL</option>
				 			<option value="jlab">JLab</option>
				 			<option value="jvc">JVC</option>
				 			<option value="jaybird">Jaybird</option>
				 			<option value="kenwood">Kenwood</option>
				 			<option value="kinivo">Kinivo</option>
				 			<option value="klipsch">Klipsch</option>
				 			<option value="koss">Koss</option>
				 			<option value="lenovo">Lenovo</option>
				 			<option value="lg">LG</option>
				 			<option value="logitech">Logitech</option>
				 			<option value="martin">Martin Logan</option>
				 			<option value="mee">MEE Audio</option>
				 			<option value="micromax">Micromax</option>
				 			<option value="microsoft">Microsoft</option>
				 			<option value="mitsubishi">Mitsubishi</option>
				 			<option value="monoprice">Monoprice</option>
				 			<option value="motorola">motorola</option>
				 			<option value="mpow">Mpow</option>
				 			<option value="msi">MSI</option>
				 			<option value="nenrent">NENRENT</option>
				 			<option value="nokia">Nokia</option>
				 			<option value="oneplus">OnePlus</option>
				 			<option value="onkyo">Onkyo</option>
				 			<option value="oppo">Oppo</option>
				 			<option value="otium">Otium</option>
				 			<option value="panasonic">Panasonic</option>
				 			<option value="phaiser">Phaiser</option>
				 			<option value="philips">Philips</option>
				 			<option value="photive">Photive</option>
				 			<option value="pioneer">Pioneer</option>
				 			<option value="plantronics">Plantronics</option>
				 			<option value="polk">Polk Audio</option>
				 			<option value="pyle">Pyle</option>
				 			<option value="razer">Razer</option>
				 			<option value="rca">RCA</option>
				 			<option value="rock">Rockford Fosgate</option>
				 			<option value="samsung">Samsung</option>
				 			<option value="scepter">Scepter</option>
				 			<option value="seiki">Seiki</option>
				 			<option value="sennheiser">Sennheiser</option>
				 			<option value="senso">Senso</option>
				 			<option value="sharp">Sharp</option>
				 			<option value="shure">Shure</option>
				 			<option value="skullcandy">Skullcandy</option>
				 			<option value="sonos">Sonos</option>
				 			<option value="sony">Sony</option>
				 			<option value="sol">Sol Republic</option>
				 			<option value="rovking">Rovking</option>
				 			<option value="soundbot">SoundBot</option>
				 			<option value="sound_intone">Sound Intone</option>
				 			<option value="soundmagic">SoundMAGIC</option>
				 			<option value="soundpeats">SoundPEATS</option>
				 			<option value="soundworks">Soundworks</option>
				 			<option value="symphonized">Symphonized</option>
				 			<option value="taotronics">Taotronics</option>
				 			<option value="tcl">TCL</option>
				 			<option value="toshiba">Toshiba</option>
				 			<option value="toysdone">Toysdone</option>
				 			<option value="treblab">TREBLAB</option>
				 			<option value="ultimate">Ultimate Ears</option>
				 			<option value="vmoda">V-Moda</option>
				 			<option value="vivo">Vivo</option>
				 			<option value="vizio">Vizio</option>
				 			<option value="xiaomi">Xiaomi</option>
				 			<option value="xovision">XO Vision</option>
				 			<option value="yamaha">Yamaha</option>
				 			<option value="others">Others</option>
				 		</select>
				 	</div>
				 	

				 	<div class="drop_item drop_last">
				 		<select class="stores" name="store">
				 			<option value="">Stores</option>
				 			<option value="amazon">Amazon</option>
				 			<option value="bestbuy">BestBuy</option>
				 			<option value="ebay">eBay</option>
				 			<option value="newegg">NewEgg</option>
				 			<option value="walmart">Walmart</option>
				 			<option value="others">Others</option>
				 		</select>
				 	</div>
				 	<div style="clear: both;"></div>
				 </div>

				 <!--price box starts -->
				 <div class="price_box">
				 	<!--from box starts-->
				 	<div class="from_box">
				 		<div class="from">From:</div>
				 		<div class="num_box">
				 			<div class="curr">USD</div>
				 			<div class="price_inp">
				 				<input type="number" name="money_one" value="0" style="width: 100%; height: 100%; text-align: right;" />
				 			</div>
				 			<div style="clear: both;"></div>
				 		</div>
				 		<div style="clear: both;"></div>
				 	</div>
				 	<!--from box ends-->

				 	<!--to box starts-->
				 	<div class="to_box">
				 		<div class="to">To:</div>
				 		<div class="num_box">
				 			<div class="curr">USD</div>
				 			<div class="price_inp">
				 				<input type="number" name="money_two" value="100" style="width: 100%; height: 100%; text-align: right;" />
				 			</div>
				 			<div style="clear: both;"></div>
				 		</div>
				 		<div style="clear: both;"></div>
				 	</div>
				 	<!--to box ends-->
				 	<div style="clear: both;"></div>
				 </div>
				 <!--price box ends-->

				 <div class="deal_but">
				 	<button type="submit" name="apply">Apply</button>
				 </div>
				</form>
				 <!--deal drop box ends-->
				 <?php
				 if($fail == 001){?>
				 <div class="fail">Sorry no match found</div>
				<?php } ?>

				 <!--applyed box-->
				 <?php

				 	if($apply == 001){
				 ?>
				 <div class="applyed_box">
		<?php
		
		if($brand == 'others' && $store == 'others'){
		$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two  order by id DESC LIMIT 5");
	}else if($brand == 'others'){
		$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store' && price >= $price_one && price <= $price_two order by id DESC LIMIT 5 ");
	}else if($store == 'others'){
		$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two order by id DESC LIMIT 5");
	}else{
		$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two order by id DESC LIMIT 5");
	}
	
	while($fetch_deal = $select_deal -> fetch_assoc()){
		$deal_img = $fetch_deal['image'];
		$deal_title = $fetch_deal['title'];
		$deal_content = $fetch_deal['content'];
		$deal_date = $fetch_deal['date'];
		$deal_poster = $fetch_deal['poster'];
		$deal_disccount = $fetch_deal['disccount'];
		$deal_store = $fetch_deal['store'];
		$deal_price = $fetch_deal['price'];
		$deal_id = $fetch_deal['id'];
		$deal_link = $fetch_deal['link'];
		$deal_category = $fetch_deal['category'];
		$strlen = strlen($deal_title);
		$txt_strlen = strlen($deal_content);

				?>


				<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="hot_main_display">
					<!--main title-->
					<div class="hot_main_title">
						<?php echo substr($deal_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
					</div>
					<!-- main title ends-->
					<!-- hot img box-->
					<div class="hot_image_box">
						<img src="<?php echo $deal_img; ?>" width="100%" height="100%"/>
						<?php if($deal_disccount != ''){ ?>
						<div class="hot_extra"><?php echo $deal_disccount; ?>% 0FF</div>
							<?php } ?>
					</div>
					<!-- hot image box ends-->
					<?php if($deal_price != '' && $deal_store != ''){ ?>
					<div class="hot_price">
						<span>$<?php echo $deal_price; ?></span> (at <?php echo $deal_store; ?>)
					</div>
					<?php } ?>

					<div class="hot_txt"><?php echo substr( $deal_content,0,210); if($txt_strlen > 210){echo '...';} ?> </div>
					<?php 
						$find_cat = $conn -> query("SELECT * FROM $deal_category WHERE title = '$deal_title' ");
						if($find_cat){
						$count_cat = mysqli_num_rows($find_cat);
						if($count_cat == 1){
					?>

					<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="details_link">Check details... </div></a>
				<?php } } ?>
				
					
				</div></a>

				<div class="line"></div>
				<?php } ?>

				 </div>
				<?php }else{ ?>
				 <!--applyed box end-->

				 <!--non apply begins-->
				 <?php 
				 $select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals'   order by id DESC LIMIT 5");
	
	while($fetch_deal = $select_deal -> fetch_assoc()){
		$deal_img = $fetch_deal['image'];
		$deal_title = $fetch_deal['title'];
		$deal_content = $fetch_deal['content'];
		$deal_date = $fetch_deal['date'];
		$deal_poster = $fetch_deal['poster'];
		$deal_disccount = $fetch_deal['disccount'];
		$deal_store = $fetch_deal['store'];
		$deal_price = $fetch_deal['price'];
		$deal_id = $fetch_deal['id'];
		$deal_link = $fetch_deal['link'];
		$deal_category = $fetch_deal['category'];
		$strlen = strlen($deal_title);
		$txt_strlen = strlen($deal_content);

		?>

		<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="hot_main_display">
					<!--main title-->
					<div class="hot_main_title">
						<?php echo substr($deal_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
					</div>
					<!-- main title ends-->
					<!-- hot img box-->
					<div class="hot_image_box">
						<img src="<?php echo $deal_img; ?>" width="100%" height="100%"/>
						<?php if($deal_disccount != ''){ ?>
						<div class="hot_extra"><?php echo $deal_disccount; ?>% 0FF</div>
							<?php } ?>
					</div>
					<!-- hot image box ends-->
					<?php if($deal_price != '' && $deal_store != ''){ ?>
					<div class="hot_price">
						<span>$<?php echo $deal_price; ?></span> (at <?php echo $deal_store; ?>)
					</div>
					<?php } ?>

					<div class="hot_txt"><?php echo substr( $deal_content,0,210); if($txt_strlen > 210){echo '...';} ?> </div>
					<?php 
						$find_cat = $conn -> query("SELECT * FROM $deal_category WHERE title = '$deal_title' ");
						if($find_cat){
						$count_cat = mysqli_num_rows($find_cat);
						if($count_cat == 1){
					?>

					<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="details_link">Check details... </div></a>
				<?php } }?>
			
				</div></a>

				<div class="line"></div>
				<?php } 
					}
				?>

				 <!--non apply ends-->
				 <!--know box begins -->
				 <?php
				 	$find_fact = $conn -> query("SELECT * FROM facts WHERE cat = 'all'");
				 	$count_fact = mysqli_num_rows($find_fact);
				 	if($count_fact > 0){
				 		$fet_fact = $find_fact -> fetch_assoc();
				 		$fact_title = $fet_fact['title'];
				 		$fact_text = $fet_fact['text'];
				 ?>
				 <div class="know_box">
				 	<div class="know_title">
				 		<?php echo $fact_title; ?>
				 	</div>
				 	<div class="know_text">
				 		<?php echo substr($fact_text,0 ,100); 
				 			if(strlen($fact_text) > 100){
				 		?> <span>Learn more...</span>

				 	<?php } ?>
				 	</div>				
				  </div>
				<?php } ?>
				 <!--know  box ends -->

				 <script>
				 	$(document).ready(function(evt){
				 		$('.know_text span').click(function(e){
				 			$('.know_text span').hide();
				 			$('.know_text').append("<?php echo substr($fact_text, 100); ?>");
				 		});
				 	});
				 </script>
				

			</div>
			<!--deal box ends-->
</div>
<!-- body container ends-->