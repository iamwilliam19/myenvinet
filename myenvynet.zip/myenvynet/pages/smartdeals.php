<?php

	$brand = $_GET['branded'];
	$store = $_GET['stored'];
	$price_one = $_GET['price_one'];
	$price_two = $_GET['price_two'];
	$apply = $_GET['apply'];
	$fail = $_GET['fail'];
	$feature = $_GET['feature'];

?>

<!-- body container starts-->
<div class="body_container">
			<!--deals box start-->
			<div class="deals_box">
				<!--deal links start-->
				<div class="deal_links">
					<table width="auto">
						<tr>
						
							<td ><a href="?action=deals">Deals</a> </td>

						<td class="deal_selected"><a href="?action=smartdeals">Smartphones</a></td>
						<td><a href="?action=tvdeals">TVs</a></td>
						<td><a href="?action=laptopdeals">Laptops</a></td>
						<td><a href="?action=speakerdeals">Speakers</a></td>
						<td><a href="?action=sounddeals">Sounds</a></td>			
					</tr>
					</table>	
				</div>
				<!--deal links ends-->

				<div class="deal_intro">
				The best deals on smartphones.
				 </div>

				 <!--deal sort-->
				 <div class="deal_sort">
				 	Sort by:
				 </div>
				 <!--deal sort ends-->

				 <!--deal drop box-->
				 <form action="db/alldeal.php?sender=smart_deal" method="post" class="smart_deal_form">
				 <div class="deal_drop_box">
				 	<div class="drop_item_smart">
				 		<select class="brands" name="brand">
				 			<option value="">Brands</option>
				 			<option value="10.or">10.or</option>
				 			
				 			<option value="apple">Apple</option>
				 			<option value="asus">ASUS</option>
				 			
				 			<option value="blackberry">Blackberry</option>
				 			<option value="blu">BLU</option>
				 			<option value="bluedio">Bluedio</option>
				 			
				 			<option value="google">Google</option>
				 			
				 			<option value="htc">HTC</option>
				 			<option value="huawei">
				 				Huawei
				 			</option>
				 			
				 			<option value="infocus">Infocus</option>
				 			
				 			<option value="lg">LG</option>
				 			
				 			<option value="oneplus">OnePlus</option>
				 			<option value="oppo">Oppo</option>
				 			
				 			<option value="samsung">Samsung</option>
				 		
				 			<option value="sony">Sony</option>
				 		
				 			<option value="vizio">Vizio</option>
				 			<option value="xiaomi">Xiaomi</option>
				 		
				 			<option value="others">Others</option>
				 		</select>
				 	</div>
				 	

				 	<div class="drop_item_smart ">
				 		<select class="stores" name="store">
				 			<option value="">Stores</option>
				 			<option value="amazon">Amazon</option>
				 			<option value="bestbuy">BestBuy</option>
				 			<option value="ebay">eBay</option>
				 			<option value="newegg">NewEgg</option>
				 			<option value="walmart">Walmart</option>
				 			<option value="others">Others</option>
				 		</select>
				 	</div>

				 	<div class="drop_item_smart drop_last">
				 		<select class="smart_feature" name="feature">
				 			<option value="">Features</option>
				 			<option value="amazing_software">Amazing software</option>
				 			<option value="ai">Arteficial Inteligence</option>
				 			<option value="augumented_reality">Augumented reality</option>
				 			<option value="awesome_camera">Awesome camera</option>
				 			<option value="best_display">Best displays</option>
				 			<option value="blazing_fast">Blazingly fast</option>
				 			<option value="dumb_phones">Dumb phones</option>
				 			<option value="gaming">Gaming</option>
				 			<option value="gorgeous_design">Gorgeous design</option>
				 			<option value="long_battery_life">Long battery life</option>
				 			<option value="notchless">Notchless</option>
				 			<option value="water_resistant">Water resistant</option>
				 			<option value="wireless_charging">Wireless charging</option>
				 		</select>
				 	</div>
				 	<div style="clear: both;"></div>
				 </div>

				 <!--price box starts -->
				 <div class="price_box">
				 	<!--from box starts-->
				 	<div class="from_box">
				 		<div class="from">From:</div>
				 		<div class="num_box">
				 			<div class="curr">USD</div>
				 			<div class="price_inp">
				 				<input type="number" name="money_one" value="0" style="width: 100%; height: 100%; text-align: right;" />
				 			</div>
				 			<div style="clear: both;"></div>
				 		</div>
				 		<div style="clear: both;"></div>
				 	</div>
				 	<!--from box ends-->

				 	<!--to box starts-->
				 	<div class="to_box">
				 		<div class="to">To:</div>
				 		<div class="num_box">
				 			<div class="curr">USD</div>
				 			<div class="price_inp">
				 				<input type="number" name="money_two" value="100" style="width: 100%; height: 100%; text-align: right;" />
				 			</div>
				 			<div style="clear: both;"></div>
				 		</div>
				 		<div style="clear: both;"></div>
				 	</div>
				 	<!--to box ends-->
				 	<div style="clear: both;"></div>
				 </div>
				 <!--price box ends-->

				 <div class="deal_but">
				 	<button type="submit" name="apply">Apply</button>
				 </div>
				</form>
				 <!--deal drop box ends-->
				 <?php
				 if($fail == 001){?>
				 <div class="fail">Sorry no match found</div>
				<?php } ?>

				 <!--applyed box-->
				 <?php

				 	if($apply == 001){
				 ?>
				 <div class="applyed_box">
		<?php
				
	if($brand == 'others' && $store == 'others'){
		if($feature != ''){
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && feature = '$feature' && category = 'phones' order by id DESC LIMIT 5");
		}else{
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && category = 'phones'  order by id DESC LIMIT 5");
		}

	}else if($brand == 'others'){
		if($feature != ''){
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store' && price >= $price_one && price <= $price_two && category = 'phones' && feature = '$feature' order by id DESC LIMIT 5 ");
		}else{
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store' && price >= $price_one && price <= $price_two && category = 'phones' order by id DESC LIMIT 5 ");
		}
	}else if($store == 'others'){
		if($feature != ''){
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && category = 'phones' && feature = '$feature' order by id DESC LIMIT 5");
		}else{
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && category = 'phones' order by id DESC LIMIT 5");
		}
	}else{
		if($feature != ''){
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && category = 'phones' && feature = '$feature' order by id DESC LIMIT 5");
		}else{
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && category = 'phones' order by id DESC LIMIT 5");
		}
	}
	
	while($fetch_deal = $select_deal -> fetch_assoc()){
		$deal_img = $fetch_deal['image'];
		$deal_title = $fetch_deal['title'];
		$deal_content = $fetch_deal['content'];
		$deal_date = $fetch_deal['date'];
		$deal_poster = $fetch_deal['poster'];
		$deal_disccount = $fetch_deal['disccount'];
		$deal_store = $fetch_deal['store'];
		$deal_price = $fetch_deal['price'];
		$deal_id = $fetch_deal['id'];
		$deal_link = $fetch_deal['link'];
		$deal_category = $fetch_deal['category'];
		$strlen = strlen($deal_title);
		$txt_strlen = strlen($deal_content);

				?>


				<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="hot_main_display">
					<!--main title-->
					<div class="hot_main_title">
						<?php echo substr($deal_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
					</div>
					<!-- main title ends-->
					<!-- hot img box-->
					<div class="hot_image_box">
						<img src="<?php echo $deal_img; ?>" width="100%" height="100%"/>
						<?php if($deal_disccount != ''){ ?>
						<div class="hot_extra"><?php echo $deal_disccount; ?>% 0FF</div>
							<?php } ?>
					</div>
					<!-- hot image box ends-->
					<?php if($deal_price != '' && $deal_store != ''){ ?>
					<div class="hot_price">
						<span>$<?php echo $deal_price; ?></span> (at <?php echo $deal_store; ?>)
					</div>
					<?php } ?>

					<div class="hot_txt"><?php echo substr( $deal_content,0,210); if($txt_strlen > 210){echo '...';} ?> </div>
					<?php 
						$find_cat = $conn -> query("SELECT * FROM $deal_category WHERE title = '$deal_title' ");
						if($find_cat){
						$count_cat = mysqli_num_rows($find_cat);
						if($count_cat == 1){
					?>

					<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="details_link">Check details... </div></a>
				<?php } } ?>
				
					
				</div></a>

				<div class="line"></div>
				<?php } ?>

				 </div>
				<?php }else{ ?>
				 <!--applyed box end-->

				 <!--non apply begins-->
				 <?php 
				 $select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && category = 'phones'  order by id DESC LIMIT 5");
	
	while($fetch_deal = $select_deal -> fetch_assoc()){
		$deal_img = $fetch_deal['image'];
		$deal_title = $fetch_deal['title'];
		$deal_content = $fetch_deal['content'];
		$deal_date = $fetch_deal['date'];
		$deal_poster = $fetch_deal['poster'];
		$deal_disccount = $fetch_deal['disccount'];
		$deal_store = $fetch_deal['store'];
		$deal_price = $fetch_deal['price'];
		$deal_id = $fetch_deal['id'];
		$deal_link = $fetch_deal['link'];
		$deal_category = $fetch_deal['category'];
		$strlen = strlen($deal_title);
		$txt_strlen = strlen($deal_content);

		?>

		<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="hot_main_display">
					<!--main title-->
					<div class="hot_main_title">
						<?php echo substr($deal_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
					</div>
					<!-- main title ends-->
					<!-- hot img box-->
					<div class="hot_image_box">
						<img src="<?php echo $deal_img; ?>" width="100%" height="100%"/>
						<?php if($deal_disccount != ''){ ?>
						<div class="hot_extra"><?php echo $deal_disccount; ?>% 0FF</div>
							<?php } ?>
					</div>
					<!-- hot image box ends-->
					<?php if($deal_price != '' && $deal_store != ''){ ?>
					<div class="hot_price">
						<span>$<?php echo $deal_price; ?></span> (at <?php echo $deal_store; ?>)
					</div>
					<?php } ?>

					<div class="hot_txt"><?php echo substr( $deal_content,0,210); if($txt_strlen > 210){echo '...';} ?> </div>
					<?php 
						$find_cat = $conn -> query("SELECT * FROM $deal_category WHERE title = '$deal_title' ");
						if($find_cat){
						$count_cat = mysqli_num_rows($find_cat);
						if($count_cat == 1){
					?>

					<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="details_link">Check details... </div></a>
				<?php }} ?>
			
				</div></a>

				<div class="line"></div>
				<?php } 
					}
				?>

				 <!--non apply ends-->
				 <!--know box begins -->
				 <?php
				 	$find_fact = $conn -> query("SELECT * FROM facts WHERE cat = 'smartdeal'");
				 	$count_fact = mysqli_num_rows($find_fact);
				 	if($count_fact > 0){
				 		$fet_fact = $find_fact -> fetch_assoc();
				 		$fact_title = $fet_fact['title'];
				 		$fact_text = $fet_fact['text'];
				 ?>
				 <div class="know_box">
				 	<div class="know_title">
				 		<?php echo $fact_title; ?>
				 	</div>
				 	<div class="know_text">
				 		<?php echo substr($fact_text,0 ,100); 
				 			if(strlen($fact_text) > 100){
				 		?> <span>Learn more...</span>

				 	<?php } ?>
				 	</div>				
				  </div>
				<?php } ?>
				 <!--know  box ends -->

				 <script>
				 	$(document).ready(function(evt){
				 		$('.know_text span').click(function(e){
				 			$('.know_text span').hide();
				 			$('.know_text').append("<?php echo substr($fact_text, 100); ?>");
				 		});
				 	});
				 </script>
				

			</div>
			<!--deal box ends-->
</div>
<!-- body container ends-->