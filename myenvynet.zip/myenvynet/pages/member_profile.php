
<?php 
	$poster_email = $_GET['poster_email'];

	//select the poster details
	$sel_poster = $conn -> query("SELECT * FROM accounts WHERE email = '$poster_email'");
	//fetch details
	$fet_det = $sel_poster -> fetch_assoc();
	$poster_name = $fet_det['name'];
	$poster_img = $fet_det['image'];
	$poster_bio = $fet_det['bio'];
	$poster_signed_up_date = $fet_det['signed_up_date'];
	$poster_website = $fet_det['website'];
	$poster_facebook = $fet_det['facebook'];
	$poster_twitter = $fet_det['twitter'];
	$poster_lastseen = $fet_det['last_seen'];
	$poster_section_covered = $fet_det['section_covered'];
	$mypro_action = $_GET['pro_action'];
?>

<!-- body container starts-->
	<div class="body_container">
		<!--profile box begins-->
		<div class="profile_box">
			<!--profile name starts-->
				<div class="profile_name"><?php echo $poster_name; ?></div>
			<!--profile name ends-->

			<!--profile pic begins-->
			<div class="profile_pic">
				<?php if($poster_img != ''){?>
				<img src="<?php echo $poster_img; ?>" width="100%" height="100%" style="border-radius:100px;" />
			<?php }else{ ?>
				<div class="profile_letter">
					<?php
						echo substr($poster_name,0,1);
					?>
				</div>
			<?php } ?>
			</div>
			<!--profile pic ends-->

			<!--profile links starts-->
			<div class="profile_link_box">
				<ul>
					<a href="?pro_action=publications&action=member_profile&poster_email=<?php echo $poster_email; ?>"><li <?php if($mypro_action != 'about'){ ?> class="profile_selected"
						<?php } ?>>Publications</li></a>
					<a href="?pro_action=about&action=member_profile&poster_email=<?php echo $poster_email; ?>"><li
						<?php if($mypro_action == 'about'){ ?> class="profile_selected"
						<?php } ?>
						>About member</li></a>
				</ul>
			</div>
			<!-- proflie links end-->

			<!--profile body-->
			<div class="profile_body">
				<?php 
					if($mypro_action == 'about'){
						include('./pages/about.php');
					}else{
						include('./pages/profile_publish.php');
					}
				?>
			</div>
			<!--profile body-->
		</div>
		<!--profie box ends-->

			
	</div>
<!-- body container ends-->
