<?php

	$brand = $_GET['branded'];
	$store = $_GET['stored'];
	$price_one = $_GET['price_one'];
	$price_two = $_GET['price_two'];
	$apply = $_GET['apply'];
	$fail = $_GET['fail'];
	$feature = $_GET['feature'];
	$type = $_GET['type'];

?>

<!-- body container starts-->
<div class="body_container">
			<!--deals box start-->
			<div class="deals_box">
				<!--deal links start-->
				<div class="deal_links">
					<table width="auto">
						<tr>
						
							<td ><a href="?action=deals">Deals</a> </td>

						<td><a href="?action=smartdeals">Smartphones</a></td>
						<td><a href="?action=tvdeals">TVs</a></td>
						<td><a href="?action=laptopdeals">Laptops</a></td>
						<td  class="deal_selected"><a href="?action=speakerdeals">Speakers</a></td>
						<td><a href="?action=sounddeals">Sounds</a></td>				
					</tr>
					</table>	
				</div>
				<!--deal links ends-->

				<div class="deal_intro">
				Get the best PC deals out there.
				 </div>

				 <!--deal sort-->
				 <div class="deal_sort">
				 	Sort by:
				 </div>
				 <!--deal sort ends-->

				 <!--deal drop box-->
				 <form action="db/alldeal.php?sender=speaker_deal" method="post" class="speaker_deal_form">
				 <div class="deal_drop_box">
				 	<div class="drop_item_smart">
				 		<select class="brands" name="brand">
				 			<option value="">Brands</option>
				 			
				 			
				 			<option value="acoustic_audio">Acoustic audio</option>

				 			<option value="altec">Altec lansing</option>
				 			<option value="amazon">Amazon</option>
				 			
				 			
				 			<option value="apple">Apple</option>

				 			<option value="audio_engine">Audio engine</option>
				 			<option value="audio_technica">Audio-technica</option>
				 			<option value="bang&olufen">Bang &amp; Olufsen</option>
				 			
				 			<option value="beats">Beats by Dre</option>
				 			<option value="bose">Bose</option>
				 			<option value="bowers">Bowers &amp; Wilkins </option>
				 			
				 			<option value="Cambridge">Cambridge Soundworks</option>
				 			<option value="cerwin">Cerwin-
				 			Vega</option>
				 			
				 			<option value="creative">Creative</option>
				 			<option value="cyber">Cyber acoustics</option>
				 			<option value="definitive">Definitive</option>
				 			<option value="dell">Dell</option>
				 			<option value="edifier">Edifier</option>
				 			<option value="fenda">F &amp; D Fenda</option>
				 			
				 			<option value="google">Google</option>
				 			<option value="akg">Harman Kardon</option>
				 			
				 			
				 			<option value="ion">ION</option>
				 			
				 			<option value="infinity">Infinity</option>
				 			<option value="jbl">JBL</option>
				 			
				 			<option value="jvc">JVC</option>
				 			
				 			<option value="kenwood">Kenwood</option>
				 			<option value="klipsch">Klipsch</option>
				 			
				 			<option value="lg">LG</option>
				 			<option value="logitech">Logitech</option>
				 			<option value="martin">Martin Logan</option>
				 			
				 			<option value="mpow">Mpow</option>
				 			
				 			
				 			<option value="onkyo">Onkyo</option>
				 			
				 			
				 			<option value="photive">Photive</option>
				 			<option value="pioneer">Pioneer</option>
				 			
				 			<option value="polk">Polk Audio</option>
				 			<option value="pyle">Pyle</option>
				 			
				 			
				 			<option value="rock">Rockford Fosgate</option>
				 			<option value="samsung">Samsung</option>
				 			
				 			<option value="sennheiser">Sennheiser</option>
				 			
				 			<option value="sonos">Sonos</option>
				 			<option value="sony">Sony</option>
				 			
				 			<option value="soundbot">SoundBot</option>
				 			
				 			<option value="symphonized">Symphonized</option>
				 			
				 			<option value="ultimate">Ultimate Ears</option>
				 			
				 			<option value="yamaha">Yamaha</option>
				 			<option value="others">Others</option>
				 		</select>
				 	</div>
				 	

				 	<div class="drop_item_smart ">
				 		<select class="stores" name="store">
				 			<option value="">Stores</option>
				 			<option value="amazon">Amazon</option>
				 			<option value="bestbuy">BestBuy</option>
				 			<option value="ebay">eBay</option>
				 			<option value="newegg">NewEgg</option>
				 			<option value="walmart">Walmart</option>
				 			<option value="others">Others</option>
				 		</select>
				 	</div>

				 	<div class="drop_item_smart drop_last">
				 		<select class="laptop_types" name="type">
				 			<option value="">Types</option>
				 			<option value="book_shelf">Book shelf</option>
				 			<option value="car_speaker">Car speakers</option>
				 			<option value="center_channel">Center channel</option>
				 			<option value="computer">Computer</option>
				 			<option value="floor_standing">Floor standing</option>
				 			<option value="inwall/inceiling">In-wall/In-ceiling</option>
				 			<option value="loud_speakers">Loud speakers</option>
				 			<option value="on_wall">On-wall</option>
				 			<option value="outdoor">Outdoor</option>
				 			<option value="smart_speaker">Smart speaker</option>
				 			<option value="sound_bars">Sound bars</option>
				 			<option value="subwoofers">Subwoofers</option>
				 			<option value="water_resistant">Water resistant</option>
				 			<option value="wirelessandportable">Wireless &amp; portable</option>
				 		</select>
				 	</div>
				 	<div style="clear: both;"></div>
				 </div>

				 <!--price box starts -->
				 <div class="price_box">
				 	<!--from box starts-->
				 	<div class="from_box">
				 		<div class="from">From:</div>
				 		<div class="num_box">
				 			<div class="curr">USD</div>
				 			<div class="price_inp">
				 				<input type="number" name="money_one" value="0" style="width: 100%; height: 100%; text-align: right;" />
				 			</div>
				 			<div style="clear: both;"></div>
				 		</div>
				 		<div style="clear: both;"></div>
				 	</div>
				 	<!--from box ends-->

				 	<!--to box starts-->
				 	<div class="to_box">
				 		<div class="to">To:</div>
				 		<div class="num_box">
				 			<div class="curr">USD</div>
				 			<div class="price_inp">
				 				<input type="number" name="money_two" value="1000" style="width: 100%; height: 100%; text-align: right;" />
				 			</div>
				 			<div style="clear: both;"></div>
				 		</div>
				 		<div style="clear: both;"></div>
				 	</div>
				 	<!--to box ends-->
				 	<div style="clear: both;"></div>
				 </div>
				 <!--price box ends-->

				 <div class="deal_but">
				 	<button type="submit" name="apply">Apply</button>
				 </div>
				</form>
				 <!--deal drop box ends-->
				 <?php
				 if($fail == 001){?>
				 <div class="fail">Sorry no match found</div>
				<?php } ?>

				 <!--applyed box-->
				 <?php

				 	if($apply == 001){
				 ?>
				 <div class="applyed_box">
		<?php
				
	if($brand == 'others' && $store == 'others'){
		if($type != ''){
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && types = '$type' && category = 'speakers' order by id DESC LIMIT 5");
		}else{
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && price >= $price_one && price <= $price_two && category = 'speakers'  order by id DESC LIMIT 5");
		}

	}else if($brand == 'others'){
		if($type != ''){
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store' && price >= $price_one && price <= $price_two && category = 'speakers' && types = '$type' order by id DESC LIMIT 5 ");
		}else{
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && store = '$store' && price >= $price_one && price <= $price_two && category = 'speakers' order by id DESC LIMIT 5 ");
		}
	}else if($store == 'others'){
		if($type != ''){
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && category = 'speakers' && types = '$type' order by id DESC LIMIT 5");
		}else{
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && price >= $price_one && price <= $price_two && category = 'speakers' order by id DESC LIMIT 5");
		}
	}else{
		if($type != ''){
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && category = 'speakers' && types = '$type' order by id DESC LIMIT 5");
		}else{
			$select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && brand = '$brand' && store = '$store' && price >= $price_one && price <= $price_two && category = 'speakers' order by id DESC LIMIT 5");
		}
	}
	
	while($fetch_deal = $select_deal -> fetch_assoc()){
		$deal_img = $fetch_deal['image'];
		$deal_title = $fetch_deal['title'];
		$deal_content = $fetch_deal['content'];
		$deal_date = $fetch_deal['date'];
		$deal_poster = $fetch_deal['poster'];
		$deal_disccount = $fetch_deal['disccount'];
		$deal_store = $fetch_deal['store'];
		$deal_price = $fetch_deal['price'];
		$deal_id = $fetch_deal['id'];
		$deal_link = $fetch_deal['link'];
		$deal_category = $fetch_deal['category'];
		$strlen = strlen($deal_title);
		$txt_strlen = strlen($deal_content);

				?>


				<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="hot_main_display">
					<!--main title-->
					<div class="hot_main_title">
						<?php echo substr($deal_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
					</div>
					<!-- main title ends-->
					<!-- hot img box-->
					<div class="hot_image_box">
						<img src="<?php echo $deal_img; ?>" width="100%" height="100%"/>
						<?php if($deal_disccount != ''){ ?>
						<div class="hot_extra"><?php echo $deal_disccount; ?>% 0FF</div>
							<?php } ?>
					</div>
					<!-- hot image box ends-->
					<?php if($deal_price != '' && $deal_store != ''){ ?>
					<div class="hot_price">
						<span>$<?php echo $deal_price; ?></span> (at <?php echo $deal_store; ?>)
					</div>
					<?php } ?>

					<div class="hot_txt"><?php echo substr( $deal_content,0,210); if($txt_strlen > 210){echo '...';} ?> </div>
					
				</div></a>

				<div class="line"></div>
				<?php } ?>

				 </div>
				<?php }else{ ?>
				 <!--applyed box end-->

				 <!--non apply begins-->
				 <?php 
				 $select_deal = $conn -> query("SELECT * FROM news WHERE section = 'deals' && category = 'speakers' order by id DESC LIMIT 5");
	
	while($fetch_deal = $select_deal -> fetch_assoc()){
		$deal_img = $fetch_deal['image'];
		$deal_title = $fetch_deal['title'];
		$deal_content = $fetch_deal['content'];
		$deal_date = $fetch_deal['date'];
		$deal_poster = $fetch_deal['poster'];
		$deal_disccount = $fetch_deal['disccount'];
		$deal_store = $fetch_deal['store'];
		$deal_price = $fetch_deal['price'];
		$deal_id = $fetch_deal['id'];
		$deal_link = $fetch_deal['link'];
		$deal_category = $fetch_deal['category'];
		$strlen = strlen($deal_title);
		$txt_strlen = strlen($deal_content);

		?>

		<a href="?action=view&gv=<?php  echo $deal_id ;?>&dir=deals"><div class="hot_main_display">
					<!--main title-->
					<div class="hot_main_title">
						<?php echo substr($deal_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
					</div>
					<!-- main title ends-->
					<!-- hot img box-->
					<div class="hot_image_box">
						<img src="<?php echo $deal_img; ?>" width="100%" height="100%"/>
						<?php if($deal_disccount != ''){ ?>
						<div class="hot_extra"><?php echo $deal_disccount; ?>% 0FF</div>
							<?php } ?>
					</div>
					<!-- hot image box ends-->
					<?php if($deal_price != '' && $deal_store != ''){ ?>
					<div class="hot_price">
						<span>$<?php echo $deal_price; ?></span> (at <?php echo $deal_store; ?>)
					</div>
					<?php } ?>

					<div class="hot_txt"><?php echo substr( $deal_content,0,210); if($txt_strlen > 210){echo '...';} ?> </div>
					
			
				</div></a>

				<div class="line"></div>
				<?php } 
					}
				?>

				 <!--non apply ends-->
				 <!--know box begins --> 
				 <?php
				 	$find_fact = $conn -> query("SELECT * FROM facts WHERE cat = 'speakerdeals'");
				 	$count_fact = mysqli_num_rows($find_fact);
				 	if($count_fact > 0){
				 		$fet_fact = $find_fact -> fetch_assoc();
				 		$fact_title = $fet_fact['title'];
				 		$fact_text = $fet_fact['text'];
				 ?>
				 <div class="know_box">
				 	<div class="know_title">
				 		<?php echo $fact_title; ?>
				 	</div>
				 	<div class="know_text">
				 		<?php echo substr($fact_text,0 ,100); 
				 			if(strlen($fact_text) > 100){
				 		?> <span>Learn more...</span>

				 	<?php } ?>
				 	</div>				
				  </div>
				<?php } ?>
				 <!--know  box ends -->

				 <script>
				 	$(document).ready(function(evt){
				 		$('.know_text span').click(function(e){
				 			$('.know_text span').hide();
				 			$('.know_text').append("<?php echo substr($fact_text, 100); ?>");
				 		});
				 	});
				 </script>
				

			</div>
			<!--deal box ends-->
</div>
<!-- body container ends-->