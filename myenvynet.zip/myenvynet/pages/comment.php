<?php
	$remark = $_GET['remark'];
	$email = $_SESSION['email'];
	//fetch commenter name
	$srch_name = $conn -> query("SELECT * FROM accounts WHERE email = '$email'");
	$fetch_det = $srch_name -> fetch_assoc();
	$poster_name = $fetch_det['name'];
	$poster_img = $fetch_det['image'];
?>

<body>
	<!-- body container starts-->
		<div class="body_container">
			
			<div class="comment_title">
				What do you think what whtabout <?php echo ' '.$view_title.'  ?'; ?>
			</div>

			<!--remark -->
			<?php if ($remark == 001){?>
			<div class="remark">comment uploaded</div>
		<?php } ?>
			<!--remark ends-->

			<!-- comment box -->
			<div class="comment_box">
				<?php 
					if($_SESSION['email'] != ''){
				 ?>
			<!--commenter box-->
			<div class="commenter_box">
				<?php if($poster_img != ''){?>
					<div class="commenter_pic">
					<img src="<?php echo $poster_img; ?>" width="100%" height="100%" />
				</div>
			<?php } else{
				$firstchar = substr($poster_name,0, 1);
			 ?>

				<div class="commenter_letter">
					<?php echo strtoupper($firstchar);  ?>
				</div>
			<?php } ?>
				<div class="commenter_name">
					<?php echo $poster_name; ?>
				</div>

				<div style="clear: both;"></div>
			</div>
			<!--commenter box ends-->

		<?php } ?>
				<form action="db/comment_pro.php?dir=<?php echo $dir; ?>&title=<?php echo $view_title;?>&cp=<?php echo $cp ;?>" method="post" class="comment_form">
				<!--commwnet text-->
				<div class="comment_text">
					<div class="comment_error"></div>
					
						<textarea placeholder="Write something.." name="comment_text" class="comment" ><?php echo $_SESSION['comment']; ?></textarea>
					
				</div>
				<!--comment text ends-->
				<?php 
					if($_SESSION['email'] == ''){
				?>
				<!-- sign in dir box-->
				<div class="sign_in_dir_box">
					<div class="signin_up_box">
						<div class="signin_up">Sign in / Sign up</div>
						<div class="signin_up_icon_box">
							<div class="signin_up_fb"><i class="fab fa-facebook-f"></i></div>

							<div class="signin_up_gp"><i class="fab fa-google-plus-g"></i></div>

							<a href="?action=sign_in"><div class="signin_up_cp"><i class="fas fa-user-alt"></i></div></a>

							<div style="clear: both;"></div>
						</div>
						<div style="clear: both;"></div>
					</div>

					<!--fake button-->
					<div class="fake_button">Post Comment</div>
					<!-- fake button ends-->
				</div>
				<!--sign in dir box ends-->

			<?php }else{?>

				<!--main button-->
				<button type="submit" class="main_button">
					Post Comment
				</button>
				<!-- main buttton ends-->
			<?php } ?>
			</form>


			<!-- posting rules start-->
			<div class="posting_rules">Posting rules</div>

			<div class="rule_box">
				<div class="rule_icon">
					<i class="fas fa-check correct"></i>
				</div>
				<div class="rule_text">
					Please you can only write your comment using English.
				</div>
				<div style="clear: both;"></div>
			</div>

			<div class="rule_box">
				<div class="rule_icon wrong">
					<i class="fas fa-times"></i>
				</div>
				<div class="rule_text">
					Refrain from personal attack, rude or foul languages.
				</div>
				<div style="clear: both;"></div>
			</div>


			<div class="rule_box">
				<div class="rule_icon wrong">
					<i class="fas fa-times"></i>
				</div>
				<div class="rule_text">
					Do not display tribal bigotry or disdain for a particular group of people. Show love and respect, even admiration.
				</div>
				<div style="clear: both;"></div>
			</div>

			<div class="rule_box">
				<div class="rule_icon">
					<i class="fas fa-check correct"></i>
				</div>
				<div class="rule_text">
					Please ignore trolls or report them.
				</div>
				<div style="clear: both;"></div>
			</div>

			<div class="rule_box">
				<div class="rule_icon wrong">
					<i class="fas fa-times"></i>
				</div>
				<div class="rule_text">
					Do not post adverts, links to adult materials or spam.
				</div>
				<div style="clear: both;"></div>
			</div>


			<div class="rule_box">
				<div class="rule_icon wrong">
					<i class="fas fa-times"></i>
				</div>
				<div class="rule_text">
					Posting of personal detail is at owners risk.
				</div>
				<div style="clear: both;"></div>
			</div>

			<!--posting rules end-->

			<!--posting others-->
			<div class="posting_others">
				We reserve the right to ban you from commenting on Myenvynet or delete your comment if any of the rules is broken. Please do not take that to heart.
			</div>
			<!--posting others end-->


			</div>
			<!--comment box ends-->

		</div>
		<!-- body container ends-->


</body>
-