<?php
	//i just copied this varibles from admin_profile page for suggestion
 $poster_name = $fet_det['name'];
	$poster_img = $fet_det['image'];
	$poster_bio = $fet_det['bio'];
	$poster_signed_up_date = $fet_det['signed_up_date'];
	$poster_website = $fet_det['website'];
	$poster_facebook = $fet_det['facebook'];
	$poster_twitter = $fet_det['twitter'];
	$poster_lastseen = $fet_det['last_seen'];
	$poster_section_covered = $fet_det['section_covered'];
	$mypro_action = $_GET['pro_action'];

	$poster_email = $_GET['poster_email'];
?>

<!-- box beginss-->
<div class="about_box">
	<div class="short_bio">Short bio:</div>
	<div class="short_bio_text">
		<?php echo $poster_bio; ?>
	</div>


	<div class="pro_box">
		<div class="pro_top">
			<div class="pro_top_left">Full name:</div>
			<div class="pro_top_right"><?php echo $poster_name; ?>
				
			</div>
		</div>
		<div class="pro_top_bottom"><?php echo $poster_name; ?>
				
			</div>
	</div>

	<div class="pro_box">
		<div class="pro_top">
			<div class="pro_top_left">Date signed up:</div>
			<div class="pro_top_right"><?php echo $poster_signed_up_date; ?>
				
			</div>
		</div>
		<div class="pro_top_bottom"><?php echo $poster_signed_up_date; ?>
				
			</div>
	</div>

	<div class="pro_box">
		<div class="pro_top">
			<div class="pro_top_left">Website:</div>
			<div class="pro_top_right"><?php echo $poster_website; ?>
				
			</div>
		</div>
		<div class="pro_top_bottom"><?php echo $poster_website; ?>
				
			</div>
	</div>

	<div class="pro_contact_box">
		<div class="pro_contact_title">
			Contact details:
		</div>
		<div class="pro_contact_text_box">
			<div class="pro_contact_icon">
				<i class="fab fa-facebook-f"></i>
			</div>
			<div class="pro_contact_text">
				<?php echo $poster_email; ?>
			</div>
		</div>

		<div class="pro_contact_text_box">
			<div class="pro_contact_icon">
				<i class="fab fa-facebook-f"></i>
			</div>
			<div class="pro_contact_text">
				<?php echo $poster_facebook; ?>
			</div>
		</div>

		<div class="pro_contact_text_box">
			<div class="pro_contact_icon">
				<i class="fab fa-twitter"></i>
			</div>
			<div class="pro_contact_text">
				<?php echo $poster_twitter; ?>
			</div>
		</div>
	</div>

	<?php 
		if($myaction == 'admin_profile'){
	?>
	<div class="pro_box">
		<div class="pro_top">
			<div class="pro_top_left">Sections covered:</div>
			<div class="pro_top_right"><?php echo $poster_section_covered; ?>
				
			</div>
		</div>
		<div class="pro_top_bottom"><?php echo $poster_section_covered; ?>
				
			</div>
	</div>


	<?php
}

?>
	<div class="pro_box">
		<div class="pro_top">
			<div class="pro_top_left">Last seen:</div>
			<div class="pro_top_right"><?php echo $poster_lastseen; ?>
				
			</div>
		</div>
		<div class="pro_top_bottom"><?php echo $poster_lastseen; ?>
				
			</div>
	</div>

</div>
<!--box ends-->