<?php  
	include('./db/config.php');
	$brand = $_GET['brand'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
	<!-- body container starts-->
		<div class="body_container">

			<div class="list_head">
				<h3>Featured <?php if($brand != 'red_hydrogen'){echo strtoupper(substr($brand, 0 ,1)).substr($brand, 1);}else if($brand == 'red_hydrogen'){
					echo 'Red hydrogen';
				} ?> smartphones.   </h3>
			</div>
			
				<!--smart phones starts-->
			<div class="smart_phones_container">
				

				<!--smart_box-->
				<div class="smart_box">
					<?php
	
	$select_phone = $conn -> query("SELECT * FROM news WHERE section = 'phones' && brand = '$brand'  order by id DESC LIMIT 30");

	$count = mysqli_num_rows($select_phone);
	if($count > 0){
	
	while($fetch_phone = $select_phone -> fetch_assoc()){
		$phone_img = $fetch_phone['image'];
		$phone_title = $fetch_phone['title'];
		$phone_id = $fetch_phone['id'];
		$phone_manufacture_year = $fetch_phone['manufacture_year'];
		
		$strlen = strlen($phone_title);

		?>

					<!--smart display-->
				<div class="smart_display">

					<?php
						if($phone_manufacture_year != ''){
					?>
					<div class="manufacture_year"><?php echo $phone_manufacture_year; ?></div>
				<?php } ?>

					<a href="?action=smartphone_spec&sc=<?php echo $phone_id; ?>">	<img src="<?php echo $phone_img ; ?>" width="100%" height="100%" /></a>
						<!-- phone_name-->
						<a href="?action=smartphone_spec&sc=<?php echo $phone_id; ?>"><div class="phone_name_container">
						<div class="phone_name"><?php echo substr($phone_title, 0 , 20); ?></div>
					</div></a>
						<!--phone name ends-->
					</div>
					<!--smart display ends-->
					<?php } ?>
					<div style="clear: both;"></div>
				</div>
				<!--smart box ends-->
				<div class="line"></div>
				
				
			</div>
			<!--smart phone ends-->
			<?php
				}else{
					echo "<div class='oops' ><h2>oops! no record found</h2></div>";
				}
			?>

		</div>
		<!-- body container ends-->


</body>
</html>
