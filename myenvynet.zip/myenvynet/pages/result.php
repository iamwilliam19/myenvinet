<?php
	$gadget_one = $_GET['gadget_one'];
	$gadget_two = $_GET['gadget_two'];
	$cat = $_GET['category'];

	//fetch details for gadget one
	$find_one = $conn -> query("SELECT * FROM news WHERE section = '$cat' && title = '$gadget_one'");
	//fetch details
	$fetch_gadget = $find_one -> fetch_assoc();
	$gadget_img_one = $fetch_gadget['image'];
		$gadget_title_one = $fetch_gadget['title'];
		$gadget_id_one = $fetch_gadget['id'];
		$gadget_brand_one = $fetch_gadget['brand'];
		$gadget_release_date_one = $fetch_gadget['release_date'];
		$gadget_version_one = $fetch_gadget['version'];
		$gadget_name2_one = $fetch_gadget['name_2'];
		$gadget_manufacturer_one = $fetch_gadget['manufacturer'];
		$gadget_screen_size_one = $fetch_gadget['screen_size'];
		$gadget_ops_one = $fetch_gadget['ops'];
		$gadget_processor_one = $fetch_gadget['pro'];
		$gadget_ram_one = $fetch_gadget['ram'];
		$gadget_int_mem_one = $fetch_gadget['int_mem'];
		$gadget_cam_one = $fetch_gadget['camera'];
		$gadget_battery_one = $fetch_gadget['battery'];
		$gadget_other_high_one = $fetch_gadget['other_high'];
		$gadget_design_one = $fetch_gadget['design'];
		$gadget_dimension_one = $fetch_gadget['dimension'];
		$gadget_weight_one = $fetch_gadget['weight'];
		$gadget_aspect_ratio_one = $fetch_gadget['aspect_rat'];
		$gadget_disp_type_one = $fetch_gadget['disp_type'];
		$gadget_resolution_one = $fetch_gadget['resolution'];
		$gadget_pixel_den_one = $fetch_gadget['pixel_den'];
		$gadget_cont_ratio_one = $fetch_gadget['cont_ratio'];
		$gadget_phy_key_one = $fetch_gadget['phy_key'];
		$gadget_edge_disp_one = $fetch_gadget['edge_disp'];
		$gadget_triluminos_one = $fetch_gadget['triluminos'];
		$gadget_color_sat_one = $fetch_gadget['color_sat'];
		$gadget_brightness_one = $fetch_gadget['brightness'];
		$gadget_hd_comp_one = $fetch_gadget['hd_comp'];
		$gadget_three_d_touch_one = $fetch_gadget['three_d_touch'];
		$gadget_true_tone_one = $fetch_gadget['true_tone'];
		$gadget_wide_color_one = $fetch_gadget['wide_color'];
		$gadget_always_on_one = $fetch_gadget['always_on'];
		$gadget_pixel_resp_one = $fetch_gadget['pixel_resp'];
		$gadget_screen_prot_one = $fetch_gadget['screen_prot'];
		$gadget_curved_screen_one = $fetch_gadget['curved_screen'];
		$gadget_scratch_res_one = $fetch_gadget['scratch_res'];
		$gadget_anti_finger_one = $fetch_gadget['anti_finger'];
		$gadget_blue_light_one = $fetch_gadget['blue_light'];
		$gadget_sun_light_one = $fetch_gadget['sun_light'];
		$gadget_multi_touch_one = $fetch_gadget['multi_touch'];
		$gadget_other_feat_one = $fetch_gadget['other_feat'];
		$gadget_ui_one = $fetch_gadget['ui'];
		$gadget_pre_installed_one = $fetch_gadget['pre_installed'];
		$gadget_graphic_pro_one = $fetch_gadget['graphic_pro'];
		$gadget_gpu_one = $fetch_gadget['gpu'];
		$gadget_soc_one = $fetch_gadget['soc'];
		$gadget_isa_one = $fetch_gadget['isa'];
		$gadget_pro_tech_one = $fetch_gadget['pro_tech'];
		$gadget_cpu_one = $fetch_gadget['cpu'];
		$gadget_co_pro_one = $fetch_gadget['co_pro'];
		$gadget_ram_type_one = $fetch_gadget['ram_type'];
		$gadget_ram_channel_one = $fetch_gadget['ram_channel'];
		$gadget_freq_one = $fetch_gadget['freq'];
		$gadget_mem_type_one = $fetch_gadget['mem_type'];
		$gadget_mem_card_one = $fetch_gadget['mem_card'];
		$gadget_front_cam_one = $fetch_gadget['front_cam'];
		$gadget_sensor_mod_one = $fetch_gadget['sensor_mod'];
		$gadget_vid_rec_one = $fetch_gadget['vid_rec'];
		$gadget_rear_cam_one = $fetch_gadget['rear_cam'];
		$gadget_sensor_type_one = $fetch_gadget['sensor_type'];
		$gadget_cam_feat_one = $fetch_gadget['cam_feat'];
		$gadget_vid_format_one = $fetch_gadget['vid_format'];
		$gadget_vid_format_one = $fetch_gadget['aud_format'];
		$gadget_img_format_one = $fetch_gadget['img_format'];
		$gadget_aud_format_one = $fetch_gadget['aud_format'];
		$gadget_speaker_one = $fetch_gadget['speaker'];
		$gadget_microgadget_one = $fetch_gadget['microgadget'];
		$gadget_sim_count_one = $fetch_gadget['sim_count'];
		$gadget_sim_type_one = $fetch_gadget['sim_type'];
		$gadget_twogcall_one = $fetch_gadget['twog_call'];
		$gadget_twog_data_one = $fetch_gadget['twog_data'];
		$gadget_threeg_call_one = $fetch_gadget['threeg_Call'];
		$gadget_threeg_data_one = $fetch_gadget['threeg_data'];
		$gadget_fourg_call_one = $fetch_gadget['fourg_call'];
		$gadget_fourg_data_one = $fetch_gadget['fourg_data'];
		$gadget_please_note_one = $fetch_gadget['please_note'];
		$gadget_sim_use_one = $fetch_gadget['sim_use'];
		$gadget_wifi_one = $fetch_gadget['wifi'];
		$gadget_wifi_feature_one = $fetch_gadget['wifi_feature'];
		$gadget_cell_net_one = $fetch_gadget['cell_net'];
		$gadget_data_con_one = $fetch_gadget['data_con'];
		$gadget_bluetooth_one = $fetch_gadget['bluetooth'];
		$gadget_nav_sys_one = $fetch_gadget['nav_sys'];
		$gadget_other_con_one = $fetch_gadget['other_con'];
		$gadget_usb_port_one = $fetch_gadget['usb_port'];
		$gadget_Ddi_one = $fetch_gadget['Ddi'];
		$gadget_finger_print_one = $fetch_gadget['finger_print'];
		$gadget_audio_jack_one = $fetch_gadget['audio_jack'];
		$gadget_face_rec_one = $fetch_gadget['face_rec'];
		$gadget_other_sensors_one = $fetch_gadget['other_sensors'];
		$gadget_bat_type_one = $fetch_gadget['bat_type'];
		$gadget_bat_mod_one = $fetch_gadget['bat_mod'];
		$gadget_charge_output_one = $fetch_gadget['charge_output'];
		$gadget_bat_sup_one = $fetch_gadget['bat_sup'];
		$gadget_browser_sup_one = $fetch_gadget['browser_sup'];
		$gadget_wearable_one = $fetch_gadget['wearable'];
		$gadget_fm_one = $fetch_gadget['fm'];
		$gadget_not_light_one = $fetch_gadget['not_light'];
		$gadget_voice_ass_one = $fetch_gadget['voice_ass'];
		$gadget_air_ges_one = $fetch_gadget['air_ges'];
		$gadget_extra_pro_one = $fetch_gadget['extra_pro'];
		$gadget_others_one = $fetch_gadget['others'];
		$gadget_cloud_sto_one = $fetch_gadget['cloud_sto'];
		$gadget_service_temp_one = $fetch_gadget['service_temp'];
		$gadget_sar_one = $fetch_gadget['sar'];
		$gadget_sty_pen_one = $fetch_gadget['sty_pen'];
		$gadget_mobile_pay_one = $fetch_gadget['mobile_pay'];
		$gadget_support_one = $fetch_gadget['support'];
		$gadget_war_type_one = $fetch_gadget['war_type'];
		$gadget_colors_one = $fetch_gadget['color'];
		$gadget_price_one = $fetch_gadget['price'];
		$gadget_audio_output_one = $fetch_gadget['audio_output'];
		$gadget_screen_to_body_one = $fetch_gadget['screen_to_body'];
		$gadget_cache_one = $fetch_gadget['cache'];
		$gadget_series_one = $fetch_gadget['series'];
		$gadget_type_one = $fetch_gadget['tv_type'];
		$gadget_channel_tuner_one = $fetch_gadget['tv_channel_tuner'];
		$gadget_link_one = $fetch_gadget['link'];
		$gadget_operating_power_one = $fetch_gadget['operating_power'];
		$gadget_cam_resolution_one = $fetch_gadget['cam_resolution'];
		$gadget_video_port_one = $fetch_gadget['video_port'];
		$gadget_head_gadget_jack_one = $fetch_gadget['head_gadget_jack'];
		$gadget_screen_refresh_one = $fetch_gadget['screen_refresh'];
		$gadget_dimming_tech_one = $fetch_gadget['dimming_tech'];
		$gadget_backlight_one = $fetch_gadget['backlight'];
		$gadget_viewing_angle_one = $fetch_gadget['viewing_angle'];
		$gadget_motion_inter_one = $fetch_gadget['motion_inter'];
		$gadget_smart_tv_one = $fetch_gadget['smart_tv'];
		$gadget_smart_tv_feat_one = $fetch_gadget['smart_tv_feat'];
		$gadget_flat_screen_one = $fetch_gadget['flat_screen'];
		$gadget_three_d_tv_one = $fetch_gadget['three_d_tv'];
		$gadget_three_d_tv_glasses_one = $fetch_gadget['three_d_tv_glasses'];
		$gadget_mi_value_one = $fetch_gadget['mi_value'];
		$gadget_frame_Rate_one = $fetch_gadget['frame_rate'];
		$gadget_video_signal_one = $fetch_gadget['video_signal'];
		$gadget_vp_mode_one = $fetch_gadget['vp_mode'];
		$gadget_speaker_output_one = $fetch_gadget['speaker_output'];
		
		$gadget_cable_port_one = $fetch_gadget['cable_port'];
		$gadget_ethernet_port_one = $fetch_gadget['ethernet_port'];
		$gadget_Dap_one= $fetch_gadget['Dap'];
		$gadget_add_port_one = $fetch_gadget['add_port'];
		$gadget_LAN_one = $fetch_gadget['LAN'];
		$gadget_stand_by_one = $fetch_gadget['stand_by'];
		$gadget_power_saving_one = $fetch_gadget['power_saving'];
		$gadget_req_voltage_one = $fetch_gadget['req_voltage'];
		$gadget_req_freq_one = $fetch_gadget['req_freq'];
		$gadget_power_add_feat_one = $fetch_gadget['power_add_feat'];
		$gadget_wall_mount_one = $fetch_gadget['wall_mount'];
		$gadget_tv_stand_one = $fetch_gadget['tv_stand'];
		$gadget_config_others_one = $fetch_gadget['config_others'];
		$gadget_in_box_one = $fetch_gadget['in_box'];
		$gadget_other_comp_acc_one = $fetch_gadget['other_comp_acc'];
		$gadget_lang_sup_one = $fetch_gadget['lang_sup'];
		$gadget_liscence_one = $fetch_gadget['liscence'];
		$gadget_other_spec_one = $fetch_gadget['other_spec'];
		$gadget_other_image_feat_one = $fetch_gadget['other_image_feat'];
		$gadget_curved_screen_one = $fetch_gadget['curved_screen'];

	//fetch details for gadget one ends

	//fetch details of gadget two
		$find_two = $conn -> query("SELECT * FROM news WHERE section = '$cat' && title = '$gadget_two'");
		$fetch_gadget_two = $find_two -> fetch_assoc();
		$gadget_img_two = $fetch_gadget_two['image'];
		$gadget_title_two = $fetch_gadget_two['title'];
		$gadget_id_two = $fetch_gadget_two['id'];
		$gadget_brand_two = $fetch_gadget_two['brand'];
		$gadget_release_date_two = $fetch_gadget_two['release_date'];
		$gadget_version_two = $fetch_gadget_two['version'];
		$gadget_name2_two = $fetch_gadget_two['name_2'];
		$gadget_manufacturer_two = $fetch_gadget_two['manufacturer'];
		$gadget_screen_size_two = $fetch_gadget_two['screen_size'];
		$gadget_ops_two = $fetch_gadget_two['ops'];
		$gadget_processor_two = $fetch_gadget_two['pro'];
		$gadget_ram_two = $fetch_gadget_two['ram'];
		$gadget_int_mem_two = $fetch_gadget_two['int_mem'];
		$gadget_cam_two = $fetch_gadget_two['camera'];
		$gadget_battery_two = $fetch_gadget_two['battery'];
		$gadget_other_high_two = $fetch_gadget_two['other_high'];
		$gadget_design_two = $fetch_gadget_two['design'];
		$gadget_dimension_two = $fetch_gadget_two['dimension'];
		$gadget_weight_two = $fetch_gadget_two['weight'];
		$gadget_aspect_ratio_two = $fetch_gadget_two['aspect_rat'];
		$gadget_disp_type_two = $fetch_gadget_two['disp_type'];
		$gadget_resolution_two = $fetch_gadget_two['resolution'];
		$gadget_pixel_den_two = $fetch_gadget_two['pixel_den'];
		$gadget_cont_ratio_two = $fetch_gadget_two['cont_ratio'];
		$gadget_phy_key_two = $fetch_gadget_two['phy_key'];
		$gadget_edge_disp_two = $fetch_gadget_two['edge_disp'];
		$gadget_triluminos_two = $fetch_gadget_two['triluminos'];
		$gadget_color_sat_two = $fetch_gadget_two['color_sat'];
		$gadget_brightness_two = $fetch_gadget_two['brightness'];
		$gadget_hd_comp_two = $fetch_gadget_two['hd_comp'];
		$gadget_three_d_touch_two = $fetch_gadget_two['three_d_touch'];
		$gadget_true_tone_two = $fetch_gadget_two['true_tone'];
		$gadget_wide_color_two = $fetch_gadget_two['wide_color'];
		$gadget_always_on_two = $fetch_gadget_two['always_on'];
		$gadget_pixel_resp_two = $fetch_gadget_two['pixel_resp'];
		$gadget_screen_prot_two = $fetch_gadget_two['screen_prot'];
		$gadget_curved_screen_two = $fetch_gadget_two['curved_screen'];
		$gadget_scratch_res_two = $fetch_gadget_two['scratch_res'];
		$gadget_anti_finger_two = $fetch_gadget_two['anti_finger'];
		$gadget_blue_light_two = $fetch_gadget_two['blue_light'];
		$gadget_sun_light_two = $fetch_gadget_two['sun_light'];
		$gadget_multi_touch_two = $fetch_gadget_two['multi_touch'];
		$gadget_other_feat_two = $fetch_gadget_two['other_feat'];
		$gadget_ui_two = $fetch_gadget_two['ui'];
		$gadget_pre_installed_two = $fetch_gadget_two['pre_installed'];
		$gadget_graphic_pro_two = $fetch_gadget_two['graphic_pro'];
		$gadget_gpu_two = $fetch_gadget_two['gpu'];
		$gadget_soc_two = $fetch_gadget_two['soc'];
		$gadget_isa_two = $fetch_gadget_two['isa'];
		$gadget_pro_tech_two = $fetch_gadget_two['pro_tech'];
		$gadget_cpu_two = $fetch_gadget_two['cpu'];
		$gadget_co_pro_two = $fetch_gadget_two['co_pro'];
		$gadget_ram_type_two = $fetch_gadget_two['ram_type'];
		$gadget_ram_channel_two = $fetch_gadget_two['ram_channel'];
		$gadget_freq_two = $fetch_gadget_two['freq'];
		$gadget_mem_type_two = $fetch_gadget_two['mem_type'];
		$gadget_mem_card_two = $fetch_gadget_two['mem_card'];
		$gadget_front_cam_two = $fetch_gadget_two['front_cam'];
		$gadget_sensor_mod_two = $fetch_gadget_two['sensor_mod'];
		$gadget_vid_rec_two = $fetch_gadget_two['vid_rec'];
		$gadget_rear_cam_two = $fetch_gadget_two['rear_cam'];
		$gadget_sensor_type_two = $fetch_gadget_two['sensor_type'];
		$gadget_cam_feat_two = $fetch_gadget_two['cam_feat'];
		$gadget_vid_format_two = $fetch_gadget_two['vid_format'];
		$gadget_vid_format_two = $fetch_gadget_two['aud_format'];
		$gadget_img_format_two = $fetch_gadget_two['img_format'];
		$gadget_aud_format_two = $fetch_gadget_two['aud_format'];
		$gadget_speaker_two = $fetch_gadget_two['speaker'];
		$gadget_microgadget_two = $fetch_gadget_two['microgadget'];
		$gadget_sim_count_two = $fetch_gadget_two['sim_count'];
		$gadget_sim_type_two = $fetch_gadget_two['sim_type'];
		$gadget_twogcall_two = $fetch_gadget_two['twog_call'];
		$gadget_twog_data_two = $fetch_gadget_two['twog_data'];
		$gadget_threeg_call_two = $fetch_gadget_two['threeg_Call'];
		$gadget_threeg_data_two = $fetch_gadget_two['threeg_data'];
		$gadget_fourg_call_two = $fetch_gadget_two['fourg_call'];
		$gadget_fourg_data_two = $fetch_gadget_two['fourg_data'];
		$gadget_please_note_two = $fetch_gadget_two['please_note'];
		$gadget_sim_use_two = $fetch_gadget_two['sim_use'];
		$gadget_wifi_two = $fetch_gadget_two['wifi'];
		$gadget_wifi_feature_two = $fetch_gadget_two['wifi_feature'];
		$gadget_cell_net_two = $fetch_gadget_two['cell_net'];
		$gadget_data_con_two = $fetch_gadget_two['data_con'];
		$gadget_bluetooth_two = $fetch_gadget_two['bluetooth'];
		$gadget_nav_sys_two = $fetch_gadget_two['nav_sys'];
		$gadget_other_con_two = $fetch_gadget_two['other_con'];
		$gadget_usb_port_two = $fetch_gadget_two['usb_port'];
		$gadget_Ddi_two = $fetch_gadget_two['Ddi'];
		$gadget_finger_print_two = $fetch_gadget_two['finger_print'];
		$gadget_audio_jack_two = $fetch_gadget_two['audio_jack'];
		$gadget_face_rec_two = $fetch_gadget_two['face_rec'];
		$gadget_other_sensors_two = $fetch_gadget_two['other_sensors'];
		$gadget_bat_type_two = $fetch_gadget_two['bat_type'];
		$gadget_bat_mod_two = $fetch_gadget_two['bat_mod'];
		$gadget_charge_output_two = $fetch_gadget_two['charge_output'];
		$gadget_bat_sup_two = $fetch_gadget_two['bat_sup'];
		$gadget_browser_sup_two = $fetch_gadget_two['browser_sup'];
		$gadget_wearable_two = $fetch_gadget_two['wearable'];
		$gadget_fm_two = $fetch_gadget_two['fm'];
		$gadget_not_light_two = $fetch_gadget_two['not_light'];
		$gadget_voice_ass_two = $fetch_gadget_two['voice_ass'];
		$gadget_air_ges_two = $fetch_gadget_two['air_ges'];
		$gadget_extra_pro_two = $fetch_gadget_two['extra_pro'];
		$gadget_others_two = $fetch_gadget_two['others'];
		$gadget_cloud_sto_two = $fetch_gadget_two['cloud_sto'];
		$gadget_service_temp_two = $fetch_gadget_two['service_temp'];
		$gadget_sar_two = $fetch_gadget_two['sar'];
		$gadget_sty_pen_two = $fetch_gadget_two['sty_pen'];
		$gadget_mobile_pay_two = $fetch_gadget_two['mobile_pay'];
		$gadget_support_two = $fetch_gadget_two['support'];
		$gadget_war_type_two = $fetch_gadget_two['war_type'];
		$gadget_colors_two = $fetch_gadget_two['color'];
		$gadget_price_two = $fetch_gadget_two['price'];
		$gadget_audio_output_two = $fetch_gadget_two['audio_output'];
		$gadget_screen_to_body_two = $fetch_gadget_two['screen_to_body'];
		$gadget_cache_two = $fetch_gadget_two['cache'];
		$gadget_series_two = $fetch_gadget_two['series'];
		$gadget_type_two = $fetch_gadget_two['tv_type'];
		$gadget_channel_tuner_two = $fetch_gadget_two['tv_channel_tuner'];
		$gadget_link_two = $fetch_gadget_two['link'];
		$gadget_operating_power_two = $fetch_gadget_two['operating_power'];
		$gadget_cam_resolution_two = $fetch_gadget_two['cam_resolution'];
		$gadget_video_port_two = $fetch_gadget_two['video_port'];
		$gadget_head_gadget_jack_two = $fetch_gadget_two['head_gadget_jack'];
		$gadget_screen_refresh_two = $fetch_gadget_two['screen_refresh'];
		$gadget_dimming_tech_two = $fetch_gadget_two['dimming_tech'];
		$gadget_backlight_two = $fetch_gadget_two['backlight'];
		$gadget_viewing_angle_two = $fetch_gadget_two['viewing_angle'];
		$gadget_motion_inter_two = $fetch_gadget_two['motion_inter'];
		$gadget_smart_tv_two = $fetch_gadget_two['smart_tv'];
		$gadget_smart_tv_feat_two = $fetch_gadget_two['smart_tv_feat'];
		$gadget_flat_screen_two = $fetch_gadget_two['flat_screen'];
		$gadget_three_d_tv_two = $fetch_gadget_two['three_d_tv'];
		$gadget_three_d_tv_glasses_two = $fetch_gadget_two['three_d_tv_glasses'];
		$gadget_mi_value_two = $fetch_gadget_two['mi_value'];
		$gadget_frame_Rate_two = $fetch_gadget_two['frame_rate'];
		$gadget_video_signal_two = $fetch_gadget_two['video_signal'];
		$gadget_vp_mode_two = $fetch_gadget_two['vp_mode'];
		$gadget_speaker_output_two = $fetch_gadget_two['speaker_output'];
		
		$gadget_cable_port_two = $fetch_gadget_two['cable_port'];
		$gadget_ethernet_port_two = $fetch_gadget_two['ethernet_port'];
		$gadget_Dap_two = $fetch_gadget_two['Dap'];
		$gadget_add_port_two = $fetch_gadget_two['add_port'];
		$gadget_LAN_two = $fetch_gadget_two['LAN'];
		$gadget_stand_by_two = $fetch_gadget_two['stand_by'];
		$gadget_power_saving_two = $fetch_gadget_two['power_saving'];
		$gadget_req_voltage_two = $fetch_gadget_two['req_voltage'];
		$gadget_req_freq_two = $fetch_gadget_two['req_freq'];
		$gadget_power_add_feat_two = $fetch_gadget_two['power_add_feat'];
		$gadget_wall_mount_two = $fetch_gadget_two['wall_mount'];
		$gadget_tv_stand_two = $fetch_gadget_two['tv_stand'];
		$gadget_config_others_two = $fetch_gadget_two['config_others'];
		$gadget_in_box_two = $fetch_gadget_two['in_box'];
		$gadget_other_comp_acc_two = $fetch_gadget_two['other_comp_acc'];
		$gadget_lang_sup_two = $fetch_gadget_two['lang_sup'];
		$gadget_liscence_two = $fetch_gadget_two['liscence'];
		$gadget_other_spec_two = $fetch_gadget_two['other_spec'];
		$gadget_other_image_feat_two = $fetch_gadget_two['other_image_feat'];
		$gadget_curved_screen_two = $fetch_gadget_two['curved_screen'];
		$gadget_cable_port_two = $fetch_gadget_two['cable_port'];
		$gadget_ethernet_port_two = $fetch_gadget_two['ethernet_port'];
		$gadget_Dap_two = $fetch_gadget_two['Dap'];
		$gadget_add_port_two = $fetch_gadget_two['add_port'];
		$gadget_LAN_two = $fetch_gadget_two['LAN'];
		$gadget_stand_by_two = $fetch_gadget_two['stand_by'];
		$gadget_power_saving_two = $fetch_gadget_two['power_saving'];
	//fetch details of gadget two ends
?>
<body>
	<!-- body container starts-->
	<div class="body_container">
		<div class="result_head">Result:</div>
			<!--result box begins-->
			<div class="result_box">
				<!--head title box-->
				<div class="head_title_box">
					<div class="head_one"><?php echo strtoupper(substr($gadget_one,0, 1)).substr($gadget_one,1) ;?></div>
					<div class="versus">VS</div>
					<div class="head_two"><?php echo strtoupper(substr($gadget_two,0, 1)).substr($gadget_two,1) ;?></div>
					<div style="clear: both;"></div>
				</div>
				<!--head title box ends-->

				<!--result img box starts-->
				<div class="result_img_box">
					<div class="img_one_cont">
						<div class="img_one">
							<img src="<?php echo $gadget_img_one; ?>" width="100%" height="100%" />
						</div>

						<!--img one others start-->
						<div class="img_one_others">
							<!--result fan box-->
							<div class="result_fan_box">
								<div class="result_fan">10 fans</div>
								<div class="result_hit">10 hits</div>
								<div style="clear: both;"></div>
							</div>
							<!--result fan box ends-->

						</div>
						<!--img one others end-->
					</div>


					<div class="img_two_cont">
						<div class="img_two">
							<img src="<?php echo $gadget_img_two; ?>" width="100%" height="100%" />
						</div>

						<!--img two others start-->
						<div class="img_two_others"><!--result fan box-->
							<div class="result_fan_box">
								<div class="result_fan">10 fans</div>
								<div class="result_hit">10 hits</div>
								<div style="clear: both;"></div>
							</div>
							<!--result fan box ends--></div>
						<!--img two others end-->
					</div>
					<div style="clear: both;"></div>
				</div>
				<!--result img box ends-->

				<!--result specs starts-->
				<?php
					if($gadget_release_date_one != '' && $gadget_release_date_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Relase date</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_release_date_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_release_date_two; ?>

							</td>
						</tr>
					</table>
				</div>

				<?php
					}
					?>

				<!--result specs end-->


				<!--result specs starts-->
				<?php
					if($gadget_version_one != '' && $gadget_version_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Versions</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_version_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_version_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_series_one != '' && $gadget_series_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Series
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_series_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_series_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

			<!--result specs starts-->
			<?php
					if($gadget_name2_one != '' && $gadget_name2_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Also known as</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_name2_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_name2_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_manufacturer_one!= '' && $gadget_manufacturer_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Manufacturer</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_manufacturer_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_manufacturer_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_type_one != '' && $gadget_type_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Tv type
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_type_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_type_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_channel_tuner_one != '' && $gadget_channel_tuner_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Tv channel tuner
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_channel_tuner_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_channel_tuner_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_wall_mount_one != '' && $gadget_wall_mount_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Wall mount
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_wall_mount_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_wall_mount_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_tv_stand_one != '' && $gadget_tv_stand_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Tv stand
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_tv_stand_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_tv_stand_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_other_comp_acc_one != '' && $gadget_other_comp_acc_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Other compatible accessories
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_other_comp_acc_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_other_comp_acc_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_lang_sup_one != '' && $gadget_lang_sup_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Language support
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_lang_sup_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_lang_sup_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_operating_power_one != '' && $gadget_operating_power_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Operating power
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_operating_power_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_operating_power_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_power_saving_one != '' && $gadget_power_saving_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Power saving
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_power_saving_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_power_saving_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_req_freq_one != '' && $gadget_req_freq_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Required frequency
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_req_freq_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_req_freq_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_req_voltage_one != '' && $gadget_req_voltage_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Required voltage
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_req_voltage_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_req_voltage_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_screen_size_one != '' && $gadget_screen_size_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Screen size</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_screen_size_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_screen_size_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_screen_refresh_one != '' && $gadget_screen_refresh_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Screen refresh
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_screen_refresh_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_screen_refresh_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_dimming_tech_one != '' && $gadget_dimming_tech_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Dimming technology
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_dimming_tech_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_dimming_tech_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_backlight_one != '' && $gadget_backlight_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Backlight type
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_backlight_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_backlight_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_viewing_angle_one != '' && $gadget_viewing_angle_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Viewing angle
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_viewing_angle_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_viewing_angle_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_motion_inter_one != '' && $gadget_motion_inter_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Motion interpolation technology
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_motion_inter_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_motion_inter_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_smart_tv_one != '' && $gadget_smart_tv_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Smart Tv
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_smart_tv_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_smart_tv_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_smart_tv_feat_one != '' && $gadget_smart_tv_feat_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Smart Tv features
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_smart_tv_feat_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_smart_tv_feat_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_flat_screen_one != '' && $gadget_flat_screen_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Flat screen
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_flat_screen_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_flat_screen_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_three_d_tv_one != '' && $gadget_three_d_tv_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">3D Tv
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_three_d_tv_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_three_d_tv_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_stand_by_one != '' && $gadget_stand_by_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Stand by
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_stand_by_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_stand_by_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_three_d_tv_glasses_one != '' && $gadget_three_d_tv_glasses_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">3D Tv glasses
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_three_d_tv_glasses_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_three_d_tv_glasses_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_mi_value_one != '' && $gadget_mi_value_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">MI Value
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_mi_value_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_mi_value_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_frame_Rate_one != '' && $gadget_frame_Rate_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Frame rate
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_frame_Rate_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_frame_Rate_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_video_signal_one != '' && $gadget_video_signal_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Video signal
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_video_signal_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_video_signal_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_vp_mode_one != '' && $gadget_vp_mode_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Video &amp; picture modes
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_vp_mode_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_vp_mode_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_ops_one != '' && $gadget_ops_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Operating system
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_ops_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_ops_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_processor_one != '' && $gadget_processor_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Processor
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_processor_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_processor_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_ram_one != '' && $gadget_ram_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">RAM
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_ram_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_ram_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_int_mem_one != '' && $gadget_int_mem_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Internal memory
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_int_mem_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_int_mem_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_cam_one != '' && $gadget_cam_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Camera
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_cam_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_cam_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_cam_resolution_one != '' && $gadget_cam_resolution_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Camera resolution
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_cam_resolution_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_cam_resolution_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_battery_one != '' && $gadget_battery_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Battery
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_battery_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_battery_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_other_high_one != '' && $gadget_other_high_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Other highlights
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_other_high_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_other_high_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_design_one != '' && $gadget_design_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Design
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_design_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_design_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?> 
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_dimension_one != '' && $gadget_dimension_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Dimensions
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_dimension_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_dimension_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_weight_one != '' && $gadget_weight_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Weight
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_weight_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_wearable_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_screen_to_body_one != '' && $gadget_screen_to_body_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Screen-to-body-ratio
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_screen_to_body_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_screen_to_body_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_aspect_ratio_one != '' && $gadget_aspect_ratio_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Aspect ratio
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_aspect_ratio_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_aspect_ratio_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_disp_type_one != '' && $gadget_disp_type_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Display type
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_disp_type_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_disp_type_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_resolution_one != '' && $gadget_resolution_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Resolution
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_resolution_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_resolution_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_pixel_den_one != '' && $gadget_pixel_den_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Pixel density
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_pixel_den_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_pixel_den_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_cont_ratio_one != '' && $gadget_cont_ratio_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Contrast ratio
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_cont_ratio_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_cont_ratio_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->


				<!--result specs starts-->
				<?php
					if($gadget_phy_key_one != '' && $gadget_phy_key_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Physical keyboard
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_phy_key_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_phy_key_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_edge_disp_one != '' && $gadget_edge_disp_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Edge display
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_edge_disp_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_edge_disp_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_triluminos_one != '' && $gadget_triluminos_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Triluminos display
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_triluminos_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_triluminos_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_color_sat_one != '' && $gadget_color_sat_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Color saturation (NTSC)
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_color_sat_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_color_sat_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_brightness_one != '' && $gadget_brightness_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Brightness level
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_brightness_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_brightness_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_hd_comp_one != '' && $gadget_hd_comp_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">HDR10 compliant
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_hd_comp_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_hd_comp_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_three_d_touch_one != '' && $gadget_three_d_touch_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">3D Touch
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_three_d_touch_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_three_d_touch_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_true_tone_one != '' && $gadget_true_tone_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">True tone display
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_true_tone_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_true_tone_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_wide_color_one != '' && $gadget_wide_color_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Wide color gamut display
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_wide_color_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_wide_color_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_always_on_one != '' && $gadget_always_on_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Always on display
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_always_on_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_always_on_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_pixel_resp_one != '' && $gadget_pixel_resp_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Pixel response time
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_pixel_resp_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_pixel_resp_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_screen_prot_one != '' && $gadget_screen_prot_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Screen protection
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_screen_prot_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_screen_prot_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_curved_screen_one != '' && $gadget_curved_screen_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Curved screen
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_curved_screen_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_curved_screen_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_scratch_res_one != '' && $gadget_scratch_res_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Scratch resistant
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_scratch_res_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_scratch_res_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_anti_finger_one != '' && $gadget_anti_finger_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Anti-finger coating
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_anti_finger_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_anti_finger_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_blue_light_one != '' && $gadget_blue_light_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Blue light filter (for eye protection)
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_blue_light_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_blue_light_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_sun_light_one != '' && $gadget_sun_light_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Sun light mode and reading mode
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_sun_light_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_sun_light_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_multi_touch_one != '' && $gadget_multi_touch_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Multi-touch gesture
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_multi_touch_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_multi_touch_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_other_feat_one != '' && $gadget_other_feat_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Other features
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_other_feat_one ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_other_feat_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_ui_one != '' && $gadget_ui_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">User interface
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_ui_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_ui_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_pre_installed_one != '' && $gadget_pre_installed_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Pre-installed app
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_pre_installed_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_pre_installed_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_graphic_pro_one != '' && $gadget_graphic_pro_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Graphics processor
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_graphic_pro_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_graphic_pro_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_gpu_one != '' && $gadget_gpu_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">GPU frequency
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_gpu_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_gpu_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_soc_one != '' && $gadget_soc_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">System-on-chip {SoC}
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_soc_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_soc_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_isa_one != '' && $gadget_isa_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Instruction Set Architecture {ISA}
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_isa_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_isa_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_pro_tech_one != '' && $gadget_pro_tech_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Process technology
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_pro_tech_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_pro_tech_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_cache_one != '' && $gadget_cache_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Cache memory
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_cache_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_cam_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_cpu_one != '' && $gadget_cpu_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">CPU
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_cpu_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_cpu_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_co_pro_one != '' && $gadget_co_pro_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Co-processor
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_co_pro_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_co_pro_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_ram_type_one != '' && $gadget_ram_type_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">RAM Type
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_ram_type_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_ram_type_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_ram_channel_one != '' && $gadget_ram_channel_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">RAM Channel
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_ram_channel_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_ram_channel_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_freq_one != '' && $gadget_freq_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Frequency
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_freq_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_freq_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_mem_type_one != '' && $gadget_mem_type_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Memory Type
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_mem_type_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_mem_type_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_mem_card_one != '' && $gadget_mem_card_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Memory card support
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_mem_card_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_mem_card_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_front_cam_one != '' && $gadget_front_cam_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Front camera
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_front_cam_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_front_cam_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_sensor_type_one != '' && $gadget_sensor_type_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Sensor type
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_sensor_type_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_sensor_type_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_sensor_mod_one != '' && $gadget_sensor_mod_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Sensor model
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_sensor_mod_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_sensor_mod_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_cam_feat_one != '' && $gadget_cam_feat_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Camera features
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_cam_feat_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_cam_feat_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_vid_rec_one != '' && $gadget_vid_rec_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Video recording
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_vid_rec_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_vid_rec_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_rear_cam_one != '' && $gadget_rear_cam_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Rear camera
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_rear_cam_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_rear_cam_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_vid_format_one != '' && $gadget_vid_format_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Video format and codecs
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_vid_format_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_vid_rec_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_aud_format_one != '' && $gadget_aud_format_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Audio format and codecs
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_aud_format_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_aud_format_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_img_format_one != '' && $gadget_img_format_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Image format and codecs
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_img_format_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_img_format_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_audio_output_one != '' && $gadget_audio_output_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Audio output
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_audio_output_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_audio_output_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_speaker_output_one != '' && $gadget_speaker_output_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Speaker output
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_speaker_output_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_speaker_output_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_type_one != '' && $gadget_type_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Tv type
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_type_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_type_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_speaker_one != '' && $gadget_speaker_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Speaker
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_speaker_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_speaker_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->


				<!--result specs starts-->
				<?php
					if($gadget_microgadget_one != '' && $gadget_microgadget_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Microgadget
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_microgadget_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_microgadget_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_sim_count_one != '' && $gadget_sim_count_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">SIM count
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_sim_count_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_sim_count_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_sim_type_one != '' && $gadget_sim_count_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">SIM type
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_sim_type_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_sim_type_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_twogcall_one != '' && $gadget_twogcall_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">2G(for calls)
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_twogcall_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_twogcall_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_threeg_call_one != '' && $gadget_threeg_call_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">3G(for calls)
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_threeg_call_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_threeg_call_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_fourg_call_one != '' && $gadget_fourg_call_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">4G/LTE(for calls)
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_fourg_call_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_fourg_call_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_twog_data_one != '' && $gadget_twog_data_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">2G(for data)
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_twog_data_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_twog_data_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_threeg_data_one != '' && $gadget_threeg_data_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">3G(for data)
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_threeg_data_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_threeg_data_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_fourg_data_one != '' && $gadget_fourg_data_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">4G/LTE(for data)
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_fourg_data_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_fourg_data_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_sim_use_one != '' && $gadget_sim_use_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">SIM use
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_sim_use_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_sim_use_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_wifi_one != '' && $gadget_wifi_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">WI-FI
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_wifi_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_wifi_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_wifi_feature_one != '' && $gadget_wifi_feature_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">WI-FI features
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_wifi_feature_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_wifi_feature_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_cell_net_one != '' && $gadget_cell_net_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Cellular network
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_cell_net_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_cell_net_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_data_con_one != '' && $gadget_data_con_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Data connection
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_data_con_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_data_con_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_bluetooth_one != '' && $gadget_bluetooth_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Bluetooth
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_bluetooth_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_bluetooth_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_nav_sys_one != '' && $gadget_nav_sys_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Navigation system
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_nav_sys_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_nav_sys_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_LAN_one != '' && $gadget_LAN_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Local Area Network
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_LAN_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_LAN_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_other_con_one != '' && $gadget_other_con_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Other connectivity features
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_other_con_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_other_con_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_usb_port_one != '' && $gadget_usb_port_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">USB port
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_usb_port_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_usb_port_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_video_port_two != '' && $gadget_video_port_one != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Video port
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_video_port_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_video_port_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_head_gadget_jack_one != '' && $gadget_head_gadget_jack_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Head gadget jack
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_head_gadget_jack_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_head_gadget_jack_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_audio_jack_one != '' && $gadget_audio_jack_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Audio jack
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_audio_jack_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_audio_jack_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_Ddi_one != '' && $gadget_Ddi_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Digital display interface
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_Ddi_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_Ddi_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_finger_print_one != '' && $gadget_finger_print_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Finger print sensor
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_finger_print_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_finger_print_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_face_rec_one != '' && $gadget_face_rec_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Face recognition
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_face_rec_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_face_rec_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_other_sensors_one != '' && $gadget_other_sensors_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Other sensors
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_other_sensors_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_other_sensors_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_bat_type_one != '' && $gadget_bat_type_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Battery type
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_bat_type_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_bat_type_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_bat_mod_one != '' && $gadget_bat_mod_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Battery Model
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_bat_mod_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_bat_mod_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_charge_output_one != '' && $gadget_charge_output_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Chager output
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_charge_output_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_charge_output_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_bat_sup_one != '' && $gadget_bat_sup_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Supports
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_bat_sup_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_bat_sup_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_browser_sup_one != '' && $gadget_browser_sup_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Browser support
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_browser_sup_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_browser_sup_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_wearable_one != '' && $gadget_wearable_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Wearable devices supported
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_wearable_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_wearable_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_fm_one != '' && $gadget_fm_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">FM Radio
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_fm_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_fm_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_not_light_one != '' && $gadget_not_light_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Notification light
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_not_light_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_not_light_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_voice_ass_one != '' && $gadget_voice_ass_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Voice assistant
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_voice_ass_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_voice_ass_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_air_ges_one != '' && $gadget_air_ges_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Air gestures
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_air_ges_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_air_ges_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_extra_pro_one != '' && $gadget_extra_pro_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Extra protection
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_extra_pro_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_extra_pro_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_other_feat_one != '' && $gadget_other_feat_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Other features
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_other_feat_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_other_feat_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_cloud_sto_one != '' && $gadget_cloud_sto_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Cloud storage
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_cloud_sto_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_cloud_sto_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_service_temp_one != '' && $gadget_service_temp_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">
								In service temperature
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_service_temp_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_service_temp_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_sar_one != '' && $gadget_sar_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">SAR
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_sar_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_sar_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_sty_pen_one != '' && $gadget_sty_pen_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Stylus pen
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_sty_pen_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_sty_pen_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_mobile_pay_one != '' && $gadget_mobile_pay_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Mobile payment
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_mobile_pay_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_mobile_pay_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_support_one != '' && $gadget_support_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Support
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_support_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_support_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_war_type_one != '' && $gadget_war_type_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Warranty type
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_war_type_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_war_type_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_colors_one != '' && $gadget_colors_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Colors
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_colors_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_colors_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_price_one != '' && $gadget_price_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Price
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_price_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_price_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_cable_port_one != '' && $gadget_cable_port_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Cable port
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_cable_port_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_cable_port_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_ethernet_port_one != '' && $gadget_ethernet_port_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Ethernet port
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_ethernet_port_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_ethernet_port_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->
				
				<!--result specs starts-->
				<?php
					if($gadget_Dap_one != '' && $gadget_Dap_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Digital audio port
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_Dap_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_Dap_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				<!--result specs starts-->
				<?php
					if($gadget_add_port_one != '' && $gadget_add_port_two != ''){

				?>
				<div class="result_spec">
					<table>
						<tr>
							<td colspan="2" class="result_header">Additional port
							</td>
					    </tr>
						<tr>
							<td class="result_cat">
								<?php echo $gadget_add_port_one; ?>
							</td>
							<td class="result_ans">
								<?php echo $gadget_add_port_two; ?>

							</td>
						</tr>
					</table>
				</div>
				<?php
					}
					?>
				<!--result specs end-->

				


			</div>
			<!--result box ends-->

			<div class="result_other">
				Compare other devices
			</div>

			<?php if($error == 001){?>
				<div class="dev_error">Please fill out all boxes</div>
			<?php }else if($error == 002){ ?>
				<div class="dev_error">No match for gadget one</div>
			<?php }else if($error == 003){ ?>
			<div class="dev_error">No match for gadget two</div>
		<?php }else if ($error == 004){ ?>
			<div class="dev_error">Please select two different gadgets</div>
		<?php } ?>

					<div class="brand_type_box">
					<div class="brand_type">
					<select class="type_category" name="category">
						<option value="">Category</option>
						<option value="gadgets">gadgets</option>
						<option value="gadgetvisions">gadgetvisions</option>
					</select>
				</div>
				</div>

					<form action="db/compare_pro.php" method="post" class="compare_form">
					<div class="dev_1">
						<label for="dev_one" class="dev_num">1.</label>

						<input type="text" name="dev_one" placeholder="Enter device name" class="dev_one_value" id="dev_one" value="<?php echo $_SESSION['valone']; ?>" />
					</div>
					<div class="dev_2">
						<label for="dev_two" class="dev_num">2.</label>

						<input type="text" name="dev_two" placeholder="Enter device name" class="dev_two_value" id="dev_two" value="<?php echo $_SESSION['valtwo']; ?>" />
					</div>
					<div style="clear: both;"></div>	
					<div class="compare">
					<button type="submit" class="compare">
				      Compare
					</button>
				</div>
				</form>

				<div class="popular_comp">Popular comparisons</div>
			
			<!--other comparison box starts-->
			<div class="other_comparison">
				<!--other box-->
				<?php
					//fetch comparisons
					$select_all = $conn ->  query("SELECT * FROM compared WHERE category = '$cat' order by id DESC LIMIT 1 ");
					$fetching_last_id  =  $select_all -> fetch_assoc();
					$last_id = $fetching_last_id['id'];
					$select_particular = $conn -> query("SELECT * FROM compared WHERE id < '$last_id' && category = '$cat' order by id DESC LIMIT 5"); 

					$count_match = mysqli_num_rows($select_particular);
					while($fet_comparison = $select_particular -> fetch_assoc()){

						$comp_gadget_one = $fet_comparison['gadget_one'];

						$comp_gadget_two = $fet_comparison['gadget_two'];

						$comp_gadget_one_img = $fet_comparison['gadget_one_image'];

						$comp_gadget_two_img = $fet_comparison['gadget_two_image'];
				?>
				<a href="?action=result&gadget_one=<?php echo $comp_gadget_one; ?>&gadget_two=<?php echo $comp_gadget_two; ?>"><div class="popular_box">
					<!--popularimg-->
					<div class="popular_img_box">

						<div class="pop_img_one_box">
						<div class="pop_img_one">
							<img src="<?php echo $comp_gadget_one_img; ?>" width="100%" height="100%" />
						</div>
						</div>

						<div class="pop_img_two_box">
						<div class="pop_img_two">
							<img src="<?php echo $comp_gadget_two_img; ?>" width="100%" height="100%" />
						</div>
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--popular image ends-->

					<!--popname box-->
					<div class="pop_name_box">
						<div class="pop_name_one">
							<?php echo $comp_gadget_one; ?>
						</div>
						<div class="pop_name_versus">
							VS
						</div>
						<div class="pop_name_two">
							<?php echo $comp_gadget_two; ?>
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--pop name box ends-->
				</div></a>
				<!--other box -->



				<div class="line"></div>
			<?php } ?>

			<?php

				if($count_match == 0){
					echo "<h4>No records found</h4>";
				}

			?>



			</div>
			<!--other comparison box end-->


	</div>
	<!-- body container ends-->



</body>