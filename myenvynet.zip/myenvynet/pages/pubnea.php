<?php
	include('db/config.php');
	//get report value
	$report = $_GET['report'];
	$section = $_GET['section'];
	
?>
	<!-- body container starts-->
		<div class="body_container">
			
			<!--publish conatainer starts-->
			<div>
				<div class="pls_ob">
					Please observe the following rules
					<span class="hider">(hide)</span>
					<span class="revealer">(reveal)</span>
				</div>


<!-- include libraries(jQuery, bootstrap) -->
<link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script> 
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script> 

<!-- include summernote css/js -->
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
				<!--rules box start-->
				<div class="rules_box">
					<!--rules section start-->
					<div class="rules_sec">
						<div class="rules_sec1 correct">
							<i class="fas fa-check correct"></i>
						</div>
						<div class="rules_sec2">
							You need to <a href="?action=sign_up">sign up</a>/<a href="?action=sign_in">sign in</a> to publish on Myenvynet (ignore if you've done this)
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--rules section ends-->

					<!--rules section start-->
					<div class="rules_sec">
						<div class="rules_sec1 correct">
							<i class="fas fa-check correct"></i>
						</div>
						<div class="rules_sec2">
							Please it is very necessary that you read our <a href="#">terms</a> of use before proceeding to write.
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--rules section ends-->

					<!--rules section start-->
					<div class="rules_sec">
						<div class="rules_sec1 wrong">
							<i class="fas fa-times"></i>
						</div>
						<div class="rules_sec2">
							Please do not post adverts.
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--rules section ends-->

					<!--rules section start-->
					<div class="rules_sec">
						<div class="rules_sec1 wrong">
							<i class="fas fa-times"></i>
						</div>
						<div class="rules_sec2">
							Do not embed videos that aren't related to your topic/headline. Do not embed too many videos either.
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--rules section ends-->
					<!--rules section start-->
					<div class="rules_sec">
						<div class="rules_sec1 correct">
							<i class="fas fa-check correct"></i>
						</div>
						<div class="rules_sec2">
							Make your headlines short and catchy.
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--rules section ends-->
					
					<!--rules section start-->
					<div class="rules_sec">
						<div class="rules_sec1 correct">
							<i class="fas fa-check correct"></i>
						</div>
						<div class="rules_sec2">
							You may want to link to the contents on our website if need be. We also want you to use the search bar at the footer to search your topic and know if it's been published before. Yes, we don't like duplicate content.
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--rules section ends-->
					<!--rules section start-->
					<div class="rules_sec">
						<div class="rules_sec1 correct">
							<i class="fas fa-check correct"></i>
						</div>
						<div class="rules_sec2">
							A thousand words can be represented in a single picture so we'd like you to use pictures 
							early enough in your write-up and as often as possible. Please don't use copyrighted pictures. <span style="color: #2A6BA6;">Flickr</span>, <span style="color: #2A6BA6;">Unsplash</span>, <span style="color: #2A6BA6;">Pexels</span> &amp; <span style="color: #2A6BA6;">Pixabay</span> are great places to source for nice free pictures.
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--rules section ends-->
					<!--rules section start-->
					<div class="rules_sec">
						<div class="rules_sec1 correct">
							<i class="fas fa-check correct"></i>
						</div>
						<div class="rules_sec2">
							We recommend that you compress your pictures at <a href="http://www.compressnow.com" target="_blank">here</a> if its too big, to enable your published write-up load faster & to get more people to see it.
						</div>
						<div style="clear: both;"></div>
					</div>
					<!--rules section ends-->
					
				</div>
				<!--rules box ends-->

				<?php
					//find users detail
				 $email = $_SESSION['email'];
				 $user = $conn -> query("SELECT * FROM accounts WHERE email = '$email'");
				 $count_match = mysqli_num_rows($user);
				 if($count_match > 0){
				 	$fet = $user -> fetch_assoc();
				 	$user_name = $fet['name'];
				 	$user_img = $fet['image'];
				 }
				?>

				<!--pub input starts-->
				<div class="pub_inp">
					<!--pub_postbox-->
					<?php
					if($_SESSION['email'] != ''){
					?>
					<div class="pub_post_head">
						<?php 

						if($user_img != ''){

						?>
						<div class="pub_head_img">
							<img src="<?php echo $user_img; ?>" width="100%" height="100%" />
						</div>
					<?php }else if($user_img == ''){ ?> 
						<div class="pub_head_aux">
							<?php
								echo strtoupper(substr($user_name,0,1)); 
							?>
						</div>
					<?php } ?>
						<div class="pub_head_name"><small><?php echo $user_name; ?></small></div>
						<div style="clear: both;"></div>
					</div>
					<!--pub post box ends-->
				<?php } ?>
					<?php
						if($report == 001){
					?>
					<div class="reported"><small>Please add an image to your post</small></div>
				<?php }?>

				<?php
						if($report == 002){
					?>
					<div class="success"><small>Post upload successful</small></div>
				<?php }?>

					<form class="publish_form" action="./db/pubneapro.php?section=<?php echo $section; ?>" method="post">
					<div class="pub_title">
						
							<input type="text" name="pub_title" placeholder="Add a title..." value="<?php echo $_SESSION['text_title']; ?>" class="pub_post_title"  <?php if($_SESSION['email'] == ''){ echo 'disabled';} ?>>
						
					</div>

					<div class="pub_head_dir">
						{60 alphabets max}
					</div>

					<div class="pub_body_text">
						Body Text
					</div>

					<div class="pub_head_dir">
						{Please pictures must be present and should be <span>less than 2MB</span>}
					</div>

					<textarea id="summernote" name="editordata"></textarea>

					<button type="submit" class="pub_post_but" <?php if($_SESSION['email'] == ''){
						echo 'disabled';
					} ?>>Publish</button>
				</form>
				</div>
				<!--pub input ends-->
				<!--pub reread starts-->
				<div class="pub_reread">
					<h5>Please re-read the write-up before publishing. </h5>
					<small>
						This write-up will be automatically saved in the 'Activities' section of your profile as a draft just in case you leave this page without publishing it.
					</small>
				</div>
				<!--pub re read ends-->
			</div>

			<!--publish container ends-->

			<script>
				// handle image upload in html editor
				$(document).ready(function() {
			$("#summernote").summernote({
			  placeholder: 'Write Your post here...',
			       minHeight: 300,
			         callbacks: {
			        onImageUpload : function(files, editor, welEditable) {
			 
			             for(var i = files.length - 1; i >= 0; i--) {
			                     sendFile(files[i], this);
			            }
			        }
			    }
			    });
			});
			function sendFile(file, el) {
			var form_data = new FormData();
			form_data.append('file', file);
			$.ajax({
			    data: form_data,
			    type: "POST",
			    url: 'editor-upload.php',
			    cache: false,
			    contentType: false,
			    processData: false,
			    success: function(url) {
			        $(el).summernote('editor.insertImage', url);
			    }
			});
			}
</script>

			
		</div>
		<!-- body container ends-->
