<?php
	$gad = $_GET['gad'];
?>
	
		<div class="gad_box">
			<!--gadgets link begins-->
			<div class="gadget_links">
				<a href="?action=gadgets&gad=smartphones"><div class="gad_smart  <?php if($gad == 'smartphones'){echo ' gad_selected';} ?>">Smartphones</div></a>
				<a href="?action=gadgets&gad=televisions"<div class="gad_tele <?php if($gad == 'televisions'){echo ' gad_selected';} ?>">Televisions</div></a>
				
			</div>
			<!--gadgets link ends-->

			<!--gad main starts-->
			<div class="gad_main">

			<?php
				if($gad == 'televisions'){
					include('televisions_gad.php');
				}else{

			?>

			<!--main head star-->
			<div class="main_head">
				<div class="main_left">26 brands</div>
				<div class="main_right">Listing: A-Z</div>
			</div>
			<!--main head ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">Brand names</div>
				<div class="main_right main_body_right"></div>
			</div>

			<div class="main_alpha">
				<div class="main_left_alpha">A</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=apple&action=phone_list"><div class="main_body">
				<div class="main_left">Apple</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<!--main body star-->
			<a href="?brand=asus&action=phone_list"><div class="main_body">
				<div class="main_left">Asus</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">B</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=blackberry&action=phone_list"><div class="main_body">
				<div class="main_left">Blackberry</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">C</div>
				<div class="main_right main_body_right"></div>
			</div>

<!--main body star-->
			<a href="?brand=caterpillar&action=phone_list"><div class="main_body">
				<div class="main_left">Caterpillar</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">G</div>
				<div class="main_right main_body_right"></div>
			</div>


<!--main body star-->
			<a href="?brand=google&action=phone_list"><div class="main_body">
				<div class="main_left">Google</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->


<!--main body star-->
			<a href="?brand=gionee&action=phone_list"><div class="main_body">
				<div class="main_left">Gionee</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">H</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=huawei&action=phone_list"><div class="main_body">
				<div class="main_left">Huawei</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<!--main body star-->
			<a href="?brand=htc&action=phone_list"><div class="main_body">
				<div class="main_left">HTC</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">L</div>
				<div class="main_right main_body_right"></div>
			</div>


			<!--main body star-->
			<a href="?brand=lg&action=phone_list"><div class="main_body">
				<div class="main_left">LG</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->


			<!--main body star-->
			<a href="?brand=lenovo&action=phone_list"><div class="main_body">
				<div class="main_left">Lenovo</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->


			<!--main body star-->
			<a href="?brand=leeco&action=phone_list"><div class="main_body">
				<div class="main_left">LeEco</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->


			<div class="main_alpha">
				<div class="main_left_alpha">M</div>
				<div class="main_right main_body_right"></div>
			</div>
			<!--main body star-->
			<a href="?brand=motorolar&action=phone_list"><div class="main_body">
				<div class="main_left">Motorolar</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

						<!--main body star-->
			<a href="?brand=meizu&action=phone_list"><div class="main_body">
				<div class="main_left">Meizu</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<!--main body star-->
			<a href="?brand=microsoft&action=phone_list"><div class="main_body">
				<div class="main_left">Microsoft</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">N</div>
				<div class="main_right main_body_right"></div>
			</div>			

			<a href="?brand=nokia&action=phone_list"><div class="main_body">
				<div class="main_left">Nokia</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=nubia&action=phone_list"><div class="main_body">
				<div class="main_left">Nubia</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<div class="main_alpha">
				<div class="main_left_alpha">O</div>
				<div class="main_right main_body_right"></div>
			</div>	

			<a href="?brand=oneplus&action=phone_list"><div class="main_body">
				<div class="main_left">onePlus</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=oppo&action=phone_list"><div class="main_body">
				<div class="main_left">Oppo</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<div class="main_alpha">
				<div class="main_left_alpha">P</div>
				<div class="main_right main_body_right"></div>
			</div>	

			<a href="?brand=palm&action=phone_list"><div class="main_body">
				<div class="main_left">Palm</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<div class="main_alpha">
				<div class="main_left_alpha">R</div>
				<div class="main_right main_body_right"></div>
			</div>	

			<a href="?brand=razer&action=phone_list"><div class="main_body">
				<div class="main_left">Razer</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=red_hydrogen&action=phone_list"><div class="main_body">
				<div class="main_left">Red hydrogen</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<div class="main_alpha">
				<div class="main_left_alpha">S</div>
				<div class="main_right main_body_right"></div>
			</div>	

			<a href="?brand=samsung&action=phone_list"><div class="main_body">
				<div class="main_left">Samsung</div>
				<div class="main_right main_body_right">></div>
			</div></a>			

			<a href="?brand=sony&action=phone_list"><div class="main_body">
				<div class="main_left">Sony</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=sharp&action=phone_list"><div class="main_body">
				<div class="main_left">Sharp</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<div class="main_alpha">
				<div class="main_left_alpha">V</div>
				<div class="main_right main_body_right"></div>
			</div>

			<a href="?brand=vivo&action=phone_list"><div class="main_body">
				<div class="main_left">Vivo</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<div class="main_alpha">
				<div class="main_left_alpha">X</div>
				<div class="main_right main_body_right"></div>
			</div>

			<a href="?brand=xiaomi&action=phone_list"><div class="main_body">
				<div class="main_left">Xiaomi</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=xolo&action=phone_list"><div class="main_body">
				<div class="main_left">XOLO</div>
				<div class="main_right main_body_right">></div>
			</div></a>


			<?php
				}
			
			?>			



			</div>
			<!--gad main ends-->

			<?php
				if($gad = 'smartphones'){
				$sel_fact = $conn -> query("SELECT * FROM facts WHERE cat = 'smartphones'");

				$fet_fact = $sel_fact -> fetch_assoc();
				$fact_head = $fet_fact['title'];
				$fact = $fet_fact['text'];
			?>

		</div>
			<!--gad main ends-->

			<div class="what_to">
				<div class="what_title"><?php echo $fact_head; ?></div>

				<div class="what_text">
				<?php echo $fact; ?>
			</div>
			</div>

			<?php 
				}else {
			
				$sel_fact = $conn -> query("SELECT * FROM facts WHERE cat = 'televisions'");

				$fet_fact = $sel_fact -> fetch_assoc();
				$fact_head = $fet_fact['title'];
				$fact = $fet_fact['text'];
			?>

		</div>
			<!--gad main ends-->

			<div class="what_to">
				<div class="what_title"><?php echo $fact_head; ?></div>

				<div class="what_text">
				<?php echo $fact; ?>
			</div>
			</div>

			<?php 
				}
			?>

		</div>
	<!-- body container ends-->
