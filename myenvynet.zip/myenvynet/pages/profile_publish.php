<div class="pub_box">


<?php


			//select content for news feed
			$select_news_feed = $conn -> query("SELECT * FROM news WHERE poster_email = '$poster_email' order by id DESC LIMIT 16");
			$counter = 0;
			while($fetch_feed = $select_news_feed -> fetch_assoc()){
				$news_feed_img = $fetch_feed['image'];
				$news_feed_title = $fetch_feed['title'];
				$news_feed_content = $fetch_feed['content'];
				$news_feed_date = $fetch_feed['date'];
				$news_feed_poster = $fetch_feed['poster'];
				$news_feed_id = $fetch_feed['id'];
				$rank = $fetch_feed['poster_rank'];
				$news_feed_extra = $fetch_feed['extra'];
				$poster_email = $fetch_feed['poster_email'];
				$section = $fetch_feed['section'];
				$strlen = strlen($news_feed_title);
				// create a new dom object
				$doc = new DOMDocument();
				//use the object to load our string
				$doc -> loadHTML($news_feed_content);
				//create an xpath to tranverse the dom
				$selector = new DOMXpath($doc);
				//select img as choice object
				$result = $selector -> query('//img');
				$img_count = 0;
				//count all matches

				$my_img_array = array();
				foreach($result  as $target){
					$img_count++;

					$img_att = $target->getAttribute('src');

					array_push($my_img_array, $img_att);
					
				}

		if($section != 'gallery' && $section != 'phones' && $section != 'televisions' && $section != 'laptops' && $section != 'sounds' && $section != 'speakers'){
			//check value of counter and decide if to post with pic
				if($counter == 0){
					$counter++;
		?>

					<!--newsfeed pic display-->
						<a href="?action=view&gv=<?php  echo $news_feed_id ;?>&dir=news_feed"><div class="pic_display_box">
							<!-- img box-->
								<div class="img_box">
									<img src="<?php echo $news_feed_img; ?>" width="100%" height="100%">
								</div>
							<!--img box ends-->
							<!--img_title-->
							<div class="img_title">
								<?php echo substr($news_feed_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
								
							</div>
							<!--img_title ends-->

							<!--img others -->
							<div class="img_others">
								<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="img_poster">By <?php echo $news_feed_poster ;?></div></a>

								<div class="img_date">
									<?php echo $news_feed_date; ?>
								</div>
								<div style="clear: both;"></div>
							</div>
							<!-- img others -->

						</div></a>
					<!-- news feed pic display box ends-->
					<div class="line"></div>
					<?php
			}else if ($counter > 0){
		?>
					<!--text-display-->
					<a href="?action=view&gv=<?php  echo $news_feed_id ;?>&dir=news_feed"><div class="text_display_box">
						<!-- text title-->
						<div class="text_title">
							<?php echo substr($news_feed_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
						</div>
						<!-- text _title ends-->

						<!-- text text-->
						<div class="text_text">
							<?php echo substr($news_feed_content,0,150); ?>
						</div>
						<!-- text text ends-->
						<div style="width: 100%; height: auto;">
						<!--text_others-->
						<div class="text_others">
							<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="text_poster">
								By <?php echo $news_feed_poster ;?>
							</div></a>

							<div class="text_date">
								<?php echo $news_feed_date; ?>
							</div>
							<div style="clear: both;"></div>
						</div>
						<!--text others end-->

					</div></a>
					<!--text display ends -->
				</div>
					<div class="line"></div>
					<?php
			}
		}else{
			
		 ?>
			<!--newsfeed pic display-->
					<a href="?action=view&gv=<?php  echo $gallery_id ;?>&dir=gallery">	<div class="pic_display_box">
							<!-- img box-->
								<div class="gallery_img_box">
									<img src="<?php echo $my_img_array[0]; ?>" width="100%" height="100%">

									<div class="gallery_extra_container">
										<div class="extra_div">
											<?php
												//check if extra is empty
												if($news_feed_extra != ''){?>

											<div class="extra"><?php echo substr($news_feed_extra, 0, 10 ) ;?></div>
											<?php }else{ ?>
											<div class="extra_empty">
												<?php echo $news_feed_extra ;?>
											</div>

										<?php }?>
										</div>
										<div class="gallery_icon">
											<div class="gicon"><i class="fa fa-camera-retro"></i></div>
										</div>
										<div class="pic_counter">
											<div class="extra_counter">
												1 of <?php echo $img_count ?>
											</div>
										</div>
									</div>
								</div>
							<!--img box ends-->
							<!--img_title-->
							<div class="img_title">
								<?php echo substr($news_feed_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
								
							</div>
							<!--img_title ends-->

							<!--img others -->
							<div class="img_others">
								<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="img_poster">By  <?php echo $news_feed_poster ;?></div></a>

								<div class="img_date">
									<?php echo $news_feed_date; ?>
								</div>
								<div style="clear: both;"></div>

								
							</div>
							<!-- img others -->

						</div></a>
					<!-- news feed pic display box ends-->
					
					<div class="line"></div>
<?php
		}

}

?>

</div>


<script>
	$(document).ready(function(evt){
		$('.text_text img').css("display","none");	
	});
</script>