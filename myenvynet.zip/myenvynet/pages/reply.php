<?php
	
	$com_id = $_GET['com_id'];
	$remark = $_GET['remark'];
	//fetch all the comments details

	$select_com = $conn -> query("SELECT * FROM comments WHERE id ='$com_id'");
		$fetched_com = $select_com -> fetch_assoc();
		$commenter = $fetched_com['commenter'];
		$commenter_img = $fetched_com['commenter_image'];
		$comment_title = $fetched_com['content_title'];
		$comment = $fetched_com['comment'];
		$commenter_dir_table = $fetched_com['dir_table'];
		$comment_id = $fetched_com['id'];
		$year = $fetched_com['year'];
		$month = $fetched_com['month'];
		$day = $fetched_com['day'];
		$hour = $fetched_com['hour'];
		$min = $fetched_com['minute'];
		$sec = $fetched_com['second'];
		$strlen = strlen($comment);

		//get user details
		$email = $_SESSION['email'];
		$select_user = $conn -> query("SELECT * FROM accounts WHERE email = '$email'");
		$fet_user = $select_user -> fetch_assoc();
		$user = $fet_user['name'];
		$user_image = $fet_user['image'];
?>



<body>
	<!-- body container starts-->
		<div class="body_container">
			<div class="reply_box">
				<!--reply title-->
				<div class="reply_title">
					Reply to <?php echo $commenter; ?> comment on <?php echo $comment_title; ?>
				</div>
				<!--reply title ends-->
				<!--reply box starts-->
				<div class="replyer_box">
					<?php if($_SESSION['email'] != ''){?>
					<div class="replyer_img">
						<?php if($user_image != ''){?>
						<img src="./images/profile.jpg"  width="100%" height="100%" />
					<?php }else{ ?>
						<div class="replyer_letter">
							<?php echo substr($user,0,1); ?>
						</div>
					<?php } ?>
					</div>

					<div class="replyer_name"><?php echo $user; ?></div>
					<div style="clear: both;"></div>
				<?php } ?>


				<!--main reply box starts-->
				<div class="main_reply_box">
					<div class="reply_dir">
						You are replying to this post...
					</div>

					<!--main reply commentbox starts -->
					<div class="main_reply_comment_box">
						<div class="comment_owner_box">
							<div class="comment_owner">
								<?php echo $commenter; ?>
							</div>
							<div class="commenting_time">
								2mins ago
							</div>
							<div style="clear: both;"></div>
						</div>

						<div class="main_reply_comment">
							<?php echo substr($comment,0,300);
								if($strlen > 300){
							 ?>
							 <span class="span">...more</span>
							<?php } ?>
						</div>
					</div>

					<script type="text/javascript">
						$(document).ready((evt)=>{
							$('.span').click((e)=>{
								$('.span').hide();
								$('.main_reply_comment').append("<?php echo substr($comment, 300); ?>");
							});
						});
					</script>
					<!--main reply comment box ends-->


					<!--reply text-->
					<?php 
							if($remark == 002){
						?>
						<div class="remark">Reply uploaded</div>
					<?php } ?>
					<div class="reply_text">
						<div class="reply_error"></div>
						
						<form action="db/reply_pro.php?cd=<?php echo $com_id; ?>" method="post" class="reply_form">
						<textarea name="reply_text" placeholder="Write something" class="reply"><?php echo $_SESSION['reply']; ?></textarea>

										<?php 
					if($_SESSION['email'] == ''){
				?>
				<!-- sign in dir box-->
				<div class="sign_in_dir_box">
					<div class="signin_up_box">
						<div class="signin_up">Sign in / Sign up</div>
						<div class="signin_up_icon_box">
							<div class="signin_up_fb"><i class="fab fa-facebook-f"></i></div>

							<div class="signin_up_gp"><i class="fab fa-google-plus-g"></i></div>

							<a href="?action=sign_in"><div class="signin_up_cp"><i class="fas fa-user-alt"></i></div></a>

							<div style="clear: both;"></div>
						</div>
						<div style="clear: both;"></div>
					</div>

					<!--fake button-->
					<div class="fake_button">Reply</div>
					<!-- fake button ends-->
				</div>
				<!--sign in dir box ends-->

			<?php }else{?>

				<!--main button-->
				<button type="submit" class="main_button">
					Reply
				</button>
				<!-- main buttton ends-->
			<?php } ?>
					</form>

					</div>
					<!--reply text ends-->
				</div>
			</div>
				<!--main reply box ends-->

				</div>
				<!--replyer box ends-->

				
			</div>
			<!-- posting rules start-->
			<div class="posting_rules">Posting rules</div>

			<div class="rule_box">
				<div class="rule_icon">
					<i class="fas fa-check correct"></i>
				</div>
				<div class="rule_text">
					Please you can only write your comment using English.
				</div>
				<div style="clear: both;"></div>
			</div>

			<div class="rule_box">
				<div class="rule_icon wrong">
					<i class="fas fa-times"></i>
				</div>
				<div class="rule_text">
					Refrain from personal attack, rude or foul languages.
				</div>
				<div style="clear: both;"></div>
			</div>


			<div class="rule_box">
				<div class="rule_icon wrong">
					<i class="fas fa-times"></i>
				</div>
				<div class="rule_text">
					Do not display tribal bigotry or disdain for a particular group of people. Show love and respect, even admiration.
				</div>
				<div style="clear: both;"></div>
			</div>

			<div class="rule_box">
				<div class="rule_icon">
					<i class="fas fa-check correct"></i>
				</div>
				<div class="rule_text">
					Please ignore trolls or report them.
				</div>
				<div style="clear: both;"></div>
			</div>

			<div class="rule_box">
				<div class="rule_icon wrong">
					<i class="fas fa-times"></i>
				</div>
				<div class="rule_text">
					Do not post adverts, links to adult materials or spam.
				</div>
				<div style="clear: both;"></div>
			</div>


			<div class="rule_box">
				<div class="rule_icon wrong">
					<i class="fas fa-times"></i>
				</div>
				<div class="rule_text">
					Posting of personal detail is at owners risk.
				</div>
				<div style="clear: both;"></div>
			</div>

			<!--posting rules end-->

		</div>
		<!-- body container ends-->


</body>
</html>
