<?php  
	include('./db/config.php');
	$brand = $_GET['brand'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
	<!-- body container starts-->
		<div class="body_container">

			<div class="list_head">
				<h3>Featured <?php echo strtoupper(substr($brand, 0 ,1)).substr($brand, 1);?> televisions.  </h3>
			</div>
			
			
			<!-- television starts -->
			<div class="tele_box">
				<!--tele title-->
					
				<!--tele title ends-->
				<?php
	$select_tele = $conn -> query("SELECT * FROM news WHERE section = 'televisions' && brand = '$brand' order by id DESC LIMIT 30");
	$line_count = 0;
	$count = mysqli_num_rows($select_tele);
	if($count > 0){
	
	while($fetch_tele = $select_tele -> fetch_assoc()){
		$tele_img = $fetch_tele['image'];
		$tele_title = $fetch_tele['title'];
		$tele_id = $fetch_tele['id'];
		$strlen = strlen($tele_title_title);
		$tele_manufacture_year = $fetch_tele['manufacture_year'];
		?>

				<!-- tele display-->
				<div class="smart_display">
					<?php
						if($tele_manufacture_year != ''){
					?>
					<a href="?action=tv_spec&sc=<?php echo $tele_id; ?>"><div class="manufacture_year"><?php echo $tele_manufacture_year; ?></div></a>
				<?php } ?>
					<a href="?action=tv_spec&sc=<?php echo $tele_id; ?>"><img src="<?php echo $tele_img ; ?>" width="100%" height="100%" /></a>
					<a href="?action=tv_spec&sc=<?php echo $tele_id; ?>"><div class="tele_name_container">
						<div class="tele_name">
							 <?php echo $tele_title; ?>
						</div>
					</div></a>
				</div>
				<?php } ?>
				<!-- tele display-->
				<div style="clear: both;"></div>

			</div>

			
			<!--television ends-->
			
			<?php
				}else{
					echo "<div class='oops' ><h2>oops! no record found</h2></div>";
				}
			?>


		</div>
		<!-- body container ends-->


</body>
</html>
