
	<!-- body container starts-->
		<div class="body_container">
			
			<!--publish conatainer starts-->

			<div class="pub_cont">
				<!--pub head starts-->
				<div class="pub_quest">
					Not signed in at the moment?
				</div>

				<div class="pub_ans">
					Sorry but you should <a href="?action=sign_up"><span style="color: #2A6BA6; cursor: pointer;">sign up</span></a> or <a href="?action=sign_in"><span style="color: #2A6BA6; cursor: pointer;">sign in</span></a> to be able to publish on Myenvynet. If you are already signed in, please continue
				</div>
				<!--pub head ends-->

				<!--selcat section begins-->
				<div class="selcat_head">
					Select the categories to publish on
				</div>

				<?php
					$sel = $conn -> query("SELECT * FROM pub_img WHERE id = 1");
					$selfet = $sel -> fetch_assoc();
					$image1 = $selfet['image'];

					$sel2 = $conn -> query("SELECT * FROM pub_img WHERE id = 2");
					$selfet2 = $sel2 -> fetch_assoc();
					 $image2 = $selfet2['image'];


				?>

				<div class="selcat_box">
					<a href="?action=sel_smartPhone"><div class="selcat_1">
						<img src="<?php echo $image1; ?>" >
						<div class="selcat_dir">
							Smartphones or TVs
						</div>
					</div></a>
					<a href="?action=sel_other"><div class="selcat_2">
						<img src="<?php echo $image2
						; ?>">
						<div class="selcat_dir">
							Other tech topics
						</div>
					</div></a>
				</div>
				<!--selcat section ends-->

				<!--pub others start-->
				<div class="pub_w_title">
					This is a unique opportunity to go viral
				</div>
				<div class="pub_write_up">
					<p>
						It is very easy to publish or upload pictures on myenvynet.com. All you need to do is to select the category you want to publish on, then on the next page, click on the section you want to publish on and voila! you can go ahead and create mesmerizing articles that will capture the mind of your readers. When you publish, we may promote your content to our readers through newsletter and social media if it is outstanding.
					</p>
					<p>
						The write-up (news, reviews, how-tos &amp; articles) published, then pictures uploaded must be tech-related. By tech-related we mean that it should be related to any kind of gadget & electronic device (e.g. Smartphones, TVs, Laptops, Speakers, Headphones, memory cards, fridges, air-conditioners, watches, drones, etc.), or automobile & locomotive (e.g. cars, motorbikes, bicycles, robots, trains, etc.) or watercraft (e.g. ships, boats, submarines, jet skis/personal watercrafts, etc.) or aircraft & spacecraft (e.g. jets, helicopters, gliders, airships, hot-air balloons, rockets, shuttles, space stations, manned maneuvering units, artificial satellite, etc.) as well as movies (of all kinds except X-rated movies) or online venture (e.g. bitcoins, affiliate marketing, blogging, e-commerce, etc.) or software (e.g. apps, games, OSs, drivers, robotics, automation, AI, VR, AR, databases, etc.) 
					</p>
					<p>
						Please note that when you publish any article or upload any picture, we assume that you have read and agreed to our <a href="#">terms </a>of use. And so should be held responsible for any misconduct.
					</p>
				</div>
				<!--pub others end-->
			</div>

			<!--publish container ends-->
			
		</div>
		<!-- body container ends-->
