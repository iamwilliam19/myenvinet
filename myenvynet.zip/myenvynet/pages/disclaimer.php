
<body>
	<!-- body container starts-->
		<div class="body_container">
			<!--disclaimer title-->
			<div class="disclaimer_title">
				Disclaimer
			</div>
			<!--disclaimer title ends-->
			

			<div class="disclaimer_text">
				<p>
					Despite having put in a lot of effort to provide reliable information about any particular product, we like to admit that the specifications or details of a product may not be 100% correct. Prices may vary too as products may not be pegged at a specific price tag at different countries, online and offline stores. But we have provided a close estimate based on what we have seen on some online retail stores and reputable websites.
				</p>

				<p>
					If you think that any part of the info we have provided about this product is not correct, please <a href="#">contact us</a>.
				</p>
			</div>
		</div>
		<!-- body container ends-->


</body>
</html>
