<?php
	$gad = $_GET['gad'];
?>
	
		<div class="gad_box">
			<!--main head star-->
			<div class="main_head">
				<div class="main_left">19 brands</div>
				<div class="main_right">Listing: A-Z</div>
			</div>
			<!--main head ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">Brand names</div>
				<div class="main_right main_body_right"></div>
			</div>

			<div class="main_alpha">
				<div class="main_left_alpha">B</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=bpl&action=television_list"><div class="main_body">
				<div class="main_left">BPL</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">E</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=element&action=television_list"><div class="main_body">
				<div class="main_left">Element</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">F</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=finlux&action=television_list"><div class="main_body">
				<div class="main_left">Finlux</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">H</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=hisense&action=television_list"><div class="main_body">
				<div class="main_left">Hisense</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">L</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=lg&action=television_list"><div class="main_body">
				<div class="main_left">LG</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">M</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=micromax&action=television_list"><div class="main_body">
				<div class="main_left">Micromax</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<!--main body star-->
			<a href="?brand=mitsubishi&action=television_list"><div class="main_body">
				<div class="main_left">Mitsubishi</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->
			
			<div class="main_alpha">
				<div class="main_left_alpha">P</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=panasonic&action=television_list"><div class="main_body">
				<div class="main_left">Panasonic</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">R</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=rca&action=television_list"><div class="main_body">
				<div class="main_left">RCA</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			<!--main body ends-->

			<div class="main_alpha">
				<div class="main_left_alpha">S</div>
				<div class="main_right main_body_right"></div>
			</div>

			<!--main body star-->
			<a href="?brand=samsung&action=television_list"><div class="main_body">
				<div class="main_left">Samsung</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=sony&action=television_list"><div class="main_body">
				<div class="main_left">Sony</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=sharp&action=television_list"><div class="main_body">
				<div class="main_left">Sharp</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=scepter&action=television_list"><div class="main_body">
				<div class="main_left">Scepter</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=seiki&action=television_list"><div class="main_body">
				<div class="main_left">Seiki</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=sansui&action=television_list"><div class="main_body">
				<div class="main_left">Sansui</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=supersonic&action=television_list"><div class="main_body">
				<div class="main_left">Supersonic</div>
				<div class="main_right main_body_right">></div>
			</div></a>
			

			<div class="main_alpha">
				<div class="main_left_alpha">T</div>
				<div class="main_right main_body_right"></div>
			</div>


			<a href="?brand=tcl&action=television_list"><div class="main_body">
				<div class="main_left">TCL</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<a href="?brand=toshiba&action=television_list"><div class="main_body">
				<div class="main_left">Toshiba</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			<div class="main_alpha">
				<div class="main_left_alpha">V</div>
				<div class="main_right main_body_right"></div>
			</div>

			<a href="?brand=vizio&action=television_list"><div class="main_body">
				<div class="main_left">Vizio</div>
				<div class="main_right main_body_right">></div>
			</div></a>

			
			
		</div>
	<!-- body container ends-->
