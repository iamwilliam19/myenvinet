<?php  
	include('./db/config.php');
	 $myaction;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
	<!-- body container starts-->
		<div class="body_container">
			
			<!--gallery_page _head-->
			<div class="gallery_pg_head">
				Gallery
			</div>
			<!--gallery page head ends-->

			<div class="gline"></div>

			<!--gallery page links-->
			<div class="gallery_pg_link">
				<div class=" gallery_link_container">
				<a href="?action=gallery">	<div class="smartphonesAndTv ">
						smartphones & Tv
					</div></a>

					<a href="?action=gallery_others"><div class="gallery_others <?php if($myaction = 'gallery_thers.php'){echo 'gallery_selected' ;} ?>">
						Others
					</div></a>

					<div style="clear: both;"></div>
				</div>
			</div>
			<!--gallery page links end-->

						<!-- gallery body-->
			
			<div class="gallery_box">
					

					<?php
			$select_gallery = $conn -> query("SELECT * FROM news WHERE section = 'gallery' && category = 'others'   order by id DESC LIMIT 16");
	
	while($fetch_gallery = $select_gallery -> fetch_assoc()){
		$gallery_img = $fetch_gallery['image'];
		$gallery_title = $fetch_gallery['title'];
		$gallery_content = $fetch_gallery['content'];
		$gallery_date = $fetch_gallery['date'];
		$gallery_poster = $fetch_gallery['poster'];
		$gallery_extra = $fetch_gallery['extra'];
		$id = $fetch_gallery['id'];
		$strlen = strlen($gallery_title);
		//count images
		// create a new dom object
		$doc = new DOMDocument();
		//use the object to load our string
		$doc -> loadHTML($gallery_content);
		//create an xpath to tranverse the dom
		$selector = new DOMXpath($doc);
		//select img as choice object
		$result = $selector -> query('//img');
		$img_count = 0;
		//count all matches

		$my_img_array = array();
		foreach($result  as $target){
			$img_count++;

			$img_att = $target->getAttribute('src');

			array_push($my_img_array, $img_att);
			
		}

	
		
?>	
		

					<!--newsfeed pic display-->
					<a href="?action=view&gv=<?php  echo $id ;?>&dir=gallery">	<div class="pic_display_box">
							<!-- img box-->
								<div class="gallery_img_box">
									<img src="<?php echo $my_img_array[0]; ?>" width="100%" height="100%">

									<div class="gallery_extra_container">
										<div class="extra_div">
											<?php
												//check if extra is empty
												if($gallery_extra != ''){?>

											<div class="extra"><?php echo substr($gallery_extra, 0, 10 ) ;?></div>
											<?php }else{ ?>
											<div class="extra_empty">
												<?php echo $gallery_extra ;?>
											</div>

										<?php }?>
										</div>
										<div class="gallery_icon">
											<div class="gicon"><i class="fa fa-camera-retro"></i></div>
										</div>
										<div class="pic_counter">
											<div class="extra_counter">
												1 of <?php echo $img_count ?>
											</div>
										</div>
									</div>
								</div>
							<!--img box ends-->
							<!--img_title-->
							<div class="img_title">
								<?php echo substr($gallery_title, 0,100);  if($strlen > 100){echo "..." ;} ?>
								
							</div>
							<!--img_title ends-->

							<!--img others -->
							<div class="img_others">
								<a href="?action=<?php if($rank == 'admin'){
									echo 'admin_profile';
								}else{
									echo 'member_profile';
								} ?>
								&poster_email=<?php echo $poster_email; ?>"><div class="img_poster">By  <?php echo $gallery_poster ;?></div></a>

								<div class="img_date">
									<?php echo $gallery_date; ?>
								</div>
								
							</div>
							<!-- img others -->


						</div></a>
					<!-- news feed pic display box ends-->
					
					<div class="line"></div>
					<?php
			
				}
		?>

			
				</div>
			<!-- gallery ends-->
			

			<!--gallery_publish starts-->
			<div class="gallery_publish">
				Publish Here
			</div>
			<!-- gallery publish ends-->
			
		</div>
		<!-- body container ends-->


</body>
</html>
