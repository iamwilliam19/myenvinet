-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2018 at 05:33 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `myenvynet`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL,
  `bio` longtext NOT NULL,
  `website` longtext NOT NULL,
  `facebook` longtext NOT NULL,
  `twitter` longtext NOT NULL,
  `last_seen` longtext NOT NULL,
  `signed_up_date` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `name`, `email`, `password`, `image`, `bio`, `website`, `facebook`, `twitter`, `last_seen`, `signed_up_date`) VALUES
(8, 'Ikeji', 'williamikeji@gmail.com', 'e5fc9faaf44519dbf1fda8702bba0228', './images/profile.jpg', '', '', '', '', '', ''),
(9, 'Ikeji', 'william@gmail.com', 'e5fc9faaf44519dbf1fda8702bba0228', '', '', '', '', '', '', ''),
(10, 'Chukwuebuka Okoli', 'okoli@gmail.com', 'e417ea5e8dc5ffeb3a864a8972902c7e', '', '', '', '', '', '', ''),
(11, 'ifeanyi', 'ikeji@gmail.com', '7769a28d8fb37872eb705872bdf17ba3', '', '', '', '', '', '', ''),
(12, 'Ufoma Lizzy', 'lizzy@gmail.com', '3bfa49b7c7146df8ca1a1a4be6143d8b', '', '', '', '', '', '', ''),
(13, 'IKeji william', 'ike@gmail.com', '19c7410d37284af76a75053dee24099f', './images/profile.jpg', 'The kind of posts users can see are the News, How-Tos, reviews & Articles the owner of this profile published on myenvynet. His replies to posts are not included, his comments on posts are not included, the reviews he has written about a particular ', '', 'facebook.com/ike william', '', '24 sept 1997', '21 sept 2011'),
(14, 'W', 'willia@gmail.com', 'bd5d2402914e26da4cf3d7339216d8a1', '', '', '', '', '', '', ''),
(15, 'l', 'oko@gmail.com', 'ce2bb1cc7440566e878d608d2a1c2cea', '', '', '', '', '', '', ''),
(16, '0', 'adol@gmail.com', '88c6a74b1ed1f410976492b6ec272926', '', '', '', '', '', '', ''),
(17, 'Willie obiano', 'obi@gmail.com', '108ec3252e1d968ead094e1af4609680', '', '', '', '', '', '', ''),
(18, 'Ikeji Nonso', 'williamphp@gmail.com', '7769a28d8fb37872eb705872bdf17ba3', '', '', '', '', '', '', ''),
(19, 'Wii', 'kelphp@gmail.com', 'b2d3ec74f516023873d07bdcb93f9332', '', '', '', '', '', '', ''),
(20, 'Chukwunonso Adolphus Ikeji', 'phans@gmail.com', 'b2d3ec74f516023873d07bdcb93f9332', './images/profile.jpg', '', '', '', '', '', ''),
(21, 'Chukwunonso Adolphus Ikeji', 'ik@gmail.com', '8c60273a626d75311a54c02099484532', './images/profile.jpg', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `administrators`
--

CREATE TABLE IF NOT EXISTS `administrators` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL,
  `bio` varchar(200) NOT NULL,
  `signed_up_date` varchar(200) NOT NULL,
  `website` varchar(100) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `twitter` varchar(200) NOT NULL,
  `last_seen` varchar(200) NOT NULL,
  `section_covered` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `administrators`
--

INSERT INTO `administrators` (`id`, `name`, `email`, `image`, `bio`, `signed_up_date`, `website`, `facebook`, `twitter`, `last_seen`, `section_covered`) VALUES
(1, 'Ikeji William', 'williamikeji@gmail.com', 'images/profile.jpg', 'I Am Pranjal Patel. I am a tech geek and lover. I personally love to code and have fun', '3rd september, 2016', 'toptalk.ng', 'facebook.com/williamikeji', 'twitter.com/williamikeji', '3rd october, 2018', 'gallery,news');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `commenter` varchar(200) NOT NULL,
  `commenter_image` varchar(200) NOT NULL,
  `comment` longtext NOT NULL,
  `dir_table` varchar(200) NOT NULL,
  `content_title` varchar(200) NOT NULL,
  `content_id` varchar(200) NOT NULL,
  `year` varchar(200) NOT NULL,
  `month` varchar(200) NOT NULL,
  `day` varchar(200) NOT NULL,
  `hour` varchar(200) NOT NULL,
  `minute` varchar(100) NOT NULL,
  `second` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `commenter`, `commenter_image`, `comment`, `dir_table`, `content_title`, `content_id`, `year`, `month`, `day`, `hour`, `minute`, `second`) VALUES
(1, 'Ufoma Lizzy', './images/profile.jpg', 'We are here', 'gallery', 'samsung', '4', '18', '09', '13', '01', '26', '06'),
(2, 'Ufoma Lizzy', '', 'We are here', 'gallery', 'samsung', '4', '18', '09', '13', '01', '32', '16'),
(3, 'Ufoma Lizzy', '', 'We are here', '', '', '', '18', '09', '13', '01', '34', '05'),
(4, 'Ufoma Lizzy', '', 'We are here', '', '', '', '18', '09', '13', '01', '36', '46'),
(5, 'Ufoma Lizzy', '', 'We are here', '', '', '', '18', '09', '13', '01', '38', '17'),
(6, 'Ufoma Lizzy', '', 'We are here', 'gallery', 'samsung', '4', '18', '09', '13', '01', '44', '07'),
(7, 'Ufoma Lizzy', '', 'We are here', '', 'samsung=gallery4=4', '', '18', '09', '13', '01', '44', '11'),
(8, 'Ufoma Lizzy', '', 'We are here', '', 'samsung=gallery4=4==', '', '18', '09', '13', '01', '45', '25'),
(9, 'Ufoma Lizzy', '', 'We are here', '', 'samsung=gallery4=4==', '', '18', '09', '13', '01', '45', '26'),
(10, 'Ufoma Lizzy', '', 'We are here', 'gallery', 'samsung', '4', '18', '09', '13', '01', '47', '30'),
(11, 'Ufoma Lizzy', '', 'We are here', '', 'samsung', '', '18', '09', '13', '01', '47', '49'),
(12, 'Ufoma Lizzy', '', 'We are here', '', 'samsung', '', '18', '09', '13', '01', '49', '13'),
(13, 'Ufoma Lizzy', '', 'We are here', '', 'samsung', '', '18', '09', '13', '01', '50', '49'),
(14, 'Ufoma Lizzy', '', 'We are here', '', 'samsung', '', '18', '09', '13', '01', '52', '28'),
(15, 'Ufoma Lizzy', '', 'We are here', '', 'samsung', '', '18', '09', '13', '01', '53', '30'),
(16, 'Ufoma Lizzy', '', 'We are here', '', 'samsung', '', '18', '09', '13', '01', '54', '27'),
(17, 'Ufoma Lizzy', '', 'We are here', 'gallery', 'samsung', '4', '18', '09', '13', '01', '58', '30'),
(18, 'Ufoma Lizzy', '', 'We are here', 'gallery', 'samsung', '4', '18', '09', '13', '02', '00', '03'),
(19, 'Ufoma Lizzy', '', 'We are here', 'gallery', 'samsung', '4', '18', '09', '13', '02', '00', '10'),
(20, 'ifoma Lizzy', '', 'ldldldlI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my comment ldldldlI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentldldldlI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my comment', 'gallery', 'samsung', '4', '18', '09', '13', '03', '12', '17'),
(21, 'ofoma Lizzy', './images/profile.jpg', 'I have done it , i have added my comment', 'gallery', 'samsung', '4', '18', '09', '13', '03', '15', '53'),
(22, 'IKeji william', '', 'This is the updated oneldldldlI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my comment ldldldlI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentldldldlI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my commentI have done it , i have added my comment', 'gallery', 'samsung', '4', '18', '09', '14', '02', '35', '26'),
(23, 'Willie obiano', '', 'this is just too cool to be true men . ', 'gallery', 'samsung', '2', '18', '09', '14', '03', '42', '37'),
(24, 'Willie obiano', '', 'okay maintain', 'gallery', 'samsung', '2', '18', '09', '14', '03', '47', '25'),
(25, 'Ufoma Lizzy', '', 'This is first comment here', 'news_feed', 'new tech in market', '5', '18', '09', '19', '09', '53', '23'),
(26, 'Ufoma Lizzy', '', 'this is refined', 'news_feed', 'Motorla is back in market', '3', '18', '10', '08', '07', '15', '35'),
(27, 'Ikeji', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'gallery', 'Iphone', '13', '18', '10', '17', '01', '54', '51');

-- --------------------------------------------------------

--
-- Table structure for table `compared`
--

CREATE TABLE IF NOT EXISTS `compared` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gadget_one` varchar(200) NOT NULL,
  `gadget_two` varchar(200) NOT NULL,
  `gadget_one_image` varchar(200) NOT NULL,
  `gadget_two_image` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `compared`
--

INSERT INTO `compared` (`id`, `gadget_one`, `gadget_two`, `gadget_one_image`, `gadget_two_image`, `category`) VALUES
(1, 'iphone', 'Galaxy s9', './images/ip.jpg', './images/gal1.jpg', 'phones'),
(2, 'sam', 'aung', './images/ip.jpg', './images/ip.jpg', 'phones'),
(3, 'added', 'added2', './images/ip.jpg', './images/ip.jpg', 'phones'),
(4, 'iphone', 'galaxy s9', './images/ip.jpg', './images/gal1.jpg', 'phones'),
(5, 'iphone', 'Galaxy S9', './images/ip.jpg', './images/gal1.jpg', 'phones'),
(6, 'iphone', 'Galaxy s9', './images/ip.jpg', './images/gal1.jpg', 'televisions'),
(7, 'Galaxy s9', 'iphone', './images/gal1.jpg', './images/ip.jpg', 'televisions'),
(8, 'galaxy s9', 'iphone', './images/gal1.jpg', './images/ip.jpg', 'televisions'),
(9, 'galaxy s9', 'iphone', './images/gal1.jpg', './images/ip.jpg', ''),
(10, 'galaxy s9', 'iphone', './images/gal1.jpg', './images/ip.jpg', ''),
(11, 'galaxy s9', 'iphone', './images/gal1.jpg', './images/ip.jpg', ''),
(12, 'iphone', 'Galaxy s9', './images/ip.jpg', './images/gal1.jpg', ''),
(13, 'iphone', 'Galaxy s9', './images/ip.jpg', './images/gal1.jpg', ''),
(14, 'iphone', 'Galaxy s9', './images/ip.jpg', './images/gal1.jpg', ''),
(15, 'iphone', 'Galaxy s9', './images/ip.jpg', './images/gal1.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `facts`
--

CREATE TABLE IF NOT EXISTS `facts` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `cat` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `text` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `facts`
--

INSERT INTO `facts` (`id`, `cat`, `title`, `text`) VALUES
(1, 'all', 'Here is what you might need to know', 'Myenvynet affiliates with online stores like Amazon, BestBuy, NewEgg, eBay and Walmart to bring to you the very best deals on smartphones, TVs, laptops, speakers, headphones & earphones… '),
(2, 'smartdeal', 'Here i', 'bklbuab kjhsIgba jgsdlbd ,sDUGKSUj jsGLFJBJ  KJHJds Myenvynet affiliates with online stores like Amazon, BestBuy, NewEgg, eBay and Walmart to bring to you the very best deals on smartphones, TVs, laptops, speakers, headphones & earphones… '),
(3, 'tvdeals', 'jkvcxihvxivbcxiuyv jyvkv inxihjio', 'bklbuab kjhsIgba jgsdlbd ,sDUGKSUj jsGLFJBJ KJHJds Myenvynet affiliates with online stores like Ama zon, BestBuy, NewEgg, eBay and Walmart to bring to you the very best deals on smartphones, TVs, laptops, speakers, headphones & earphones… '),
(4, 'laptopdeals', 'jkxcbvzkjblvkj', 'Myenvynet affiliates with online stores like Amazon, BestBuy, NewEgg, eBay and Walmart to bring to you the very best deals on smartphones, TVs, laptops, speakers, headphones & earphones… '),
(5, 'speakerdeals', 'knckzln ', 'Myenvynet affiliates with online stores like Amazon, BestBuy, NewEgg, eBay and Walmart to bring to you the very best deals on smartphones, TVs, laptops, speakers, headphones & earphones… '),
(6, 'soundsdeals', 'si=ounds', 'Myenvynet affiliates with online stores like Amazon, BestBuy, NewEgg, eBay and Walmart to bring to you the very best deals on smartphones, TVs, laptops, speakers, headphones & earphones… '),
(7, 'smartphones', 'Here is what you might need to know', 'This page contains a comprehensive list of television brands we cover. We do not cover all television brands so this list does not in any way represent the total number of television brands in the world. There are some brands we’ve left out or do not cover because they may not be active any more in the TV business or they do not represent the interest of a significant number of our users/audience. Please we are really sorry for any inconvenience this decision of ours would cause'),
(8, 'televisions', 'Here is what you might need to know', 'This page contains a comprehensive list of smartphone brands we cover. We do not cover all smartphone brands so this list does not in any way represent the total number of smartphone brands in the world. There are some brands we’ve left out or do not cover because they may not be active any more in the smartphone business or they do not represent the interest of a significant number of our users/audience. Please we are really sorry for any inconvenience this decision of ours would cause.');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `section` varchar(200) NOT NULL,
  `poster` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `poster_email` varchar(200) NOT NULL,
  `poster_rank` varchar(200) NOT NULL,
  `store` varchar(200) NOT NULL,
  `disccount` varchar(200) NOT NULL,
  `link` varchar(200) NOT NULL,
  `feature` varchar(200) NOT NULL,
  `types` varchar(200) NOT NULL,
  `extra` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `brand` longtext NOT NULL,
  `release_date` longtext NOT NULL,
  `version` longtext NOT NULL,
  `name_2` longtext NOT NULL,
  `manufacturer` longtext NOT NULL,
  `screen_size` longtext NOT NULL,
  `ops` longtext NOT NULL,
  `pro` longtext NOT NULL,
  `ram` longtext NOT NULL,
  `int_mem` longtext NOT NULL,
  `camera` longtext NOT NULL,
  `battery` longtext NOT NULL,
  `other_high` longtext NOT NULL,
  `dimension` longtext NOT NULL,
  `weight` longtext NOT NULL,
  `screen_to_body` longtext NOT NULL,
  `aspect_ratio` longtext NOT NULL,
  `display_type` longtext NOT NULL,
  `resolution` longtext NOT NULL,
  `pixel_den` longtext NOT NULL,
  `cont_ratio` longtext NOT NULL,
  `phy_key` longtext NOT NULL,
  `edge_disp` longtext NOT NULL,
  `triluminos` longtext NOT NULL,
  `color_sat` longtext NOT NULL,
  `brightness` longtext NOT NULL,
  `hd_comp` longtext NOT NULL,
  `three_d_touch` longtext NOT NULL,
  `true_tone` longtext NOT NULL,
  `wide_color` longtext NOT NULL,
  `always_on` longtext NOT NULL,
  `pixel_resp` longtext NOT NULL,
  `screen_prot` longtext NOT NULL,
  `curved_screen` longtext NOT NULL,
  `anti_finger` longtext NOT NULL,
  `blue_light` longtext NOT NULL,
  `sun_light` longtext NOT NULL,
  `multi_touch` longtext NOT NULL,
  `other_feat` longtext NOT NULL,
  `ui` longtext NOT NULL,
  `pre_installed` longtext NOT NULL,
  `graphic_pro` longtext NOT NULL,
  `gpu` longtext NOT NULL,
  `soc` longtext NOT NULL,
  `isa` longtext NOT NULL,
  `pro_tech` longtext NOT NULL,
  `cache` longtext NOT NULL,
  `cpu` longtext NOT NULL,
  `co_pro` longtext NOT NULL,
  `ram_type` longtext NOT NULL,
  `ram_channel` longtext NOT NULL,
  `freq` longtext NOT NULL,
  `mem_type` longtext NOT NULL,
  `mem_card` longtext NOT NULL,
  `front_cam` longtext NOT NULL,
  `sensor_mod` longtext NOT NULL,
  `vid_rec` longtext NOT NULL,
  `rear_cam` longtext NOT NULL,
  `sensor_type` longtext NOT NULL,
  `cam_feat` longtext NOT NULL,
  `vid_format` longtext NOT NULL,
  `aud_format` longtext NOT NULL,
  `img_format` longtext NOT NULL,
  `speaker` longtext NOT NULL,
  `microphone` longtext NOT NULL,
  `sim_count` longtext NOT NULL,
  `sim_type` longtext NOT NULL,
  `twog_call` longtext NOT NULL,
  `threeg_call` longtext NOT NULL,
  `fourg_call` longtext NOT NULL,
  `twog_data` longtext NOT NULL,
  `threeg_data` longtext NOT NULL,
  `fourg_data` longtext NOT NULL,
  `please_note` longtext NOT NULL,
  `sim_use` longtext NOT NULL,
  `wifi` longtext NOT NULL,
  `wifi_feature` longtext NOT NULL,
  `cell_net` longtext NOT NULL,
  `data_con` longtext NOT NULL,
  `bluetooth` longtext NOT NULL,
  `nav_sys` longtext NOT NULL,
  `other_con` longtext NOT NULL,
  `usb_port` longtext NOT NULL,
  `audio_jack` longtext NOT NULL,
  `Ddi` longtext NOT NULL,
  `finger_print` longtext NOT NULL,
  `face_rec` longtext NOT NULL,
  `other_sensors` longtext NOT NULL,
  `bat_type` longtext NOT NULL,
  `bat_mod` longtext NOT NULL,
  `charge_output` longtext NOT NULL,
  `bat_sup` longtext NOT NULL,
  `wearable` longtext NOT NULL,
  `fm` longtext NOT NULL,
  `not_light` longtext NOT NULL,
  `voice_ass` longtext NOT NULL,
  `extra_pro` longtext NOT NULL,
  `air_ges` longtext NOT NULL,
  `cloud_sto` longtext NOT NULL,
  `others` longtext NOT NULL,
  `service_temp` longtext NOT NULL,
  `sar` longtext NOT NULL,
  `sty_pen` longtext NOT NULL,
  `mobile_pay` longtext NOT NULL,
  `support` longtext NOT NULL,
  `war_type` longtext NOT NULL,
  `color` longtext NOT NULL,
  `price` varchar(200) NOT NULL,
  `audio_output` longtext NOT NULL,
  `series` longtext NOT NULL,
  `motion_inter` longtext NOT NULL,
  `screen_refresh` longtext NOT NULL,
  `tv_type` longtext NOT NULL,
  `tv_channel_tuner` longtext NOT NULL,
  `best_deal` longtext NOT NULL,
  `dimming_tech` longtext NOT NULL,
  `backlight` longtext NOT NULL,
  `viewing_angle` longtext NOT NULL,
  `smart_tv` longtext NOT NULL,
  `smart_tv_feat` longtext NOT NULL,
  `flat_screen` longtext NOT NULL,
  `three_d_tv` longtext NOT NULL,
  `three_d_tv_glasses` longtext NOT NULL,
  `mi_value` longtext NOT NULL,
  `frame_rate` longtext NOT NULL,
  `video_signal` longtext NOT NULL,
  `vp_mode` longtext NOT NULL,
  `speaker_output` longtext NOT NULL,
  `sound_effect` longtext NOT NULL,
  `cable_port` longtext NOT NULL,
  `ethernet_port` longtext NOT NULL,
  `Dap` longtext NOT NULL,
  `add_feat` longtext NOT NULL,
  `LAN` longtext NOT NULL,
  `stand_by` longtext NOT NULL,
  `power_saving` longtext NOT NULL,
  `req_voltage` longtext NOT NULL,
  `req_freq` longtext NOT NULL,
  `power_add_feat` longtext NOT NULL,
  `wall_mount` longtext NOT NULL,
  `tv_stand` longtext NOT NULL,
  `config_others` longtext NOT NULL,
  `in_box` longtext NOT NULL,
  `other_comp_acc` longtext NOT NULL,
  `lang_sup` longtext NOT NULL,
  `liscence` longtext NOT NULL,
  `other_spec` longtext NOT NULL,
  `other_image_feat` longtext NOT NULL,
  `other_audio_feat` longtext NOT NULL,
  `other_cam_feat` longtext NOT NULL,
  `head_phone_jack` longtext NOT NULL,
  `video_port` longtext NOT NULL,
  `cam_resolution` longtext NOT NULL,
  `light_sensor` longtext NOT NULL,
  `operating_power` longtext NOT NULL,
  `manufacture_year` longtext NOT NULL,
  `year` varchar(200) NOT NULL,
  `month` varchar(200) NOT NULL,
  `day` varchar(200) NOT NULL,
  `hour` varchar(200) NOT NULL,
  `minute` varchar(200) NOT NULL,
  `second` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=86 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `image`, `content`, `section`, `poster`, `date`, `poster_email`, `poster_rank`, `store`, `disccount`, `link`, `feature`, `types`, `extra`, `category`, `name`, `brand`, `release_date`, `version`, `name_2`, `manufacturer`, `screen_size`, `ops`, `pro`, `ram`, `int_mem`, `camera`, `battery`, `other_high`, `dimension`, `weight`, `screen_to_body`, `aspect_ratio`, `display_type`, `resolution`, `pixel_den`, `cont_ratio`, `phy_key`, `edge_disp`, `triluminos`, `color_sat`, `brightness`, `hd_comp`, `three_d_touch`, `true_tone`, `wide_color`, `always_on`, `pixel_resp`, `screen_prot`, `curved_screen`, `anti_finger`, `blue_light`, `sun_light`, `multi_touch`, `other_feat`, `ui`, `pre_installed`, `graphic_pro`, `gpu`, `soc`, `isa`, `pro_tech`, `cache`, `cpu`, `co_pro`, `ram_type`, `ram_channel`, `freq`, `mem_type`, `mem_card`, `front_cam`, `sensor_mod`, `vid_rec`, `rear_cam`, `sensor_type`, `cam_feat`, `vid_format`, `aud_format`, `img_format`, `speaker`, `microphone`, `sim_count`, `sim_type`, `twog_call`, `threeg_call`, `fourg_call`, `twog_data`, `threeg_data`, `fourg_data`, `please_note`, `sim_use`, `wifi`, `wifi_feature`, `cell_net`, `data_con`, `bluetooth`, `nav_sys`, `other_con`, `usb_port`, `audio_jack`, `Ddi`, `finger_print`, `face_rec`, `other_sensors`, `bat_type`, `bat_mod`, `charge_output`, `bat_sup`, `wearable`, `fm`, `not_light`, `voice_ass`, `extra_pro`, `air_ges`, `cloud_sto`, `others`, `service_temp`, `sar`, `sty_pen`, `mobile_pay`, `support`, `war_type`, `color`, `price`, `audio_output`, `series`, `motion_inter`, `screen_refresh`, `tv_type`, `tv_channel_tuner`, `best_deal`, `dimming_tech`, `backlight`, `viewing_angle`, `smart_tv`, `smart_tv_feat`, `flat_screen`, `three_d_tv`, `three_d_tv_glasses`, `mi_value`, `frame_rate`, `video_signal`, `vp_mode`, `speaker_output`, `sound_effect`, `cable_port`, `ethernet_port`, `Dap`, `add_feat`, `LAN`, `stand_by`, `power_saving`, `req_voltage`, `req_freq`, `power_add_feat`, `wall_mount`, `tv_stand`, `config_others`, `in_box`, `other_comp_acc`, `lang_sup`, `liscence`, `other_spec`, `other_image_feat`, `other_audio_feat`, `other_cam_feat`, `head_phone_jack`, `video_port`, `cam_resolution`, `light_sensor`, `operating_power`, `manufacture_year`, `year`, `month`, `day`, `hour`, `minute`, `second`) VALUES
(1, 'This start-up is probably the best of the century nsduiaio nsduhf jiw', './images/samsung.jpg', 'At last you’re finally done with your old smartphone and you are looking forward to getting another one as soon as possible? \n\n', 'news_feed', 'IKeji william', '15 mins ago', 'williamikeji@gmail.com', 'admin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '9', '20', '23', '23', '12'),
(2, 'samusunThis start-up is probably the best of the century', './images/samsung.jpg', 'At last youre finally done with your old smartphone and you are looking forward to getting another one as soon as possible\n<img src="./images/gal1.jpg"/>\n<img src="./images/gal2.jpg"/><img src="./images/gal1.jpg"/>\n<img src="./images/gal2.jpg"/>\n\n<p>kkk</p>\n', 'news_feed', 'william', '34mins', 'williamikeji@gmail.com', 'admin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '3', '12', '22', '24', '11'),
(3, 'Motorla is back in market', './images/samsung.jpg', 'At last you’re finally done with your old smartphone and you are looking forward to getting another one as soon as possible? ', 'news_feed', 'ikeji william', '34min', 'williamikeji@gmail.com', 'admin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '17', '2', '1', '1', '34', '04'),
(4, 'again what do we have', './images/samsung.jpg', 'At last you’re finally done with your old smartphone and you are looking forward to getting another one as soon as possible? ', 'articles', 'poster', 'today', 'dinjvn.@bxjb.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '17', '12', '2', '12', '35', '23'),
(5, 'new tech in market', './images/samsung.jpg', 'At last you’re finally done with your old smartphone and you are looking forward to getting another one as soon as possib\n<img src="./images/samsung.jpg" />', 'articles', 'poster', 'yesterday', 'williamikeji@gmail.com', 'admin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '16', '1', '1', '3', '46', '34'),
(6, 'Galaxy s9', './images/gal1.jpg', '<img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' />', 'phones', 'william', 'today', 'williamikeji@gmail.com', 'member', '', '', '', '', '', '', '', '', 'apple', '23sept 3027', 'samsung', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'v', 'Global and India versions', '', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'v', 'v', 'Global and India versions', 'v', 'v', 'v', 'Global and India versions', 'Global and India versions', 'v', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'vGlobal and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018', '2018', '1', '21', '3', '3', '23'),
(7, 'Iphone', './images/ip.jpg', '<img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' />', 'phones', 'william', 'today', 'williamikeji@gmail.com', 'admin', '', '', '', '', '', '', '', '', 'apple', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'vGlobal and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', 'Global and India versions', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018', '07', '3', '4', '45', '45'),
(8, 'the king os hre', './images/ip.jpg', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'reviews', 'william', 'today', 'williamikeji@gmail.com', 'admin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018', '07', '32', '5', '6', '56'),
(9, 'we wre here', './images/ip.jpg', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'reviews', 'ike', 'yesterday', 'ike@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018', '05', '2', '6', '5', '43'),
(10, 'hoiw rto', './images/repair.jpg', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'how_to', 'william', 'today', 'ike@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018', '04', '2', '7', '54', '23'),
(11, 'how to do it', './images/repair.jpg', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'how_to', 'wili', 'yesterday', 'williamikeji@gmail.com', 'admin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018', '04', '2', '5', '4', '56'),
(12, 'samsung', './images/gal1.jpg', '<img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' />\n\n\n\n\n\nLorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.\n', 'gallery', 'william', 'today', 'williamikeji@gmail.com', 'admin', '', '', '', '', '', 'don''t miss', 'phone', 'samsung', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018', '04', '2', '4', '45', '45'),
(13, 'Iphone', './images/gal2.jpg', '<img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' />\n\n\n\n\n\nLorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'gallery', 'will', 'date', 'ike@gmail.com', 'member', '', '', '', '', '', 'get it', 'others', 'samsung', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018', '06', '23', '09', '57', '11'),
(14, 'iphone', './images/ip.jpg', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'deals', 'william', 'today', 'williamikeji@gmail.com', 'admin', 'ebay', '50', '', 'ai', '', '', 'sounds', '', 'samsung', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '100', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2012', '07', '23', '08', '58', '15'),
(15, 'samsung', './images/tele.png', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'deals', 'william', 'da', 'williamikeji@gmail.com', 'admin', 'ebay', '50', '', '', 'hybrid', '', 'televisions', '', 'samsung', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '79', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018', '08', '20', '07', '59', '14'),
(16, 'ARTIB', './images/ip.jpg', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'articles', 'william', 'date', 'williamikeji@gmail.com', 'admin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '13', '09', '24', '09', '45', '12'),
(17, 'thr asr', './images/ip.jpg', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'articles', 'mon', 'da', 'williamikeji@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '12', '10', '19', '10', '30', '24'),
(18, 'smartscreen', './images/tele.png', '<img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' />\r\n\r\n\r\n\r\n\r\n\r\nLorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'televisions', 'william', '', 'ike@gmail.com', 'member', '', '', '', '', '', '', '', '', 'samsung', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2019', '2015', '11', '16', '11', '40', '25'),
(19, 'tele', './images/tele.png', '<img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' />\n\n\n\n\n\nLorem ipsum dolor, sit amet consectetur adipisicing elit. Amet rem reprehenderit eos vel, velit, magni voluptatem possimus voluptate quae sit iste at. Est at maiores qui porro dolorem blanditiis reiciendis, ducimus deleniti consectetur dignissimos aut libero fugit, veniam minus! Facere ut temporibus vero doloribus aspernatur nesciunt porro vel maiores architecto.', 'televisions', '', '', 'williamikeji@gmail.com', '', '', '', '', '', '', '', '', '', 'samsung', '', '', '', '', 'RAM and Memory', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2016', '2017', '12', '11', '12', '50', '27'),
(20, 'samsung', './images/tele.png', '<img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' /><img src=''./images/gal1.jpg'' />\n\n\n\n', 'televisions', 'william', 'yesterday', 'williamikeji@gmail.com', 'admin', 'walmart', '90', '', '', '', '', 'samsung', '', 'samsung', '23 09 1994', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'v', 'v', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'v', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'v', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and MemoryRAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', '', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', '100', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'RAM and Memory', 'vRAM and Memory', 'RAM and Memory', 'heac', 'heck', '20', 'sgssrw', 'juuid', '2017', '2018', '12', '20', '12', '30', '29'),
(26, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(27, 'xcxc', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(28, 'vv', 'data', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(29, 'jjk', 'data', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(30, '<p>my first code</p>', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(47, 'whats up', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(48, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(49, 'this is first title', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(50, '<p><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(52, '<p><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(54, '<p>yes of</p><p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABMsAAAGgCAYAAAC0ZuCcAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAANZpSURBVHhe7P1djF1Veu8LH/XtuX5v nZfvhI3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(57, '<p>the op nvh</p><p><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(58, '<p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABQ0AAAIUCAYAAACw gpEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAJ7PSURBVHhe7b3tjx3VvaAb5c/IvzASXyI Ib4kEpKVSEYJQRGID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(60, '<p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABQ0AAAIUCAYAAACw gpEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAJ7PSURBVHhe7b3tjx3VvaAb5c/IvzASXyI Ib4kEpKVSEYJQRGID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(61, '<p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABQ0AAAIUCAYAAACw gpEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAJ7PSURBVHhe7b3tjx3VvaAb5c/IvzASXyI Ib4kEpKVSEYJQRGID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(63, 'this is first title', '<p><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(64, 'this is first title', '<p><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(65, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(66, 'this is first title', '<img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQU', '', 'news_feed', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(67, 'checking', '<img style="width: 100%; height:100%;" src="./images/1542563062.JPG">', '', 'news_feed', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(68, 'hh', '', '<p><img style="max-width: 100%;" src="./images/1542563502.JPG"><img style="max-width: 100%;" src="./images/1542563502.PNG"><br></p><p>conclusion</p>', 'news_feed', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `news` (`id`, `title`, `image`, `content`, `section`, `poster`, `date`, `poster_email`, `poster_rank`, `store`, `disccount`, `link`, `feature`, `types`, `extra`, `category`, `name`, `brand`, `release_date`, `version`, `name_2`, `manufacturer`, `screen_size`, `ops`, `pro`, `ram`, `int_mem`, `camera`, `battery`, `other_high`, `dimension`, `weight`, `screen_to_body`, `aspect_ratio`, `display_type`, `resolution`, `pixel_den`, `cont_ratio`, `phy_key`, `edge_disp`, `triluminos`, `color_sat`, `brightness`, `hd_comp`, `three_d_touch`, `true_tone`, `wide_color`, `always_on`, `pixel_resp`, `screen_prot`, `curved_screen`, `anti_finger`, `blue_light`, `sun_light`, `multi_touch`, `other_feat`, `ui`, `pre_installed`, `graphic_pro`, `gpu`, `soc`, `isa`, `pro_tech`, `cache`, `cpu`, `co_pro`, `ram_type`, `ram_channel`, `freq`, `mem_type`, `mem_card`, `front_cam`, `sensor_mod`, `vid_rec`, `rear_cam`, `sensor_type`, `cam_feat`, `vid_format`, `aud_format`, `img_format`, `speaker`, `microphone`, `sim_count`, `sim_type`, `twog_call`, `threeg_call`, `fourg_call`, `twog_data`, `threeg_data`, `fourg_data`, `please_note`, `sim_use`, `wifi`, `wifi_feature`, `cell_net`, `data_con`, `bluetooth`, `nav_sys`, `other_con`, `usb_port`, `audio_jack`, `Ddi`, `finger_print`, `face_rec`, `other_sensors`, `bat_type`, `bat_mod`, `charge_output`, `bat_sup`, `wearable`, `fm`, `not_light`, `voice_ass`, `extra_pro`, `air_ges`, `cloud_sto`, `others`, `service_temp`, `sar`, `sty_pen`, `mobile_pay`, `support`, `war_type`, `color`, `price`, `audio_output`, `series`, `motion_inter`, `screen_refresh`, `tv_type`, `tv_channel_tuner`, `best_deal`, `dimming_tech`, `backlight`, `viewing_angle`, `smart_tv`, `smart_tv_feat`, `flat_screen`, `three_d_tv`, `three_d_tv_glasses`, `mi_value`, `frame_rate`, `video_signal`, `vp_mode`, `speaker_output`, `sound_effect`, `cable_port`, `ethernet_port`, `Dap`, `add_feat`, `LAN`, `stand_by`, `power_saving`, `req_voltage`, `req_freq`, `power_add_feat`, `wall_mount`, `tv_stand`, `config_others`, `in_box`, `other_comp_acc`, `lang_sup`, `liscence`, `other_spec`, `other_image_feat`, `other_audio_feat`, `other_cam_feat`, `head_phone_jack`, `video_port`, `cam_resolution`, `light_sensor`, `operating_power`, `manufacture_year`, `year`, `month`, `day`, `hour`, `minute`, `second`) VALUES
(69, 'should work', './images/1542570011.png', '<p><img style="width: 1093.17px;" src="./images/1542570011.png"><img style="width: 1093.17px;" src="./images/1542569987.png"><br></p>', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(70, 'should work', './images/1542570011.png', '<p><img style="width: 1093.17px;" src="./images/1542570011.png"><img style="width: 1093.17px;" src="./images/1542569987.png"><br></p>', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(71, 'jk', './images/1542570668.png', '<p><img style="width: 456px;" src="./images/1542570668.png"></p><p><img style="width: 1093.17px;" src="./images/1542570688.PNG"><br></p>', 'news_feed', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(72, 'oo', './images/1542570797.JPG', '<p><img style="width: 100%;" src="./images/1542570797.JPG">kllklklk</p><p><img style="width: 456px;" src="./images/1542570811.png"><br></p>', 'news_feed', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(73, 'nkmk', './images/1542682415.png', '<p>jki<img src="./images/1542682415.png" style="width: 455.994px;"></p><p><br></p><p><br></p>', 'news_feed', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '20', '04', '01', '28'),
(74, 'nkmk', './images/1542682415.png', '<p>jki<img src="./images/1542682415.png" style="width: 455.994px;"></p><p><br></p><p><br></p>', 'news_feed', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '20', '04', '05', '45'),
(75, 'main', './images/1542683688.png', '<p>Wha elses<img src="./images/1542683688.png" style="width: 455.994px;"></p>', 'news_feed', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '20', '04', '14', '52'),
(76, 'this is first dtitle', './images/1543071916.jpg', '<div style="text-align: justify;"><img src="./images/1543071916.jpg" style="width: 693.011px;"></div><div style="text-align: justify;">wht does this mean<img src="./images/1543071942.jpg" style="width: 695.994px;"><img src="./images/1543071942.png" style="width: 411.989px;"></div>', 'news_feed', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '24', '16', '05', '54'),
(77, 'this is amin', './images/1543072309.jpg', '<p><img src="./images/1543072309.jpg" style="width: 800px;"></p><p>khvidfhbiod</p><p>dakfbgiub</p>', '', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '24', '16', '11', '55'),
(78, 'this is first title', './images/1543072460.jpg', '<p><img src="./images/1543072460.jpg" style="width: 890.994px;"><br></p>', '', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '24', '16', '14', '23'),
(79, 'this is amin', './images/1543072309.jpg', '<p><img src="./images/1543072309.jpg" style="width: 800px;"></p><p>khvidfhbiod</p><p>dakfbgiub</p>', 'news_feed', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '24', '16', '15', '06'),
(80, 'this is articles', './images/1543072941.jpg', '<p>,hxclzkhub</p><p><img src="./images/1543072941.jpg" style="width: 695.994px;"><br></p>', 'articles', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '24', '16', '22', '24'),
(81, 'how to', './images/1543073073.png', '<p><img src="./images/1543073073.png" style="width: 411.989px;"></p><p>nnfk</p>', 'how_to', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '24', '16', '24', '39'),
(82, 'currrent', './images/1543254054.jpg', '<p><img src="./images/1543254054.jpg" style="width: 890.994px;"></p><p>whats current</p>', 'news_feed', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '26', '18', '41', '06'),
(83, 'my article', './images/1543255577.jpg', '<p><img src="./images/1543255577.jpg" style="width: 695.994px;"></p><p>my main article</p>', 'articles', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '26', '19', '06', '27'),
(84, 'other news', './images/1543255666.jpg', '<p><img src="./images/1543255666.jpg" style="width: 423.977px;"><br></p>', 'news_feed', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '26', '19', '07', '48'),
(85, 'other news adblsbibl adlsibiafbdlibduf dsbfausidbfdib  adsfauib d flsaufsdb fdisafiuogfoubfbsdgf ', './images/1543255666.jpg', '<p><img src="./images/1543255666.jpg" style="width: 423.977px;"><br></p>', 'news_feed', 'Chukwunonso Adolphus Ikeji', '', 'ik@gmail.com', 'member', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18', '11', '26', '19', '09', '50');

-- --------------------------------------------------------

--
-- Table structure for table `pub_img`
--

CREATE TABLE IF NOT EXISTS `pub_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pub_img`
--

INSERT INTO `pub_img` (`id`, `image`) VALUES
(1, 'images/ip.jpg'),
(2, 'images/ip.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `replys`
--

CREATE TABLE IF NOT EXISTS `replys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` varchar(200) NOT NULL,
  `replyer` longtext NOT NULL,
  `reply` longtext NOT NULL,
  `content_id` varchar(200) NOT NULL,
  `content_title` varchar(200) NOT NULL,
  `dir_table` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `month` varchar(200) NOT NULL,
  `day` varchar(200) NOT NULL,
  `hour` varchar(200) NOT NULL,
  `minute` varchar(200) NOT NULL,
  `second` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `replys`
--

INSERT INTO `replys` (`id`, `comment_id`, `replyer`, `reply`, `content_id`, `content_title`, `dir_table`, `year`, `month`, `day`, `hour`, `minute`, `second`) VALUES
(1, '20', 'Ufoma Lizzy', 'This is it', '4', 'samsung', 'gallery', '18', '09', '16', '07', '42', '43'),
(2, '20', 'Ufoma Lizzy', 'This is my updated', '4', 'samsung', 'gallery', '18', '09', '16', '07', '46', '38'),
(3, '20', 'Ufoma Lizzy', 'this', '4', 'samsung', 'gallery', '18', '09', '16', '07', '46', '58'),
(4, '20', 'Ufoma Lizzy', 'this', '4', 'samsung', 'gallery', '18', '09', '16', '07', '49', '41'),
(5, '20', 'Ufoma Lizzy', 'this is the best', '4', 'samsung', 'gallery', '18', '09', '16', '07', '49', '53'),
(6, '20', 'Ufoma Lizzy', 'this is main', '4', 'samsung', 'gallery', '18', '09', '16', '08', '03', '17'),
(7, '20', 'Ufoma Lizzy', 'udd', '4', 'samsung', 'gallery', '18', '09', '16', '08', '04', '43'),
(8, '20', 'Ufoma Lizzy', 'af', '4', 'samsung', 'gallery', '18', '09', '16', '08', '04', '54'),
(9, '20', 'Ufoma Lizzy', 'kdnfkldnln', '4', 'samsung', 'gallery', '18', '09', '16', '08', '07', '02'),
(10, '26', 'Ufoma Lizzy', 'first reply to this', '3', 'Motorla is back in market', 'news_feed', '18', '10', '08', '07', '15', '51'),
(11, '26', 'Ufoma Lizzy', 'ndfjlnna;d', '3', 'Motorla is back in market', 'news_feed', '18', '10', '08', '07', '16', '12'),
(12, '26', 'Ufoma Lizzy', 'afsssa', '3', 'Motorla is back in market', 'news_feed', '18', '10', '08', '07', '20', '43'),
(13, '26', 'Ufoma Lizzy', 'You are mad', '3', 'Motorla is back in market', 'news_feed', '18', '10', '08', '07', '21', '07'),
(14, '26', 'Wii', 'this is myb repluy', '3', 'Motorla is back in market', 'news_feed', '18', '10', '16', '01', '58', '00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
